# Validação da 0.17.2

## Partida da 0.17.1 (10/10/2026)

Fleshmob: 12/12 golpes no corpo reduzidos, inclusive 4 entre 3,08 e 3,74 m. Cuspidor de Bile (Bile Spewer MK2): impacto da bolha de ácido é projétil com dano nativo 0 (decisão "bloquear" sem escrita); o dano real do ácido (33/37) chega como Ability causa zero com causador = bolha (353) e dono = cuspidor (355), não resolvido e mantido. Golpe de perto do cuspidor (`0xf25abcdd`, 36, 1,5–2,7 m) ficou sem redução por causa da exclusão por tipo da 0.17.1.

Esclarecimento do usuário: só o cuspe de ácido deve ficar original; o corpo a corpo dos cuspidores deve ser reduzido.

## Alterações

- Removida a exclusão por tipo dos inimigos de ácido (Bile/Nursing/Rupture Spewer, Bile Spitter, Bile Warrior).
- Regras por par e por 3 m exigem causador igual ao dono: confirmado em todos os 89 golpes de perto identificados até aqui; os 5 respingos de ácido tinham causador diferente.
- Novos pares confirmados: Bile Spewer MK2 + `0xf25abcdd`; Stalker (`F540CA9D9D4A422E`) + `0x6d29c458` (golpes de 2,0 a 4,3 m; três acima de 3 m ficaram sem redução na 0.17.1); Hulk Bruiser (`137988CEA16458F7`) + causa zero (1,4–1,5 m; tronco 54→37, cabeça original).

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas, incluindo causador ≠ dono recusado e par do cuspidor aceito. Em partida: golpe de perto do cuspidor reduzido, cuspe de ácido original.
