# Validação da 0.16.0

## Alterações

Somente a coleta de dados mudou; regras, causas aceitas e escritas de dano são as da 0.15.0.

- Novo módulo `native/damage_origin.c`: tipo do atacante pelo descritor do gerenciador de vida (`game+0x3326688`, hash `+0x1030`, descritores `+0x1048`), a mesma chave de `src/source_names.lua`. Diagnóstico da falha da 0.15.0: o mapa de entidades (`+0xf1aeb0`/`+0xf32f18`) devolve outro tipo (ex.: `DEFE062C2567C23D`, `1D4595328B92326A`), ausente do catálogo inteiro de 724 tipos da referência.
- Posição por unidade no registro do executável (`exe+0x1a100f0`, contagem `+0x98`, gerações `+0xa0`, objetos `+0x88`), geração de 8 bits relida, acessor `exe+0x2bd870` conferido (`48 8d 41 60 c3`) antes e depois da leitura. Distância euclidiana atacante–personagem local.
- Ligação preparo→evento pela chave de 13 palavras, fila própria de 64 entradas com expiração de 1 s; correspondência múltipla é consumida como ambígua.
- Resumo de 128 combinações tipo/elemento/causa/produtor/atacante com dano, distância e regiões; alimentado por todos os eventos locais, independente das cotas.
- Lua: `Origem do impacto` estendida, `Coleta de origem` e `Resumo de causa` a cada 10 s. Estrutura FFI renomeada para `LobaoArmorCombatSampleV2` (464 bytes) com conferência de tamanho.
- Analisador: `eventos_com_origem` (junção pela sequência) e `resumo_causas`.

Referências de offsets: SkyeShade/HD2Runtime `domains/event_natives.lua` (`health`, `engine.units`, `sceneGraphMethod`) e `runtime/event_world.lua` (`entity_state`, `unit_position`, `type_info`), mesmo `game.dll`/`helldivers2.exe` já exigidos pelo mod.

## Verificação realizada

- `python build_bridge.py --test`: suíte nativa completa aprovada, incluindo `tests/origin_test.c` (descritor de vida, entidade divergente, índice fora de `live`, geração errada, índice fora da contagem, acessor alterado, posição NaN, distância 5 m, ligação única/ambígua/expirada/sobrescrita, 128 causas e excedente).
- Capturas reais de corpo a corpo: 90 eventos por captura ligados exatamente ao preparo, zero ambíguos; resumo com causa, produtor `0x7d247e`, conhecida e reduzida; reduções idênticas à 0.15.0.
- `python tests/run_actor.py --lua-dll …`: LuaJIT com a DLL real (novas exportações vazias), linhas de log formatadas e analisador lendo o log gerado.
- Analisador sobre o log real da 0.15.0: 223 registros brutos preservados.

## Limites em partida

Não instalado nem testado em partida. Confirmar: nomes resolvidos para inimigos comuns (esperado `conscript_*`, `berserker_*`, `cyborg_*` etc.), distância plausível em golpes (≈1–4 m) e tiros, ligação com produtores `0x7d247e`/`0x13ad4ed`, e custo de desempenho com muitos impactos. Tipos sem nome no catálogo continuam aparecendo apenas em hexadecimal.
