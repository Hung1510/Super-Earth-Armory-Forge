#include "armor_equipment.h"
#undef NDEBUG
#include <assert.h>
#include <string.h>
#include <stdio.h>
#define BASE UINT64_C(0x1000000000)
static unsigned char profile[0x160], user[0xb3a0], players[0x2d204];
static unsigned char catalog[12], kit[64], bodies[24], pieces[13*96], array[16], other_kit[64];
static void put32(unsigned char *data,size_t at,uint32_t value) { memcpy(data+at,&value,4); }
static void put64(unsigned char *data,size_t at,uint64_t value) { memcpy(data+at,&value,8); }
static int fail_piece, change_selection;
void ArmorEquipmentFixtureWeight(uint32_t weight) {
    put32(pieces,16,weight); put32(pieces,96+16,weight);
}
void ArmorEquipmentFixtureDuplicate(int duplicate) {
    put32(catalog,8,2); put64(array,8,0x900004); put32(other_kit,0,duplicate ? 123 : 321);
}
void ArmorEquipmentFixtureMixed(uint32_t main, uint32_t secondary) {
    put64(bodies,16,13);
    for (unsigned i=0;i<13;++i) put32(pieces,i*96+16,i ? main : secondary);
}
void ArmorEquipmentFixtureSelect(uint32_t id) {
    put32(profile,0x158,id); put32(players,0x38+0x12c,id); put32(kit,0,id);
}
int ArmorEquipmentFixtureRead(uintptr_t at,void *out,size_t size) {
    struct Range { uintptr_t at; unsigned char *data; size_t size; } ranges[]={
        {0x100000,profile,sizeof(profile)}, {0x200000,user,sizeof(user)}, {0x300000,players,sizeof(players)},
        {0x400000,catalog,sizeof(catalog)}, {0x500004,kit,sizeof(kit)}, {0x600000,bodies,sizeof(bodies)},
        {0x700000,pieces,sizeof(pieces)}, {0x800000,array,sizeof(array)}, {0x900004,other_kit,sizeof(other_kit)}};
    uintptr_t value=0;
    if (at==BASE+0x347cdd8) value=0x100000;
    else if (at==BASE+0x347cef0) value=0x200000;
    else if (at==BASE+0x347ce50) value=0x300000;
    else if (at==BASE+0x33264f8) value=0x400000;
    if (value) { if (size!=8) return 0; memcpy(out,&value,8); return 1; }
    if (fail_piece && at>=0x700000 && at<0x700000+sizeof(pieces)) return 0;
    if (change_selection && at==0x100000+0x158) put32(profile,0x158,999);
    for (unsigned i=0;i<sizeof(ranges)/sizeof(ranges[0]);++i) {
        if (at>=ranges[i].at && at-ranges[i].at<=ranges[i].size
            && size<=ranges[i].size-(at-ranges[i].at)) {
            memcpy(out,ranges[i].data+at-ranges[i].at,size); return 1;
        }
    }
    return 0;
}
void ArmorEquipmentFixtureReset(void) {
    memset(profile,0,sizeof(profile)); memset(user,0,sizeof(user)); memset(players,0,sizeof(players));
    memset(kit,0,sizeof(kit)); memset(bodies,0,sizeof(bodies)); memset(pieces,0,sizeof(pieces));
    fail_piece=change_selection=0;
    put32(profile,0x158,123); put64(user,0xb398,456); put64(players,0,456);
    put32(players,0x2d200,1); put32(players,0x38+0x12c,123);
    put64(catalog,0,0x800000); put32(catalog,8,1); put64(array,0,0x500004);
    put32(kit,0,123); put64(kit,48,0x600000); put64(kit,56,1);
    put64(bodies,8,0x700000); put64(bodies,16,2);
    put32(pieces,16,2); put32(pieces,96+16,2);
}
void ArmorEquipmentTests(void) {
    ArmorEquipment out; ArmorEquipmentCache cache={0};
    ArmorEquipmentFixtureReset();
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.id==123 && out.weight==2);
    assert(cache.kit==0x500004);
    put32(pieces,16,1); put32(pieces,96+16,1);
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.weight==1);
    put32(pieces,16,0); put32(pieces,96+16,0);
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.weight==0);
    put32(pieces,96+16,2);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && !cache.kit);
    for (uint32_t main=0;main<3;++main) for (uint32_t secondary=0;secondary<3;++secondary) {
        ArmorEquipmentFixtureReset(); ArmorEquipmentFixtureMixed(main,secondary);
        assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.weight==main);
    }
    ArmorEquipmentFixtureReset(); ArmorEquipmentFixtureMixed(2,1);
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.weight==2);
    ArmorEquipmentFixtureSelect(321); ArmorEquipmentFixtureMixed(0,1);
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.id==321 && out.weight==0);
    ArmorEquipmentFixtureSelect(456); ArmorEquipmentFixtureMixed(1,2);
    assert(ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && out.id==456 && out.weight==1);
    put64(bodies,16,3); put32(pieces,16,0); put32(pieces,96+16,1); put32(pieces,192+16,2);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out) && !cache.kit);
    ArmorEquipmentFixtureReset(); fail_piece=1;
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset(); change_selection=1;
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset(); put32(players,0x38+0x12c,321);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset(); put32(kit,40,1);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset(); put64(kit,56,9);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset(); put32(pieces,16,3);
    assert(!ArmorEquipmentRead(BASE,ArmorEquipmentFixtureRead,&cache,&out));
    ArmorEquipmentFixtureReset();
    puts("Equipamento aprovado: 3 categorias, pesos mistos com maioria estrita, troca de armadura e cache, empates e dados invalidos recusados.");
}
