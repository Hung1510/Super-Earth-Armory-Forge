local i18n=assert(loadfile(HAP_ROOT..'/src/i18n.lua'))()
assert(i18n.index(nil)==1 and i18n.index('2')==1 and i18n.index(0)==1 and i18n.index(4)==1)
assert(i18n.index(1.5)==1 and i18n.index(0/0)==1)
local keys={}
for key in pairs(i18n.get(1)) do keys[#keys+1]=key end
local function chars(text) local _,n=text:gsub('[\128-\191]','');return #text-n end
for language=1,3 do
    assert(i18n.index(language)==language)
    local row=i18n.get(language)
    for _,key in ipairs(keys) do
        assert(type(row[key])==type(i18n.get(1)[key]),'Tradução ausente: '..key)
        if type(row[key])=='string' then
            assert(row[key]~='')
            if key:find('_label$') then assert(chars(row[key])<=64) end
            if key:find('_description$') then assert(chars(row[key])<=400) end
        end
    end
    for weight=0,2 do
        assert(type(row.armor_names[weight])=='string' and type(row.armor_regions[weight])=='string')
        if weight<2 then assert(row.armor_regions[weight]:find('AV2',1,true)) end
    end
    assert(row.armor_regions[2]:find('AV3',1,true) and row.helmet_head:find('AV3',1,true))
    assert(not row.armor_regions[2]:find('AV4',1,true))
    assert(row.heavy_regions:find('AV4',1,true) and row.heavy_speed:find('-10%',1,true))
    assert(row.ergonomics_description:find('-10%',1,true))
    assert(row.armor_regions[1]:find('AV3',1,true))
    assert(row.armor_regions[0]:find('AV1',1,true))
    assert(chars(i18n.choices[language])<=48)
end
assert(i18n.get(nil)==i18n.get(1) and i18n.get(99)==i18n.get(1))
print('Idiomas aprovados: inglês padrão, seleção inválida recusada, três traduções completas e limites do menu preservados.')
