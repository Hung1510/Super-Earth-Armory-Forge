local source = assert(io.open(HAP_ROOT..'/src/actor_addon.lua','rb')):read('*a')
local function fixture(result,initial_language,menu_version)
    local env, notes = {}, {}
    setmetatable(env,{__index=_G})
    env._G = env
    local now, enabled, detached, calls, saved, registered = 0,false,false,0,nil,0
    local protected, saved_protection,saved_descriptions=false,nil,nil
    local heavy,saved_profiles,profiles=false,nil,nil
    local equipped={valid=1,armor_id=123,weight=2}
    local ui_active
    local saved_language,ui_language=initial_language,nil
    local saved_feedback,drawn,closed=nil,0,0
    local specs={}
    local stats = {slot_protection=4,init_seen=0,apply_seen=0,captured=0,dropped=0,read_failed=0,
        stage=0,victim=0,zone=0,source_kind=0,damage=0,protection_active=0}
    local detail = {local_avatar=71,local_init_seen=0,local_apply_seen=0,late_seen=0,local_late_seen=0,
        local_captured=0,local_read_failed=0,region=0,source_kind=0,parent_return_rva=0,sample_avatar=0,
        penetration={0,0,0,0},raw_damage=0,multiplier=0}
    local refreshed = 0
    local api = {
        heavy_step=function(wanted,id) if wanted then assert(id==equipped.armor_id) end;heavy=wanted;return 1 end,
        profile_step=function() return 1 end,
        armor_step=function(id,reinforced) if id~=0 then assert(id==equipped.armor_id) end;heavy=protected and id~=0 and equipped.weight==2 and reinforced;return 1 end,
        equipped=function() return equipped end,
        load_profiles=function() return saved_profiles end,
        save_profiles=function(data) saved_profiles=data;return true end,
        movement_stats=function() return {active=0,reason=1,avatar=0,record=0,before=1,expected=1,observed=1,applied=0,restored=0,refused=0} end,
        swim_step=function() return 1 end,
        swim_stats=function() return {reason=1,weight=2,active=0,refused=0,before=5,expected=5,observed=5,applied=0,restored=0} end,
        handling=function() return {reason=1,rows={}} end,
        combat=function() return nil end,
        ergo_restore=function() return 1 end,
        now=function() return now end,install=function() return result end,
        enable=function(v) enabled=v end,detach=function() detached=true;return 1 end,
        protect=function(v) protected=v end,
        melee_stats=function() return {prepared=0,rejected=0,matched=0,ambiguous=0,unknown=0,applied=0,refused=0,
            victim=0,cause=0,region=0,armor_id=0,weight=2,before=0,after=0,reason=0,keep_percent=100,collider=0,reinforced=0} end,
        effect=function() return {enabled=protected and 1 or 0,applied=0,blocked=0,reduced=0,refused=0,
            victim=0,region=0,before=0,after=0,reason=0} end,
        stats=function() return stats end,detail=function() return detail end,
        refresh_local=function() refreshed=refreshed+1 end,
        sampling=function() return {quota_avatar=71,projectile_seen=1,other_seen=70,
            projectile_captured=1,other_captured=64,projectile_remaining=63,other_remaining=0} end,
        prediction=function() return {rebuilt=1,rejected=0,matched=1,unmatched=0,ambiguous=0,
            victim=71,region=2854072496,damage=23,penetration={2,2,1,0},selected=2} end,
        decision=function() return {evaluated=1,unavailable=0,blocked=1,reduced=0,original=0,victim=71,
            region=2854072496,armor_id=123,weight=2,damage=23,projected=0,rule=1,penetration=2,factor=0} end
    }
    env.HAPBridge = {new=function(_,mode) assert(mode=='actor');return api end}
    env.HAPI18n=assert(loadfile(HAP_ROOT..'/src/i18n.lua'))()
    env.HAPProfiles=assert(loadfile(HAP_ROOT..'/src/profiles.lua'))()
    local before,after,draws=0,0,0
    local presentation={
        before_ui=function() end,
        ergo_before=function() before=before+1 end,
        ergo_after=function(wanted) after=after+1;assert(wanted==enabled) end,
        swim_after=function(wanted) assert(type(wanted)=='boolean') end,
        step=function(sr,now,visual,protection,ergonomics,language,swimming,descriptions)
            draws=draws+1;ui_active=visual and descriptions;ui_language=language end,close=function() end}
    env.HAPAlerts={new=function() return {before_ui=function() end,close=function() end,step=function() end} end}
    local fed=0
    api.totals=function() return {sequence=0,shots_blocked=0,shots_reduced=0,shot_prevented=0,melee_reduced=0,melee_prevented=0,
        last_kind=0,last_prevented=0,mission=0,session=0} end
    env.HAPFeedback={part=function() return 'torso' end,new=function() return {before_ui=function() end,
        update=function(_,t) assert(type(t)=='table');fed=fed+1 end,draw=function() drawn=drawn+1 end,
        close=function() closed=closed+1 end} end}
    env.HAPPresentation={new=function(_,_,settings) profiles=settings;return presentation end}
    env.CowboyBingusModLoader={open_log=function() return {
        write=function(_,s) notes[#notes+1]=s end,flush=function() end} end}
    env.ModOptionsMenu={api=1,version=menu_version or 2,register_option=function(key,o)
        registered=registered+1;assert(o.mod=='Armor Reimagined');specs[key]=o
        assert(key~='lobao.armor_probe.heavy_av4')
        if key=='lobao.armor_probe.language' then
            assert(o.default==1 and o.type=='choice' and #o.choices==3)
        elseif key=='lobao.armor_probe.feedback' then
            assert(o.default==true and o.type=='toggle')
        elseif key=='lobao.armor_probe.angled_plates' then
            assert(o.default==false and o.type=='toggle')
        elseif key=='lobao.armor_probe.arm_gaps' then
            assert(o.default==true and o.type=='toggle')
        else error('Opção inesperada no menu: '..key) end
        local function resolve(value) return type(value)=='function' and value() or value end
        assert(type(resolve(o.label))=='string' and type(resolve(o.description))=='string')
        return true end,
        get=function(key)
            assert(key~='lobao.armor_probe.heavy_av4')
            if key=='lobao.armor_probe.language' then return saved_language end
            if key=='lobao.armor_probe.feedback' then return saved_feedback end
            if key=='lobao.armor_probe.apply_protection' then return saved_protection end
            if key=='lobao.armor_probe.descriptions' then return saved_descriptions end
            return saved
        end}
    env.update=function(a,b)
        calls=calls+1
        if result==1 and not detached then assert(after==calls,'Ergonomia deve ser aplicada antes da atualização anterior') end
        return a,b
    end
    assert(setfenv(assert(loadstring(source)),env))()
    return {env=env,stats=stats,detail=detail,api=api,notes=notes,
        tick=function(value,protection_value,descriptions_value,language_value,heavy_value)
            now=now+1001;saved=value;saved_protection=protection_value;saved_descriptions=descriptions_value
            if language_value~=nil then saved_language=language_value end
            if heavy_value~=nil then assert(profiles.choose(123,heavy_value)) end
            local a,b=env.update('primeiro','segundo');assert(a=='primeiro' and b=='segundo')
        end,
        state=function() return enabled,detached,calls,registered end,
        refreshed=function() return refreshed end,protected=function() return protected end,
        heavy=function() return heavy end,
        feedback=function(value) saved_feedback=value end,feedback_calls=function() return drawn,closed,fed end,
        ui_active=function() return ui_active end,ui_language=function() return ui_language end,specs=specs,
        presentation=presentation,equipped=equipped,profiles=function() return profiles end}
end
local quiet=fixture(1)
quiet.tick(nil);quiet.stats.init_seen=5;quiet.stats.apply_seen=5;quiet.tick(nil)
-- PT-BR: Modo normal: sem linhas técnicas por segundo; só resumos e mudanças de estado.
-- EN: Normal mode: no per-second technical lines; only summaries and state changes.
assert(not table.concat(quiet.notes):find('Inicialização=',1,true) and not table.concat(quiet.notes):find('Reconstruções=',1,true))
assert(not table.concat(quiet.notes):find('Diagnóstico detalhado ligado',1,true))
local good=fixture(1)
good.api.diagnostics_requested=function() return true end
good.api.diagnostics=function() end
good.tick(nil)
local enabled,detached,calls,registered=good.state()
assert(enabled and not detached and calls==1 and registered==4 and good.protected() and not good.heavy())
assert(good.ui_language()==1 and good.specs['lobao.armor_probe.language'].label()=='Language / Idioma')
assert(good.specs['lobao.armor_probe.feedback'].label()=='On-screen armor feedback')
for key in pairs(good.specs) do assert(key=='lobao.armor_probe.language' or key=='lobao.armor_probe.feedback' or key=='lobao.armor_probe.angled_plates' or key=='lobao.armor_probe.arm_gaps','Opção inesperada: '..key) end
assert(table.concat(good.notes):find('Frestas nos braços: ligadas',1,true))
-- PT-BR: Instalação recusada: o log mostra o motivo sem o caminho interno do script (arquivo.lua:linha:).
-- EN: Refused installation: the log shows the reason without the script's internal path (file.lua:line:).
do
    local refused=fixture(42);refused.tick(nil)
    local text=table.concat(refused.notes)
    assert(text:find('Causa provável',1,true) and text:find('O que fazer',1,true))
    assert(text:find('Experimento desligado: Instalação recusada; código 42',1,true) and not text:find('armor_probe',1,true)
        and not text:find('%.lua:%d+:'))
end
-- PT-BR: Erro inesperado: fica só arquivo e linha, sem as pastas.
-- EN: Unexpected error: only file and line remain, without the folders.
do
    local broken=fixture(1)
    broken.api.stats=function() error('valor nulo') end
    broken.tick(nil)
    local text=table.concat(broken.notes)
    local line=text:match('Experimento desligado: ([^\n]*)')
    assert(line and not line:find('/',1,true) and line:find('valor nulo',1,true),tostring(line))
end
assert(table.concat(good.notes):find('Placas inclinadas: desligadas',1,true))
-- PT-BR: Aviso na tela ligado por padrão; desligado no menu fecha o desenho mas continua contando a missão.
-- EN: On-screen feedback on by default; turning it off in the menu closes drawing but keeps counting the mission.
local drawn,closed,fed=good.feedback_calls();assert(drawn==1 and closed==0 and fed==1)
assert(table.concat(good.notes):find('Aviso de proteção na tela: ligado',1,true))
good.feedback(false);good.tick(nil);drawn,closed,fed=good.feedback_calls();assert(drawn==1 and closed==1 and fed==2)
assert(table.concat(good.notes):find('Aviso de proteção na tela: desligado',1,true))
good.feedback(nil)
assert(table.concat(good.notes):find('Diagnóstico detalhado ligado',1,true))
assert(good.refreshed()==2)
good.presentation.ergo_sample={record=0x600000,weight=0,reason=0,weapon='test_primary',before=65,
    expected=71.5,observed=71.5,writes=2,verified=2,restores=1,restore_refused=0,
    protection_windows=3,protection_failed=0}
good.tick(nil)
assert(table.concat(good.notes):find('categoria=leve; base=65; previsto=71.5; relido=71.5',1,true))
local count_before=#good.notes
good.tick(nil)
assert(#good.notes==count_before)
good.presentation.ergo_sample.reason=6
count_before=#good.notes;good.tick(nil)
assert(#good.notes==count_before)
good.presentation.ergo_sample=nil
good.stats.init_seen=1;good.stats.apply_seen=1;good.stats.captured=2
good.tick(nil)
assert(table.concat(good.notes):find('eventos alterados=0',1,true))
good.detail.local_late_seen=1;good.detail.local_captured=1;good.detail.region=2854072496
good.detail.penetration={2,2,1,0}
good.tick(nil)
assert(table.concat(good.notes):find('AP na preparação=[2,2,1,0]',1,true))
assert(table.concat(good.notes):find('tiros restantes=63; outros restantes=0',1,true))
assert(table.concat(good.notes):find('eventos associados=1',1,true))
assert(table.concat(good.notes):find('AP selecionada na cópia=2',1,true))
assert(table.concat(good.notes):find('penetração final ainda não confirmada',1,true))
assert(table.concat(good.notes):find('categoria=pesada',1,true))
assert(table.concat(good.notes):find('decisão=bloquear; dano original=23; dano projetado=0',1,true))
-- PT-BR: Valores antigos de opções removidas são ignorados; proteção, ergonomia e descrições continuam ligadas.
-- EN: Values of removed options are ignored; protection, ergonomics and descriptions stay on.
local frozen=good.refreshed()
good.tick(false,false,false)
assert(good.state() and good.protected() and good.ui_active() and good.refreshed()>frozen)
good.tick(true,true,true,2)
assert(good.ui_language()==2 and good.protected())
assert(good.specs['lobao.armor_probe.language'].description()==good.env.HAPI18n.get(2).language_description)
good.tick(true,true,true,3)
assert(good.ui_language()==3 and good.protected())
assert(good.specs['lobao.armor_probe.language'].description()==good.env.HAPI18n.get(3).language_description)
good.tick(true,true,true,99)
assert(good.ui_language()==1 and good.protected())
good.tick(true,true,true,1,true);assert(good.heavy())
good.equipped.armor_id=124;good.tick(true,true);assert(not good.heavy())
assert(good.profiles().get(123) and not good.profiles().get(124))
good.equipped.armor_id=123;good.tick(true,true);assert(good.heavy())
good.tick(true,false);assert(good.heavy())
good.tick(true,true,true,1,false);assert(not good.heavy())
local traced=fixture(1)
traced.env.HAP_SOURCE_NAMES={['856E9710E45E760F']='conscript_jump_melee'}
local queue={}
local function sample(stage,sequence,flags)
    return {stage=stage,kind=6,victim=71,parent=stage==1 and 0x12a2cf7 or 0,extra_valid=0,producer=0x7d247e,
        dealer=552,owner=552,data='00',extra='00',dealer_type='DEFE062C2567C23D',owner_type='DEFE062C2567C23D',
        origin={sequence=sequence,kind=6,victim=71,parent=0,producer=0x7d247e,cause=0x51ba8f74,flags=flags,
            region=0xaa1db0b0,dealer=552,owner=552,dealer_unit=4194330,victim_unit=12,distance=1.75,
            dealer_health_type='856E9710E45E760F',owner_health_type='856E9710E45E760F'}}
end
queue[1]=sample(1,41,4+8+16+32+64+128);queue[2]=sample(2,41,4+8+16+32+64+128+256)
queue[3]=sample(2,0,128+512)
traced.api.combat=function() return table.remove(queue,1) end
local cause_rows={{kind=6,element=0,cause=0x51ba8f74,producer=0x7d247e,count=3,linked=2,known=3,reduced=2,
    damage_min=33,damage_max=40,damage_sum=106,distance_count=2,distance_min=1.25,distance_max=2.25,distance_sum=3.5,
    regions=17,dealer_type='856E9710E45E760F'},
    {kind=6,element=0,cause=0,producer=0,count=1,linked=0,known=0,reduced=0,damage_min=56,damage_max=56,
    damage_sum=56,distance_count=0,distance_min=0,distance_max=0,distance_sum=0,regions=0,dealer_type='0000000000000000'}}
local origin_version=1
traced.api.origin_stats=function() return {built=5,linked=2,ambiguous=1,unlinked=1,link_busy=0,recorded=4,overflow=0,version=origin_version} end
traced.api.cause=function(index) return cause_rows[index+1] end
local diagnostics_set
traced.api.diagnostics_requested=function() return true end
traced.api.diagnostics=function(value) diagnostics_set=value end
traced.tick(nil)
local trace=table.concat(traced.notes,'\n')
assert(diagnostics_set==true and trace:find('Diagnóstico detalhado ligado',1,true))
assert(trace:find('Origem do impacto: etapa=1; tipo=6; avatar=71; sequência=41; ligado=0; ambíguo=0; causa=0x51ba8f74; produtor=0x007d247e; região=0xaa1db0b0; causador=552; tipo causador=856E9710E45E760F; nome causador=conscript_jump_melee',1,true))
assert(trace:find('sequência=41; ligado=1; ambíguo=0',1,true) and trace:find('distância=1.75 m; alcance do golpe=indisponível; via rede: entidade=0, tipo=não resolvido, nome=não identificado, distância=indisponível; marcas=0x01fc',1,true))
assert(trace:find('Posições do impacto: sequência=41; atacante=indisponível; você=indisponível; via rede=indisponível; ponto do golpe até você=indisponível',1,true))
assert(trace:find('sequência=0; ligado=0; ambíguo=1',1,true) and trace:find('tipo causador=não resolvido; nome causador=não identificado',1,true))
assert(trace:find('distância=indisponível; alcance do golpe=indisponível; via rede: entidade=0, tipo=não resolvido, nome=não identificado, distância=indisponível; marcas=0x0280',1,true))
assert(trace:find('Coleta de origem: impactos montados=5; eventos ligados=2; ambíguos=1; sem ligação=1',1,true))
assert(trace:find('Resumo de causa: tipo=6; elemento=0; causa=0x51ba8f74; produtor=0x007d247e; tipo causador=856E9710E45E760F; nome causador=conscript_jump_melee; eventos=3; ligados=2; na lista corpo a corpo=3; reduzidos=2; dano mín=33; médio=35.3; máx=40; distância mín=1.25 m; média=1.75 m; máx=2.25 m; amostras de distância=2; regiões=0x11',1,true))
assert(trace:find('causa=0x00000000; produtor=0x00000000; tipo causador=não resolvido',1,true))
local summary_lines=select(2,trace:gsub('Resumo de causa:',''))
traced.tick(nil);assert(select(2,table.concat(traced.notes,'\n'):gsub('Resumo de causa:',''))==summary_lines)
for _=1,10 do traced.tick(nil) end
assert(select(2,table.concat(traced.notes,'\n'):gsub('Resumo de causa:',''))==summary_lines)
cause_rows[1].count=4;origin_version=2
for _=1,10 do traced.tick(nil) end
trace=table.concat(traced.notes,'\n')
assert(select(2,trace:gsub('Resumo de causa:',''))==summary_lines+1)
local exported=io.open(HAP_ROOT..'/native-build/origin-log-fixture.log','wb')
if exported then exported:write(trace);exported:close() end
local saved_locale=fixture(1,3)
saved_locale.tick(nil)
assert(saved_locale.ui_language()==3)
assert(saved_locale.specs['lobao.armor_probe.language'].description()==saved_locale.env.HAPI18n.get(3).language_description)
local legacy=fixture(1,2,1)
legacy.tick(nil)
assert(legacy.ui_language()==2 and legacy.specs['lobao.armor_probe.language'].label=='Language / Idioma')
local denied=fixture(16)
denied.tick(nil)
enabled,detached,calls=denied.state()
assert(not enabled and detached and calls==1)
assert(table.concat(denied.notes):find('código 16',1,true))
local waiting=fixture(-1)
waiting.tick(nil)
assert(not waiting.state())
assert(table.concat(waiting.notes):find('aguardando',1,true))
print('Addon aprovado: inglês padrão, idioma salvo, seleção em execução, menu traduzido sem duplicar categoria, proteção independente e retornos preservados.')
