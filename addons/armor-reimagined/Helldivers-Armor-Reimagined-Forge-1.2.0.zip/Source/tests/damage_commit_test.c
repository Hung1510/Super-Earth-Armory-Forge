#include "damage_commit.h"
#include <windows.h>
#undef NDEBUG
#include <assert.h>
#include <string.h>
#include <stdio.h>
void ArmorDamageCommitTests(void) {
    unsigned char *event=VirtualAlloc(NULL,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
    assert(event);
    unsigned char expected[0x70]={0}, changed[0x70];
    uint32_t damage=100;
    memcpy(expected+0x2c,&damage,4); memcpy(event,expected,sizeof(expected));
    assert(ArmorDamageCommit((uintptr_t)event,expected,65));
    memcpy(changed,expected,sizeof(changed)); damage=65; memcpy(changed+0x2c,&damage,4);
    assert(!memcmp(event,changed,sizeof(changed)));
    assert(!ArmorDamageCommit((uintptr_t)event,expected,0));
    memcpy(expected,changed,sizeof(expected)); event[0x20]=1;
    assert(!ArmorDamageCommit((uintptr_t)event,expected,0));
    memcpy(event,expected,sizeof(expected));
    DWORD old;
    assert(VirtualProtect(event,4096,PAGE_READONLY,&old));
    assert(!ArmorDamageCommit((uintptr_t)event,expected,0));
    extern int ArmorExchangeDamage(void *,uint32_t,uint32_t);
    assert(!ArmorExchangeDamage(event+0x2c,0,65));
    assert(VirtualProtect(event,4096,PAGE_READWRITE,&old));
    assert(!ArmorDamageCommit((uintptr_t)event,expected,66));
    expected[4]=1; memcpy(event,expected,sizeof(expected));
    assert(!ArmorDamageCommit((uintptr_t)event,expected,0));
    assert(!ArmorDamageCommit((uintptr_t)event+1,expected,0));
    expected[4]=6;damage=40;memcpy(expected+0x2c,&damage,4);
    uint32_t cause=0x11c4b1a5;memcpy(expected+0x60,&cause,4);memcpy(event,expected,sizeof(expected));
    assert(!ArmorDamageCommit((uintptr_t)event,expected,28));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,20,0));
    assert(VirtualProtect(event,4096,PAGE_READONLY,&old));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    assert(VirtualProtect(event,4096,PAGE_READWRITE,&old));
    event[0x20]^=1;assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));event[0x20]^=1;
    assert(ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    memcpy(changed,expected,sizeof(changed));damage=28;memcpy(changed+0x2c,&damage,4);
    assert(!memcmp(event,changed,sizeof(changed)));
    memcpy(event,expected,sizeof(expected));expected[8]=1;event[8]=1;
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    expected[8]=0;expected[4]=4;memcpy(event,expected,sizeof(expected));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    expected[4]=6;cause=0x6644dc22;memcpy(expected+0x60,&cause,4);memcpy(event,expected,sizeof(expected));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    // PT-BR: Causa fora da lista só é escrita com proximidade confirmada e elemento físico.
    // EN: An unlisted cause is written only with confirmed proximity and a physical element.
    cause=0xab3862b0;memcpy(expected+0x60,&cause,4);memcpy(event,expected,sizeof(expected));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,0));
    expected[8]=2;memcpy(event,expected,sizeof(expected));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,28,1));
    expected[8]=0;memcpy(event,expected,sizeof(expected));
    assert(!ArmorMeleeDamageCommit((uintptr_t)event,expected,27,1));
    assert(ArmorMeleeDamageCommit((uintptr_t)event,expected,28,1));
    assert(VirtualFree(event,0,MEM_RELEASE));
    puts("Escrita de dano aprovada: somente 4 bytes alterados; evento divergente, aumento, tipo errado e acesso recusado preservam dados.");
}
