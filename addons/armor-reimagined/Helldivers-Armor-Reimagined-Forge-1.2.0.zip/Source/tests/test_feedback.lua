local env={};setmetatable(env,{__index=_G});env._G=env
env.HAPI18n=assert(loadfile(HAP_ROOT..'/src/i18n.lua'))()
local notes,draws,gui={},{},false
env.HAPSurface={new=function() local surface;surface={
    close=function() gui=false;surface.gui=nil end,
    valid=function() return gui end,
    bind=function() gui=true;surface.gui=true;return true end,
    sync=function(items) draws[#draws+1]=items;return true end
};return surface end}
local presentation={alert_fonts=function() return {font='f',atlas='a',material='m'} end}
local source=assert(io.open(HAP_ROOT..'/src/feedback.lua','rb')):read('*a')
local feedback_module=setfenv(assert(loadstring(source)),env)()
local feedback=feedback_module.new({},function(s) notes[#notes+1]=s end,presentation)
local sr={Gui={resolution=function() return 1920,1080 end},Application={main_world=function() return 'mission' end}}
local t={sequence=0,shots_blocked=0,shots_reduced=0,shot_prevented=0,melee_reduced=0,melee_prevented=0,last_kind=0,last_prevented=0,mission=0,session=0}
local function event(kind,saved)
    t.sequence=t.sequence+1;t.last_kind=kind;t.last_prevented=saved
    if kind==1 then t.shots_blocked=t.shots_blocked+1;t.shot_prevented=t.shot_prevented+saved
    elseif kind==2 or kind==4 then t.shots_reduced=t.shots_reduced+1;t.shot_prevented=t.shot_prevented+saved
    else t.melee_reduced=t.melee_reduced+1;t.melee_prevented=t.melee_prevented+saved end
end
local function copy() local c={} for k,v in pairs(t) do c[k]=v end return c end
local function part(id) for _,item in ipairs(draws[#draws] or {}) do if item.id==id then return item end end end
-- PT-BR: Eventos antes da missão entram na base e não aparecem no relatório.
-- EN: Events before the mission go into the baseline and do not show in the report.
event(1,40);feedback.update(0,copy());feedback.draw(sr,0,1);assert(not gui)
t.mission,t.session=1,777;feedback.update(100,copy());feedback.draw(sr,100,1);assert(not gui)
event(1,58);feedback.update(200,copy());feedback.draw(sr,200,1);assert(gui and part('flash').text=='BLOCKED')
feedback.draw(sr,1099,1);assert(gui);feedback.draw(sr,1100,1);assert(not gui)
event(2,20);feedback.update(2000,copy());feedback.draw(sr,2000,2);assert(part('flash').text=='ARMADURA -20')
-- PT-BR: Com a região conhecida, o aviso diz onde pegou.
-- EN: With a known region, the flash says where it landed.
t.last_region=0x64a3fa1d;event(1,10);feedback.update(2100,copy());feedback.draw(sr,2100,2);assert(part('flash').text=='BLOQUEADO | PERNAS')
t.last_region,t.last_collider=0x1880288e,0x03752c98;event(1,10);feedback.update(2150,copy());feedback.draw(sr,2150,2);assert(part('flash').text=='BLOQUEADO | OMBRO')
t.last_region,t.last_collider=0x87b05ff4,0x3ac8154a;event(2,5);feedback.update(2170,copy());feedback.draw(sr,2170,1);assert(part('flash').text=='ARMOR -5 | SHIN')
t.last_collider=nil
-- PT-BR: Fresta no braço da pesada: mostra o dano que passou, com a parte.
-- EN: Gap in a heavy arm: shows the damage that got through, with the part.
t.last_region,t.last_collider,t.last_after=0x1880288e,0x1ca2cd66,4;event(4,19);feedback.update(2180,copy());feedback.draw(sr,2180,2);assert(part('flash').text=='FRESTA +4 | ANTEBRAÇO')
t.last_collider,t.last_after=nil,nil
t.last_region=0x8c5570c9;event(2,7);feedback.update(2200,copy());feedback.draw(sr,2200,1);assert(part('flash').text=='ARMOR -7 | HEAD')
t.last_region=nil
event(3,13);feedback.update(3000,copy());feedback.draw(sr,3000,3);assert(part('flash').text=='ARMADURA -13')
-- PT-BR: Oscilação curta fora da missão não gera relatório; voltar mantém a base.
-- EN: A short flicker out of the mission does not report; returning keeps the baseline.
t.mission=0;feedback.update(4000,copy());feedback.update(6000,copy());assert(#notes==0)
t.mission=1;feedback.update(6500,copy());event(1,30);feedback.update(6600,copy())
-- PT-BR: Fim da missão: relatório após 3 s com só os eventos da missão.
-- EN: End of mission: report after 3 s with only the mission's events.
t.mission,t.session=0,0;feedback.update(10000,copy());feedback.update(12999,copy());assert(#notes==0)
feedback.update(13000,copy(),7);feedback.draw(sr,13000,1)
assert(notes[1]=='Relatório da missão: tiros bloqueados=4; tiros reduzidos=4; golpes reduzidos=1; dano evitado=172; tiros que passaram pelas frestas=0.')
-- PT-BR: Tela de estatísticas aberta (código 7): o relatório espera; depois precisa de 2 s de tela livre.
-- EN: Statistics screen open (code 7): the report waits; then it needs 2 s of free screen.
assert(not gui and feedback.waiting())
feedback.update(20000,copy(),7);feedback.draw(sr,20000,1);assert(not gui)
feedback.update(21000,copy(),0);feedback.draw(sr,21000,1);assert(not gui)
feedback.update(22000,copy(),13);feedback.update(22500,copy(),0);feedback.update(24000,copy(),0);feedback.draw(sr,24000,1);assert(not gui)
feedback.update(24500,copy(),0);feedback.draw(sr,24500,1)
assert(gui and not feedback.waiting())
assert(part('report_title').text=='ARMOR REPORT' and part('report_saved').text=='Damage prevented: 172')
assert(part('report_shots').text=='Shots blocked: 4   Shots reduced: 4' and part('report_melee').text=='Melee hits reduced: 1')
feedback.draw(sr,39499,1);assert(gui);feedback.draw(sr,39500,1);assert(not gui)
-- PT-BR: Missão sem proteção aplicada não mostra relatório.
-- EN: A mission without applied protection shows no report.
t.mission,t.session=1,778;feedback.update(40000,copy());t.mission,t.session=0,0;feedback.update(41000,copy(),0);feedback.update(44000,copy(),0)
local function mission_notes() local n=0 for _,s in ipairs(notes) do if s:find('Relatório da missão',1,true) then n=n+1 end end return n end
feedback.update(47000,copy(),0);feedback.draw(sr,47000,1);assert(not gui and mission_notes()==1 and not feedback.waiting())
-- PT-BR: Fim de missão em que a tela fica 0: sem estatísticas vistas, o relatório não sai antes de 90 s.
-- EN: Mission end where the screen stays 0: with no statistics seen, the report does not show before 90 s.
t.mission,t.session=1,783;feedback.update(50000,copy());event(1,7);feedback.update(50100,copy())
t.mission,t.session=0,0;feedback.update(51000,copy(),0);feedback.update(54000,copy(),0);feedback.update(60000,copy(),0)
feedback.draw(sr,60000,1);assert(not gui and feedback.waiting())
feedback.update(143999,copy(),0);assert(feedback.waiting());feedback.update(144000,copy(),0);feedback.draw(sr,144000,1);assert(gui)
feedback.close()
-- PT-BR: Ficar 3 minutos na tela de estatísticas não solta o relatório; ele sai 2 s depois de fechar.
-- EN: Staying 3 minutes on the statistics screen does not release the report; it shows 2 s after closing.
t.mission,t.session=1,555;feedback.update(400000,copy());event(1,30);feedback.update(400100,copy())
t.mission,t.session=0,0;feedback.update(401000,copy(),0);feedback.update(404000,copy(),0);assert(feedback.waiting())
feedback.update(405000,copy(),13);feedback.update(600000,copy(),13);feedback.draw(sr,600000,1);assert(not gui and feedback.waiting())
feedback.update(600500,copy(),0);feedback.update(602500,copy(),0);feedback.draw(sr,602500,1);assert(gui and not feedback.waiting())
feedback.draw(sr,617500,1);assert(not gui)
-- PT-BR: Sem código de tela, o relatório sai depois de 90 s; nova missão antes disso cancela a espera.
-- EN: Without a screen code, the report shows after 90 s; a new mission before that cancels the wait.
t.mission,t.session=1,780;feedback.update(150000,copy());event(2,5);feedback.update(150100,copy())
t.mission,t.session=0,0;feedback.update(151000,copy());feedback.update(154000,copy());assert(feedback.waiting())
feedback.update(243999,copy());feedback.draw(sr,243999,1);assert(not gui)
feedback.update(244000,copy());feedback.draw(sr,244000,1);assert(gui and part('report_shots').text=='Shots blocked: 0   Shots reduced: 1')
feedback.close()
t.mission,t.session=1,781;feedback.update(260000,copy());event(1,5);feedback.update(260100,copy())
t.mission,t.session=0,0;feedback.update(261000,copy(),5);feedback.update(264000,copy(),5);assert(feedback.waiting())
t.mission,t.session=1,782;feedback.update(265000,copy());assert(not feedback.waiting())
-- PT-BR: Relatório expandido: regiões, quem mais feriu (por tipo), morte e matador; só eventos da missão.
-- EN: Expanded report: regions, who hurt you most (by type), death and killer; only the mission's events.
HAP_SOURCE_NAMES={['C626D2BB495A202D']='Devastator',['A6A68D8AF177F3A1']='Berserker',['0000000000000000']='N/A'}
local function armor(rows,attackers,last)
    local r={regions={},attackers=attackers,last=last}
    for g=1,4 do local v=rows[g] or {0,0,0,0,0,0};r.regions[g]={hits=v[1],blocked=v[2],reduced=v[3],full=v[4],taken=v[5],prevented=v[6]} end
    return r
end
local base_armor=armor({{1,0,0,1,10,0}},{{type='C626D2BB495A202D',hits=1,taken=10,prevented=0}},{type='C626D2BB495A202D',sequence=1,avatar=50,region=0x8c5570c9,before=10,after=10,kind=1})
t.mission,t.session=1,790;feedback.update(280000,copy(),0,base_armor,50)
event(1,30);event(2,20)
local mid_armor=armor({{1,0,0,1,10,0},{3,1,1,1,70,50},{0,0,0,0,0,0},{2,0,1,1,40,9}},
    {{type='C626D2BB495A202D',hits=4,taken=90,prevented=40},{type='A6A68D8AF177F3A1',hits=2,taken=30,prevented=19},{type='0000000000000000',hits=1,taken=5,prevented=0}},
    {type='A6A68D8AF177F3A1',sequence=9,avatar=50,region=0xaa1db0b0,before=60,after=39,kind=2})
feedback.update(281000,copy(),0,mid_armor,50)
feedback.update(282000,copy(),0,mid_armor,nil)
feedback.update(283000,copy(),0,mid_armor,77)
t.mission,t.session=0,0;feedback.update(284000,copy(),0,mid_armor,nil);feedback.update(287000,copy(),0,mid_armor,nil);feedback.update(287500,copy(),13,mid_armor,nil)
feedback.update(288000,copy(),0,mid_armor,nil);feedback.update(290000,copy(),0,mid_armor,nil)
-- PT-BR: Desligado (padrão da 1.1.0): só as quatro linhas simples aparecem.
-- EN: Off (1.1.0 default): only the four simple lines are drawn.
assert(feedback_module.EXPANDED==false);feedback.draw(sr,290000,1)
assert(gui and part('report_saved') and part('report_region_2')==nil and part('report_top')==nil and part('report_killer')==nil)
feedback_module.EXPANDED=true;feedback.draw(sr,290000,1)
assert(gui and part('report_region_1')==nil and part('report_region_3')==nil)
assert(part('report_region_2').text=='Torso: 3 hits | 1 blocked | 1 reduced | 1 full')
assert(part('report_region_4').text=='Legs: 2 hits | 0 blocked | 1 reduced | 1 full')
assert(part('report_top').text=='Hurt you most:')
assert(part('report_attacker_1').text=='Devastator - 80 taken, 40 prevented')
assert(part('report_attacker_2').text=='Berserker - 30 taken, 19 prevented')
assert(part('report_attacker_3').text=='Unknown enemy - 5 taken, 0 prevented')
assert(part('report_deaths').text=='Deaths: 1')
assert(part('report_killer').text=='Killed by Berserker: 39 damage to the Torso (armor prevented 21)')
feedback.draw(sr,290001,2);assert(part('report_killer').text=='Morto por Berserker: 39 de dano em Tronco (armadura evitou 21)')
assert(table.concat(notes,'\n'):find('Relatório morte: mortes=1; último atacante=A6A68D8AF177F3A1',1,true))
feedback_module.EXPANDED=false
feedback.close()
-- PT-BR: Golpe antigo (mais de 3 s antes de cair) não vira matador; a morte ainda conta.
-- EN: An old hit (more than 3 s before falling) does not become the killer; the death still counts.
t.mission,t.session=1,791;feedback.update(300000,copy(),0,mid_armor,77);event(1,9);feedback.update(300100,copy(),0,mid_armor,77)
local late=armor({{0,0,0,0,0,0},{4,2,1,1,80,59}},mid_armor.attackers,{type='A6A68D8AF177F3A1',sequence=10,avatar=77,region=0xaa1db0b0,before=20,after=0,kind=1})
feedback.update(301000,copy(),0,late,77);feedback.update(306000,copy(),0,late,nil);feedback.update(320000,copy(),0,late,78)
t.mission,t.session=0,0;feedback.update(321000,copy(),0,late,nil);feedback.update(324000,copy(),0,late,nil)
feedback.update(324500,copy(),13,late,nil);feedback.update(325000,copy(),0,late,nil);feedback.update(327000,copy(),0,late,nil)
feedback_module.EXPANDED=true;feedback.draw(sr,327000,1);feedback_module.EXPANDED=false
assert(gui and part('report_deaths').text=='Deaths: 1' and part('report_killer')==nil)
feedback.close()
-- PT-BR: Recurso indisponível não quebra; fechar limpa tudo.
-- EN: Missing resources do not break; closing clears everything.
t.mission,t.session=1,779;feedback.update(270000,copy());event(1,10);feedback.update(270100,copy())
presentation.alert_fonts=function() return nil end;feedback.draw(sr,270100,1);assert(not gui)
presentation.alert_fonts=function() return {font='f',atlas='a',material='m'} end;feedback.draw(sr,270200,1);assert(gui)
feedback.close();assert(not gui);feedback.draw(sr,270300,1);assert(not gui)
print('Indicador e relatório aprovados: bloqueio/redução/golpe com texto e cor, expiração, base da missão, oscilação, espera da tela de estatísticas (abre/fecha e 2 s livre, 90 s de reserva), relatório só com eventos e três idiomas.')
