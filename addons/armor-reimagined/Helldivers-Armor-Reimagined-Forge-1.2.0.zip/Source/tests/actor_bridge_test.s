.text
.intel_syntax noprefix
.globl ArmorTestInitCall
.globl ArmorTestInitReturn
.seh_proc ArmorTestInitCall
ArmorTestInitCall:
    push r14
    .seh_pushreg r14
    sub rsp, 0x20
    .seh_stackalloc 0x20
    .seh_endprologue
    mov r14, rdx
    call [r8]
ArmorTestInitReturn:
    add rsp, 0x20
    pop r14
    ret
.seh_endproc

.globl ArmorTestLateCall
.globl ArmorTestLateReturn
.seh_proc ArmorTestLateCall
ArmorTestLateCall:
    push r14
    .seh_pushreg r14
    sub rsp, 0x60
    .seh_stackalloc 0x60
    .seh_endprologue
    mov r14, rdx
    call [r8]
ArmorTestLateReturn:
    add rsp, 0x60
    pop r14
    ret
.seh_endproc
.globl ArmorTestApplyCall
.globl ArmorTestApplyReturn
.seh_proc ArmorTestApplyCall
ArmorTestApplyCall:
    push r14
    .seh_pushreg r14
    sub rsp, 0x20
    .seh_stackalloc 0x20
    .seh_endprologue
    mov r14, rdx
    call [r8]
ArmorTestApplyReturn:
    add rsp, 0x20
    pop r14
    ret
.seh_endproc
