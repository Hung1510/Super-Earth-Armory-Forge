#include "private_session.h"
#include "runtime_fixture.h"
#include <stdio.h>
static unsigned char *context,*state,*engine,*lobby;
static const uintptr_t game=UINT64_C(0x1000000000);
static int read_session(uintptr_t at,void *out,size_t size) {
    if (at==game+0x347cef0 && size==8) {uintptr_t p=(uintptr_t)context;memcpy(out,&p,8);return 1;}
    if (at==game+0x3326340 && size==8) {uintptr_t p=(uintptr_t)state;memcpy(out,&p,8);return 1;}
    return ArmorRuntimeReadSelf(at,out,size);
}
void ArmorPrivateSessionTests(void) {
    context=VirtualAlloc(NULL,0x20000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    state=VirtualAlloc(NULL,0xad000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    engine=VirtualAlloc(NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    lobby=VirtualAlloc(NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    assert(context && state && engine && lobby);
    fixture_ptr(context,0xb398,900);fixture_ptr(context,0xb3a8,900);fixture_ptr(context,0xb390,123);
    fixture_ptr(context,0x1d470,(uintptr_t)engine);fixture_ptr(engine,0x10,(uintptr_t)lobby);
    fixture_u32(context,0x159b0+24,1);fixture_u32(lobby,0x118,3);fixture_ptr(lobby,0x120,12345);
    fixture_u32(state,0xac21c,4);
    for (unsigned guest=0;guest<2;guest++) {
        fixture_ptr(context,0xb398,900+guest);
        for (unsigned setting=0;setting<4;setting++) for (unsigned sos=0;sos<2;sos++) {
            fixture_u32(state,0xac550,setting);
            context[0x1d470+56+19*257]=(char)('0'+setting);
            context[0x1d470+56+8*257]=(char)('0'+sos);
            ArmorSessionRefresh(read_session,game);assert(ArmorSessionMission(read_session,game));
        }
        fixture_u32(context,0x171c8,1);assert(!ArmorSessionMission(read_session,game));fixture_u32(context,0x171c8,0);
        fixture_u32(context,0x159b0+28,1);assert(!ArmorSessionMission(read_session,game));fixture_u32(context,0x159b0+28,0);
        fixture_u32(state,0xac21c,3);assert(!ArmorSessionMission(read_session,game));fixture_u32(state,0xac21c,4);
        fixture_u32(lobby,0x118,2);assert(!ArmorSessionMission(read_session,game));fixture_u32(lobby,0x118,3);
        fixture_ptr(lobby,0x120,0);assert(!ArmorSessionMission(read_session,game));fixture_ptr(lobby,0x120,12345);
        fixture_ptr(context,0xb3a8,0);assert(!ArmorSessionMission(read_session,game));fixture_ptr(context,0xb3a8,900);
        fixture_ptr(context,0xb390,456);assert(!ArmorSessionMission(read_session,game));fixture_ptr(context,0xb390,123);
        ArmorSessionRefresh(read_session,game);assert(ArmorSessionMission(read_session,game));
    }
    Sleep(800);assert(!ArmorSessionMission(read_session,game));
    ArmorSessionRefresh(read_session,game);assert(ArmorSessionMission(read_session,game));
    fixture_ptr(context,0xb398,900);ArmorSessionRefresh(read_session,game);
    fixture_u32(context,0x159b0+24,0);assert(!ArmorSessionMission(read_session,game));
    for (unsigned i=0;i<4;i++) assert(VirtualFree(((void *[]){context,state,engine,lobby})[i],0,MEM_RELEASE));
    puts("Sessao aprovada: host/convidado, publico/privado/SOS permitidos; navio, transicao, join, host ausente, lobby invalido e cache vencido recusados.");
}
