#include "runtime_fixture.h"
#include "movement.h"
#include "armor_rules.h"
#include <stdio.h>
#include <math.h>
void ArmorMovementTests(void) {
    assert(sizeof(ArmorMovementStats)==48);
    OwnedFixture f;fixture_create(&f,0x34,0x14,0x38,0x48);
    for (unsigned i=0;i<5;i++) fixture_float(f.records,4*i,1);
    unsigned char original[0x34],remote[0x34];memcpy(original,f.records,0x34);
    memset(f.records+0x34,0x71,0x34);memcpy(remote,f.records+0x34,0x34);
    for (unsigned i=0;i<3000;i++) {
        assert(ArmorMovementApply(&f.local));
        assert(fabsf(fixture_value(f.records,4)-.9f)<.000001f);
        assert(ArmorMovementValid(71) && !ArmorMovementValid(72));
        assert(!memcmp(remote,f.records+0x34,0x34));
        assert(ArmorMovementRestore() && !memcmp(original,f.records,0x34));
    }
    for (unsigned i=0;i<100;i++) {
        assert(ArmorMovementApplyFactor(&f.local,.95f) && fabsf(fixture_value(f.records,4)-.95f)<.000001f);
        assert(ArmorMovementApplyFactor(&f.local,.9f) && fabsf(fixture_value(f.records,4)-.9f)<.000001f);
        assert(ArmorMovementApplyFactor(&f.local,.95f));fixture_float(f.records,4,fixture_value(f.records,4)*.6f);
        assert(ArmorMovementRestore() && fabsf(fixture_value(f.records,4)-.6f)<.000001f);
        memcpy(f.records,original,sizeof(original));
    }
    assert(!ArmorMovementApplyFactor(&f.local,.8f) && !ArmorMovementApplyFactor(&f.local,NAN));
    assert(!memcmp(original,f.records,sizeof(original)));
    assert(!ArmorMovementApply(&f.remote));
    assert(ArmorMovementApply(&f.local));
    fixture_float(f.records,4,fixture_value(f.records,4)*.6f);
    assert(ArmorMovementRestore() && fabsf(fixture_value(f.records,4)-.6f)<.000001f);
    assert(ArmorMovementApply(&f.local) && fabsf(fixture_value(f.records,4)-.54f)<.000001f);
    unsigned char relocated[0x34];memcpy(relocated,f.records,0x34);
    memcpy(f.records,remote,0x34);memcpy(f.records+0x34,relocated,0x34);
    uintptr_t temporary=f.pointers[0];f.pointers[0]=f.pointers[1];f.pointers[1]=temporary;
    assert(ArmorMovementValid(71) && ArmorMovementRestore());
    assert(!memcmp(f.records,remote,0x34) && fabsf(fixture_value(f.records+0x34,4)-.6f)<.000001f);
    f.pointers[1]=f.pointers[0];f.pointers[0]=temporary;
    memcpy(f.records,original,0x34);memcpy(f.records+0x34,remote,0x34);
    DWORD old;assert(VirtualProtect(f.records,8192,PAGE_READONLY,&old));
    assert(!ArmorMovementApply(&f.local));assert(VirtualProtect(f.records,8192,PAGE_READWRITE,&old));
    fixture_float(f.records,4,NAN);assert(!ArmorMovementApply(&f.local));
    fixture_float(f.records,4,1);assert(ArmorMovementApply(&f.local));
    fixture_u32(f.descriptors,12,999);assert(!ArmorMovementValid(71) && !ArmorMovementRestore());
    assert(fixture_value(f.records,4)==.9f);
    fixture_destroy(&f);
    const uint32_t zones[]={0x8c5570c9,0xaa1db0b0,0x1880288e,0x64a3fa1d};
    const uint32_t volumes[]={0x37ef0820,0x668f6a68,0x58d886fb,0};
    for (unsigned weight=0;weight<3;weight++) for (unsigned zone=0;zone<4;zone++)
        for (unsigned volume=0;volume<4;volume++) for (unsigned ap=0;ap<7;ap++) {
            float normal,enhanced;assert(ArmorRuleEvaluateCollider(weight,zones[zone],volumes[volume],ap,&normal)==1);
            assert(ArmorRuleEvaluateProfile(weight,zones[zone],volumes[volume],ap,1,&enhanced)==1);
            if (weight==2 && zone==1 && volume==0) assert(enhanced==(ap<4 ? 0 : ap==4 ? .65f : 1));
            else assert(normal==enhanced);
        }
    puts("Movimento aprovado: 3000 ciclos sem acumulacao, restauracao de produto nativo, compactacao, isolamento remoto, recusa de leitura e AV4 apenas no peitoral pesado identificado.");
}
