import argparse
import ctypes
import hashlib
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from build_actor_addon import entry_text


def evaluate(lua_dll, source):
    lua = ctypes.CDLL(str(lua_dll))
    lua.luaL_newstate.restype = ctypes.c_void_p
    lua.luaL_openlibs.argtypes = [ctypes.c_void_p]
    lua.luaL_loadbuffer.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
    lua.lua_pcall.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    lua.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_size_t)]
    lua.lua_tolstring.restype = ctypes.c_char_p
    lua.lua_close.argtypes = [ctypes.c_void_p]
    state = lua.luaL_newstate()
    if not state:
        raise RuntimeError('Ambiente Lua indisponível')
    lua.luaL_openlibs(state)
    data = source.encode('utf-8')
    try:
        result = lua.luaL_loadbuffer(state, data, len(data), b'@test_armor_bridge')
        result = result or lua.lua_pcall(state, 0, 0, 0)
        if result:
            message = lua.lua_tolstring(state, -1, None)
            raise RuntimeError(message.decode('utf-8', errors='replace') if message else 'Erro Lua')
    finally:
        lua.lua_close(state)


def smoke(lua_dll, tampered):
    source = '''local notes = {}
CowboyBingusModLoader = {open_log=function() return {
write=function(_,s) notes[#notes+1]=s end,flush=function() end} end}
local called=0
update=function(token) called=called+1;return token end
'''
    source += 'assert(loadstring([========[\n' + entry_text() + ']========]))()\n'
    if tampered:
        source += "assert(not LobaoArmorBridgeInstalled and table.concat(notes):find('não corresponde ao pacote',1,true))\n"
    else:
        source += r'''assert(LobaoArmorBridgeInstalled)
assert(update('anterior') == 'anterior' and called==1)
local stats = LobaoArmorBridgeInstalled.stats()
assert(stats.installed==0 and stats.protection_active==0)
local ergo=LobaoArmorBridgeInstalled.ergo_stats()
assert(ergo.weight==4294967295 and ergo.writes==0 and ergo.verified==0 and ergo.pending==0)
assert(LobaoArmorBridgeInstalled.swim_stats().active==0)
assert(LobaoArmorBridgeInstalled.melee_stats().applied==0)
local totals=LobaoArmorBridgeInstalled.totals()
assert(totals.sequence==0 and totals.shots_blocked==0 and totals.mission==0 and totals.session==0)
local report=LobaoArmorBridgeInstalled.report()
assert(#report.regions==4 and report.regions[2].hits==0 and #report.attackers==0 and report.last.type=='0000000000000000')
assert(LobaoArmorBridgeInstalled.unknown_attack()==nil)
assert(LobaoArmorBridgeInstalled.combat()==nil and LobaoArmorBridgeInstalled.cause(0)==nil)
local origin=LobaoArmorBridgeInstalled.origin_stats()
assert(origin.built==0 and origin.linked==0 and origin.recorded==0 and origin.overflow==0)
assert(LobaoArmorBridgeInstalled.diagnostics_requested()==false)
LobaoArmorBridgeInstalled.diagnostics(true);LobaoArmorBridgeInstalled.diagnostics(false)
assert(type(LobaoArmorBridgeInstalled.alert_sound)=='function')
assert(LobaoArmorBridgeInstalled.armor_step(123,true)==0)
assert(LobaoArmorBridgeInstalled.movement_stats().active==0)
assert(LobaoArmorBridgeInstalled.heavy_step(true)==0)
assert(LobaoArmorBridgeInstalled.heavy_step(false)==0)
assert(LobaoArmorBridgeInstalled.equipped().valid==0)
assert(LobaoArmorBridgeInstalled.save_profiles('0x00000065=av4\n'))
assert(LobaoArmorBridgeInstalled.load_profiles()=='0x00000065=av4\n')
assert(not LobaoArmorBridgeInstalled.save_profiles(string.rep('x',65537)))
assert(LobaoArmorBridgeInstalled.load_profiles()=='0x00000065=av4\n')
assert(LobaoArmorBridgeInstalled.handling(0).reason==1)
-- PT-BR: Sem mudança, as leituras por quadro devolvem a mesma tabela (sem lixo).
-- EN: Unchanged, per-frame reads return the same table (no garbage).
assert(LobaoArmorBridgeInstalled.totals()==LobaoArmorBridgeInstalled.totals())
assert(LobaoArmorBridgeInstalled.report()==LobaoArmorBridgeInstalled.report())
assert(LobaoArmorBridgeInstalled.equipped()==LobaoArmorBridgeInstalled.equipped())
assert(type(LobaoArmorBridgeInstalled.research_state())=='string' and LobaoArmorBridgeInstalled.research_state():find('estado=0',1,true))
assert(LobaoArmorBridgeInstalled.statuses()==nil and LobaoArmorBridgeInstalled.passives()==nil)
assert(LobaoArmorBridgeInstalled.fire().sequence==0 and LobaoArmorBridgeInstalled.fire_native()==0)
assert(LobaoArmorBridgeInstalled.pop_settings()==nil and LobaoArmorBridgeInstalled.key_down(0x77)==false and LobaoArmorBridgeInstalled.passive_override(0x73734d67,1,true)==0 and LobaoArmorBridgeInstalled.flinch_test()==nil)
assert(LobaoArmorBridgeInstalled.pop_hit()==nil and LobaoArmorBridgeInstalled.gaps()==0 and LobaoArmorBridgeInstalled.totals().gaps==0)
local decision = LobaoArmorBridgeInstalled.decision()
assert(decision.evaluated==0 and decision.weight==4294967295 and decision.rule==4294967295)
LobaoArmorBridgeInstalled.protect(false)
assert(LobaoArmorBridgeInstalled.effect().enabled==0)
assert(table.concat(notes):find('Módulo ainda ausente',1,true))
assert(LobaoArmorBridgeInstalled.detach()==1)
'''
    evaluate(lua_dll, source)


def run(lua_dll):
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_alerts.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_profiles.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_i18n.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_surface.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_presentation.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_feedback.lua').read_text(encoding='utf-8'))
    evaluate(lua_dll, 'HAP_ROOT = ' + repr(ROOT.as_posix()) + '\n'
             + (ROOT / 'tests/test_actor_addon.lua').read_text(encoding='utf-8'))
    origin_log = ROOT / 'native-build/origin-log-fixture.log'
    sys.path.insert(0, str(ROOT / 'tools'))
    from analyze_combat_log import analyze
    report = analyze(origin_log.read_text(encoding='utf-8'))
    assert [row['sequencia'] for row in report['preparos_com_origem']] == [41]
    linked, ambiguous = report['eventos_com_origem']
    assert linked['ligado'] and linked['preparo_registrado'] and linked['produtor_do_preparo'] == '007d247e'
    assert linked['nome_causador'] == 'conscript_jump_melee' and linked['distancia_m'] == 1.75
    assert ambiguous['ambiguo'] and not ambiguous['preparo_registrado'] and ambiguous['distancia_m'] is None
    first, second = report['resumo_causas']
    assert first['causa'] == '51ba8f74' and first['eventos'] == 4 and first['regioes'] == ['tronco', 'perna esquerda']
    assert first['distancia_media_m'] == 1.75 and second['tipo_causador'] == 'não resolvido'
    print('Analisador aprovado: preparo e evento unidos pela sequência da DLL, ambiguidade preservada e resumo por causa.')
    fixture = ROOT / 'tests/bridge-smoke-á-中文'
    fixture.mkdir(exist_ok=True)
    command = [sys.executable, str(Path(__file__).resolve()), '--lua-dll', str(lua_dll), '--smoke']
    environment = dict(os.environ, LOCALAPPDATA=str(fixture))
    subprocess.run(command, check=True, env=environment)
    binary = (ROOT / 'native-build/LobaoArmorBridge.dll').read_bytes()
    identity = hashlib.sha256(binary).hexdigest()
    extracted = fixture / 'CowboyBingus/Helldivers2/Native/ArmorBridge' / identity / 'LobaoArmorBridge.dll'
    assert extracted.resolve().is_relative_to(fixture.resolve())
    extracted.write_bytes(b'X'+binary[1:])
    try:
        subprocess.run(command+['--tampered'], check=True, env=environment)
    finally:
        extracted.write_bytes(binary)
    print('DLL e LuaJIT reais aprovados: caminho Unicode, versão anterior preservada e recusa de arquivo alterado; nenhum jogo utilizado.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Testa o adaptador e o addon fora do jogo.')
    parser.add_argument('--lua-dll', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--tampered', action='store_true')
    args = parser.parse_args()
    smoke(args.lua_dll,args.tampered) if args.smoke else run(args.lua_dll)
