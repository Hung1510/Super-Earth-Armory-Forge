local M=dofile(HAP_ROOT..'/src/surface.lua')
local worlds,loaded={'principal','menu'},true
local creates,destroys,texts,destroyed_texts=0,0,0,0
local updates,notes=0,{}
local live_texts={}
local frame=0
local function current_id(value,message)
    assert(type(value)=='table' and value.frame==frame,message or 'IdString64 expirado')
end
local sr={Application={worlds=function() return worlds end,can_get=function(kind,value)
        current_id(value);return loaded
    end},
    IdString64={from_hex=function(x) assert(type(x)=='string');return {hex=x,frame=frame} end},Vector2=function(...) return {...} end,
    Vector3=function(...) return {...} end,Color=function(...) return {...} end,
    Material={set_scalar=function() end,set_vector2=function() end,set_vector4=function() end,set_texture=function() assert(loaded) end},
    World={create_screen_gui=function(w) assert(w=='menu');creates=creates+1;return creates end,
        destroy_gui=function(w) assert(w=='menu');destroys=destroys+1;live_texts={} end},
    Gui={material=function(gui,value) assert(loaded);current_id(value);return {} end,
        text=function(gui,value,font,size,material,position,color)
            assert(loaded and type(value)=='string')
            current_id(font,'Fonte temporária de frame anterior')
            current_id(material,'Material temporário de frame anterior')
            assert(type(size)=='number' and position and color)
            texts=texts+1;live_texts[texts]=true;return texts
        end,
        update_text=function(gui,id,value,font,material,size,position,color)
            assert(type(material)=='table' and type(size)=='number',
                'Contrato Gui.update_text: material antes do tamanho')
            current_id(font);current_id(material)
            assert(live_texts[id] and loaded and type(value)=='string' and position and color)
            updates=updates+1
        end,
        destroy_text=function(gui,id)
            assert(live_texts[id]);live_texts[id]=nil;destroyed_texts=destroyed_texts+1
        end}}
local fonts={font='0000000000000001',atlas='0000000000000002',material='0000000000000003'}
local surface=M.new(function(why) notes[#notes+1]=why end)
local items={{id='title',kind='text',text='Blindagem',size=14,color={255,255,255,255}}}
assert(surface.bind(sr,'menu',fonts));assert(surface.sync(items));assert(creates==1 and texts==1)
for i=1,1000 do
    frame=frame+1
    assert(surface.bind(sr,'menu',fonts));assert(surface.sync(items),table.concat(notes))
end
assert(creates==1 and texts==1001 and destroyed_texts==1000 and destroys==0 and updates==0)
local remaining=0;for _ in pairs(live_texts) do remaining=remaining+1 end;assert(remaining==1)
loaded=false
assert(not surface.valid(sr));assert(not surface.sync(items));assert(destroys==1)
assert(not surface.bind(sr,'menu',fonts));assert(creates==1)
loaded=true
assert(surface.bind(sr,'menu',fonts));assert(creates==2)
worlds={'principal'}
surface.close();assert(destroys==1)
assert(not surface.bind(sr,'menu',fonts))
worlds={'principal','menu'}
assert(surface.bind(sr,'menu',fonts))
fonts.font='0000000000000004'
assert(surface.bind(sr,'menu',fonts));assert(creates==4 and destroys==2)
sr.Application.can_get=nil
assert(not surface.valid(sr));surface.close();assert(destroys==3)
print('GUI aprovada: mil frames com IdString64 expirando, sem reutilizar fonte/material temporários nem acumular textos; recursos ausentes e mundos removidos recusados.')
