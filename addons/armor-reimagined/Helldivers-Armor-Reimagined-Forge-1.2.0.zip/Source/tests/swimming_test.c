#include "swimming.h"
#include "runtime_fixture.h"
#include <stdio.h>
#include <math.h>
void ArmorSwimmingTests(void) {
    OwnedFixture f;fixture_create(&f,28,0x14,0x38,0x40);
    unsigned char remote[28];memset(f.records+28,0x57,28);memcpy(remote,f.records+28,28);
    f.records[0]=1;fixture_float(f.records,20,4.5f);
    for (unsigned i=0;i<1000;i++) {
        fixture_float(f.records,20,4.5f);
        assert(ArmorSwimStep(&f.local,5,0,1));assert(fixture_value(f.records,20)==5);
        assert(!memcmp(remote,f.records+28,28));
        assert(ArmorSwimStep(&f.local,5,i%2+1,1));
        fixture_float(f.records,20,4.5f);
        assert(ArmorSwimStep(&f.local,5,2,1));assert(fixture_value(f.records,20)==4.5f);
    }
    assert(!ArmorSwimStep(&f.remote,5,0,1));assert(!memcmp(remote,f.records+28,28));
    assert(ArmorSwimStep(&f.local,5,0,1));assert(ArmorSwimRestore());
    fixture_float(f.records,20,4);assert(ArmorSwimStep(NULL,0,UINT32_MAX,0));assert(fixture_value(f.records,20)==4);
    f.records[0]=0;assert(ArmorSwimStep(&f.local,5,0,1));assert(fixture_value(f.records,20)==4);
    f.records[0]=1;fixture_float(f.records,20,0);assert(!ArmorSwimStep(&f.local,5,0,1));
    fixture_float(f.records,20,NAN);assert(!ArmorSwimStep(&f.local,5,0,1));
    fixture_float(f.records,20,4);f.descriptors[12]^=1;assert(!ArmorSwimStep(&f.local,5,0,1));
    assert(fixture_value(f.records,20)==4);f.descriptors[12]^=1;
    DWORD old;assert(VirtualProtect(f.records,8192,PAGE_READONLY,&old));
    assert(!ArmorSwimStep(&f.local,5,0,1));assert(fixture_value(f.records,20)==4);
    assert(VirtualProtect(f.records,8192,PAGE_READWRITE,&old));
    ArmorSwimStats stats;ArmorSwimReadStats(&stats);assert(sizeof(stats)==48 && !stats.active);
    fixture_destroy(&f);
    puts("Natacao: 1.000 ciclos de reposicao somente no personagem local leve; remoto, media, pesada, seco e desativacao preservados; nenhum temporizador compartilhado alterado.");
}
