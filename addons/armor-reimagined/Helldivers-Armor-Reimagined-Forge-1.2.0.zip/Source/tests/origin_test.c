﻿#include "damage_origin.h"
#include <windows.h>
#undef NDEBUG
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
typedef struct {uintptr_t at;unsigned char data[256];size_t size;} Block;
static Block blocks[48];
static unsigned block_count;
static Block *map(uintptr_t at,size_t size) {
    assert(block_count<48 && size<=256);
    Block *b=&blocks[block_count++];memset(b,0,sizeof(*b));b->at=at;b->size=size;return b;
}
static void put32(Block *b,unsigned at,uint32_t value) {memcpy(b->data+at,&value,4);}
static void put64(Block *b,unsigned at,uint64_t value) {memcpy(b->data+at,&value,8);}
static int fake_read(uintptr_t at,void *out,size_t size) {
    for (unsigned i=0;i<block_count;i++)
        if (at>=blocks[i].at && at+size<=blocks[i].at+blocks[i].size) {memcpy(out,blocks[i].data+(at-blocks[i].at),size);return 1;}
    return 0;
}
static const uintptr_t game=UINT64_C(0x100000000),exe=UINT64_C(0x600000000);
static Block *descriptor,*live,*generation,*object,*method,*poses;
static void world(void) {
    block_count=0;
    const uintptr_t manager=UINT64_C(0x200000000),buckets=UINT64_C(0x300000000),descriptors=UINT64_C(0x400000000);
    put64(map(game+0x3326688,8),0,manager);
    live=map(manager+0x1020,4);put32(live,0,4);
    Block *header=map(manager+0x1030,20);put64(header,0,buckets);put32(header,8,8);put32(header,12,UINT32_MAX);put32(header,16,1);
    Block *table=map(buckets,64);memset(table->data,255,64);
    put32(table,8,17);put32(table,12,2);put32(table,16,18);put32(table,20,3);
    put64(map(manager+0x1048,8),0,descriptors);
    Block *pointers=map(descriptors,32);put64(pointers,16,UINT64_C(0x500000000));put64(pointers,24,UINT64_C(0x500000100));
    descriptor=map(UINT64_C(0x500000000),24);put64(descriptor,0,UINT64_C(0x856e9710e45e760f));put32(descriptor,8,17);
    put32(descriptor,12,(3u<<22)|5);
    Block *victim=map(UINT64_C(0x500000100),24);put64(victim,0,UINT64_C(0x4d1c334d294dfa97));put32(victim,8,18);put32(victim,12,6);
    const uintptr_t registry=UINT64_C(0x700000000),generations=UINT64_C(0x710000000),objects=UINT64_C(0x720000000);
    put64(map(exe+0x1a100f0,8),0,registry);
    Block *r=map(registry+0x88,32);put64(r,0,objects);put32(r,0x10,10);put64(r,0x18,generations);
    generation=map(generations,10);generation->data[5]=3;generation->data[6]=0;
    Block *list=map(objects,64);put64(list,40,UINT64_C(0x730000000));put64(list,48,UINT64_C(0x730000100));
    object=map(UINT64_C(0x730000000),0x90);put64(object,0,UINT64_C(0x740000000));put32(object,8,(3u<<22)|5);
    put64(object,0x88,UINT64_C(0x750000000));
    Block *other=map(UINT64_C(0x730000100),0x90);put64(other,0,UINT64_C(0x740000000));put32(other,8,6);
    put64(other,0x88,UINT64_C(0x750000100));
    put64(map(UINT64_C(0x740000000)+0xe8,8),0,exe+0x2bd870);
    method=map(exe+0x2bd870,5);memcpy(method->data,"\x48\x8d\x41\x60\xc3",5);
    poses=map(UINT64_C(0x750000000)+0x30,12);
    float a[3]={3,4,0},b[3]={0,0,0};memcpy(poses->data,a,12);
    memcpy(map(UINT64_C(0x750000100)+0x30,12)->data,b,12);
}
static void source_tests(void) {
    uint64_t type=0;uint32_t unit=0;float position[3];
    world();
    assert(ArmorSourceHealth(game,fake_read,17,&type,&unit) && type==UINT64_C(0x856e9710e45e760f) && unit==((3u<<22)|5));
    assert(!ArmorSourceHealth(game,fake_read,19,&type,&unit) && !ArmorSourceHealth(0,fake_read,17,&type,&unit));
    put32(descriptor,8,99);assert(!ArmorSourceHealth(game,fake_read,17,&type,&unit));put32(descriptor,8,17);
    put32(live,0,2);assert(!ArmorSourceHealth(game,fake_read,17,&type,&unit));put32(live,0,4);
    assert(ArmorSourceUnitPosition(exe,fake_read,(3u<<22)|5,position) && position[0]==3 && position[1]==4);
    assert(!ArmorSourceUnitPosition(exe,fake_read,(4u<<22)|5,position));
    assert(!ArmorSourceUnitPosition(exe,fake_read,(3u<<22)|11,position));
    method->data[4]=0x90;assert(!ArmorSourceUnitPosition(exe,fake_read,(3u<<22)|5,position));method->data[4]=0xc3;
    float bad=NAN;memcpy(poses->data,&bad,4);assert(!ArmorSourceUnitPosition(exe,fake_read,(3u<<22)|5,position));
    float x=3;memcpy(poses->data,&x,4);
    ArmorOrigin o={.dealer=17,.owner=17,.victim=18};
    ArmorOriginResolve(game,exe,fake_read,&o,1);
    assert(o.flags&ARMOR_ORIGIN_DEALER_HEALTH && o.flags&ARMOR_ORIGIN_OWNER_HEALTH);
    assert(o.dealer_health_type==UINT64_C(0x856e9710e45e760f) && o.owner_health_type==o.dealer_health_type);
    assert(o.flags&ARMOR_ORIGIN_DEALER_POSITION && o.flags&ARMOR_ORIGIN_VICTIM_POSITION && fabsf(o.distance-5)<1e-5f);
    assert(!(o.flags&ARMOR_ORIGIN_DEALER_ENTITY));
    ArmorOrigin lean={.dealer=17,.owner=17,.victim=18};
    ArmorOriginResolve(game,exe,fake_read,&lean,0);
    assert(lean.flags==ARMOR_ORIGIN_VICTIM_POSITION && !lean.dealer_health_type && !lean.distance);
    ArmorOrigin missing={.dealer=19,.owner=17,.victim=20};
    ArmorOriginResolve(game,exe,fake_read,&missing,1);
    assert(!(missing.flags&ARMOR_ORIGIN_DEALER_HEALTH) && missing.flags&ARMOR_ORIGIN_OWNER_HEALTH && !missing.distance);
    assert(missing.reserved==19 && !(missing.flags&ARMOR_ORIGIN_DEALER_GENERATION));
    // PT-BR: Evento com Ã­ndice sem geraÃ§Ã£o: o gerenciador do motor completa o ID e o descritor de vida resolve.
    // EN: Event with a generation-less index: the engine manager completes the ID and the health descriptor resolves.
    const uintptr_t engine=UINT64_C(0x760000000),generations=UINT64_C(0x770000000);
    const uint32_t full=(2u<<22)|19;
    put64(map(exe+0x1b135b8,8),0,engine);
    Block *e=map(engine+0x80,16);put32(e,0,64);put64(e,8,generations);
    Block *g=map(generations,64);g->data[19]=2;
    Block *table=NULL;
    for (unsigned i=0;i<block_count;i++) if (blocks[i].at==UINT64_C(0x300000000)) table=&blocks[i];
    put32(table,24,full);put32(table,28,1);
    for (unsigned i=0;i<block_count;i++) if (blocks[i].at==UINT64_C(0x400000000)) put64(&blocks[i],8,UINT64_C(0x500000200));
    Block *enemy=map(UINT64_C(0x500000200),24);put64(enemy,0,UINT64_C(0x9d8827fed763650e));put32(enemy,8,full);put32(enemy,12,(3u<<22)|5);
    assert(ArmorEntityComplete(exe,fake_read,19)==full && ArmorEntityComplete(exe,fake_read,full)==full);
    assert(ArmorEntityComplete(exe,fake_read,99)==99 && ArmorEntityComplete(0,fake_read,19)==19);
    ArmorOrigin completed={.dealer=19,.owner=19,.victim=18};
    ArmorOriginResolve(game,exe,fake_read,&completed,1);
    assert(completed.flags&ARMOR_ORIGIN_DEALER_GENERATION && completed.flags&ARMOR_ORIGIN_OWNER_GENERATION);
    assert(completed.dealer_health_type==UINT64_C(0x9d8827fed763650e) && completed.owner_health_type==completed.dealer_health_type);
    assert(completed.reserved==full && completed.dealer==19 && fabsf(completed.distance-5)<1e-5f);
}
static void link_tests(void) {
    ArmorReplayKey key={{1,2,3}},other={{1,2,4}};
    ArmorOrigin origin={.sequence=7,.producer=0x7d247e},out;
    ArmorOriginClear();
    assert(ArmorOriginRemember(&key,&origin,100) && !ArmorOriginTake(&other,100,&out));
    assert(ArmorOriginTake(&key,150,&out)==1 && out.sequence==7 && out.producer==0x7d247e);
    assert(!ArmorOriginTake(&key,150,&out));
    assert(ArmorOriginRemember(&key,&origin,100) && !ArmorOriginTake(&key,1101,&out));
    assert(ArmorOriginRemember(&key,&origin,100) && ArmorOriginRemember(&key,&origin,100));
    assert(ArmorOriginTake(&key,100,&out)==-2 && !ArmorOriginTake(&key,100,&out));
    for (unsigned i=0;i<200;i++) {origin.sequence=i;key.words[5]=i;assert(ArmorOriginRemember(&key,&origin,100));}
    key.words[5]=199;assert(ArmorOriginTake(&key,100,&out)==1 && out.sequence==199);
    key.words[5]=0;assert(!ArmorOriginTake(&key,100,&out));
    ArmorOriginClear();
}
static void cause_tests(void) {
    ArmorCauseStats row;
    ArmorCauseClear();
    uint32_t version=ArmorCauseVersion();
    ArmorOrigin o={.kind=6,.cause=0x71739f3f,.producer=0x7d247e,.region=0xaa1db0b0,
        .flags=ARMOR_ORIGIN_DEALER_HEALTH|ARMOR_ORIGIN_DEALER_POSITION|ARMOR_ORIGIN_VICTIM_POSITION|ARMOR_ORIGIN_LINKED,
        .dealer_health_type=0x54e107dacf6929cbull,.distance=2.5f};
    assert(ArmorCauseRecord(&o,0,60,1,1));
    o.distance=1.5f;o.region=0x64a3fa1d;o.flags&=~ARMOR_ORIGIN_LINKED;
    assert(ArmorCauseRecord(&o,0,54,1,0));
    o.flags&=~ARMOR_ORIGIN_VICTIM_POSITION;assert(ArmorCauseRecord(&o,0,40,0,0));
    assert(ArmorCauseVersion()==version+3 && ArmorCauseRead(0,&row) && !ArmorCauseRead(1,&row));
    assert(ArmorCauseRead(0,&row) && row.count==3 && row.linked==1 && row.known==2 && row.reduced==1);
    assert(row.damage_min==40 && row.damage_max==60 && row.damage_sum==154 && row.distance_count==2);
    assert(row.distance_min==1.5f && row.distance_max==2.5f && fabs(row.distance_sum-4)<1e-9);
    assert(row.regions==(1u|16u) && row.dealer_type==0x54e107dacf6929cbull);
    o.producer=0x13ad4ed;assert(ArmorCauseRecord(&o,0,45,0,0) && ArmorCauseRead(1,&row) && row.count==1);
    o.flags=0;o.region=0x12345678;assert(ArmorCauseRecord(&o,0,1,0,0) && ArmorCauseRead(2,&row) && !row.dealer_type && row.regions==64);
    for (unsigned i=0;i<200;i++) {o.cause=i+1;ArmorCauseRecord(&o,0,1,0,0);}
    assert(ArmorCauseOverflow()>=75 && ArmorCauseRead(127,&row) && !ArmorCauseRead(128,&row));
    assert(ArmorCauseRegionBit(0)==0 && ArmorCauseRegionBit(0x8c5570c9)==2);
    ArmorCauseClear();assert(!ArmorCauseRead(0,&row));
}
static void reach_network_tests(void) {
    unsigned char hit[0x118]={0};float a[3]={-185.33f,-53.95f,13.67f},b[3]={-184.52f,-53.36f,14.06f},reach;
    memcpy(hit+0x34,a,12);memcpy(hit+0x40,b,12);
    assert(ArmorHitReach(hit,&reach) && fabsf(reach-1.08f)<0.02f);
    float bad=NAN;memcpy(hit+0x40,&bad,4);assert(!ArmorHitReach(hit,&reach) && !ArmorHitReach(NULL,&reach));
    block_count=0;
    const uintptr_t manager=UINT64_C(0x800000000),buckets=UINT64_C(0x810000000);
    put64(map(game+0x346bf98,8),0,manager);
    Block *h=map(manager+0xf22ec8,20);put64(h,0,buckets);put32(h,8,8);put32(h,12,UINT32_MAX);put32(h,16,1);
    Block *t=map(buckets,64);memset(t->data,255,64);put32(t,8*6,678);put32(t,8*6+4,3);
    put32(map(manager+0xf32f20+3*24,4),0,(1u<<22)|900);
    assert(ArmorEntityFromNetwork(game,fake_read,678)==((1u<<22)|900));
    assert(!ArmorEntityFromNetwork(game,fake_read,679) && !ArmorEntityFromNetwork(game,fake_read,0x7fff) && !ArmorEntityFromNetwork(0,fake_read,678));
}
void ArmorOriginTests(void) {
    source_tests();link_tests();cause_tests();reach_network_tests();
    puts("Origem aprovada: tipo pelo descritor de vida, posicao por unidade com geracao, distancia, ligacao exata preparo-evento, ambiguidade/expiracao e resumo de 128 causas.");
}
