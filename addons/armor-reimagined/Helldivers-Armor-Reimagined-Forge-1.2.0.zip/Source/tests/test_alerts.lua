local env={};setmetatable(env,{__index=_G});env._G=env
env.HAPI18n=assert(loadfile(HAP_ROOT..'/src/i18n.lua'))()
local queue,beeps,notes,draws={},0,{},{}
local gui,available=false,true
local surface
env.HAPSurface={new=function() surface={
    close=function() gui=false;surface.gui=nil end,
    valid=function() return gui and available end,
    bind=function() gui=available;surface.gui=available and true or nil;return available end,
    sync=function(items) draws[#draws+1]=items;return true end
};return surface end}
local api={equipped=function() return {valid=1,avatar=71} end,
    unknown_attack=function() return table.remove(queue,1) end,
    alert_sound=function() beeps=beeps+1;return true end}
local presentation={alert_fonts=function() return {font='f',atlas='a',material='m'} end}
local source=assert(io.open(HAP_ROOT..'/src/alerts.lua','rb')):read('*a')
local alerts=setfenv(assert(loadstring(source)),env)().new(api,function(s) notes[#notes+1]=s end,presentation)
local sr={Gui={resolution=function() return 1920,1080 end},Application={main_world=function() return 'mission' end}}
local function hit(cause,avatar,element)
    queue[#queue+1]={sequence=#notes+1,cause=cause or 99,victim=avatar or 71,element=element or 0,kind=6,damage=30}
end
hit();alerts.step(sr,0,true,2);assert(beeps==1 and gui and draws[#draws][2].text=='ATAQUE FÍSICO NÃO IDENTIFICADO')
assert(notes[1]:find('causa=0x00000063; dano=30; som=true',1,true))
hit();alerts.step(sr,1000,true,2);assert(beeps==1)
hit(100);alerts.step(sr,2000,true,2);assert(beeps==1)
alerts.step(sr,6000,true,2);assert(not gui)
hit();alerts.step(sr,9000,true,2);assert(beeps==1)
hit(100);alerts.step(sr,10000,true,1);assert(beeps==2 and draws[#draws][2].text=='UNKNOWN PHYSICAL ATTACK')
hit(101);alerts.step(sr,11000,false,1);assert(beeps==2 and not gui and #queue==0)
alerts.step(sr,18000,true,1);assert(beeps==2 and not gui)
hit(101,72);hit(102,71,1);alerts.step(sr,20000,true,1);assert(beeps==2)
hit();alerts.step(sr,60000,true,3);assert(beeps==3 and draws[#draws][2].text=='ATAQUE FÍSICO NO IDENTIFICADO')
available=false;alerts.before_ui(sr);assert(not gui)
alerts.step(sr,61000,true,3);assert(not gui and beeps==3)
available=true;alerts.step(sr,62000,true,3);assert(gui)
api.equipped=function() return {valid=1,avatar=72} end
alerts.step(sr,63000,true,3);assert(not gui)
api.equipped=function() return {valid=1,avatar=71} end
api.alert_sound=function() error('Som indisponível') end
hit(105);alerts.step(sr,70000,true,1);assert(gui and notes[#notes]:find('som=false',1,true))
alerts.close();assert(not gui)
-- PT-BR: Aviso de desligamento aparece sem missão/equipamento e expira em 15 s; falha genérica mostra o código.
-- EN: Disable notice appears without mission/equipment and expires after 15 s; generic failure shows the code.
api.equipped=function() return {valid=0} end
alerts.notice('version',21,100000);alerts.step(sr,100000,false,2)
assert(gui and draws[#draws][2].text=='ARMOR REIMAGINED DESLIGADO' and draws[#draws][3].text:find('versão do jogo mudou',1,true))
alerts.step(sr,114999,false,2);assert(gui)
alerts.step(sr,115000,false,2);assert(not gui)
alerts.notice('refused',47,120000);alerts.step(sr,120000,false,1)
assert(gui and draws[#draws][2].text=='ARMOR REIMAGINED DISABLED' and draws[#draws][3].text:find('code 47',1,true))
alerts.close()
print('Avisos aprovados: três idiomas, duração, intervalo global/por causa, fila drenada quando desligada, alvo/elemento, troca de avatar, recurso expirado e som indisponível sem interromper o mod.')
