#undef NDEBUG
#include <assert.h>
#include <math.h>
#include <string.h>
#include "projectile_replay.h"
static float round_value(float value) { return floorf(value+0.5f); }
void ArmorReplayTests(void) {
    ArmorReplayInput input = {.durable=0.25f, .base={2,6}, .extra={0,1,2,3}, .scale=1.5f};
    float out[4];
    assert(ArmorReplayCalculate(&input, round_value, out));
    assert(out[0] == 5 && out[1] == 6 && out[2] == 8 && out[3] == 9);
    input.extra[0] = -9;
    assert(ArmorReplayCalculate(&input, round_value, out) && out[0] == 0);
    float before[4]; memcpy(before, out, sizeof(before));
    input.scale = NAN;
    assert(!ArmorReplayCalculate(&input, round_value, out) && !memcmp(out, before, sizeof(before)));
    input.scale = 100;
    assert(!ArmorReplayCalculate(&input, round_value, out));
    unsigned char hit[0x118] = {0}, event[0x70] = {0};
    const unsigned from[13] = {0x20,4,0x24,0x84,0x104,0x110,0x114,0x34,0x38,0x3c,0x88,0x8c,0x90};
    const unsigned to[13] = {0,8,0xc,0x10,0x14,0x18,0x1c,0x50,0x54,0x58,0x44,0x48,0x4c};
    for (unsigned i=0; i<13; ++i) {
        uint32_t value = 71+i;
        memcpy(hit+from[i], &value, 4); memcpy(event+to[i], &value, 4);
    }
    ArmorReplaySample sample = {.region=2854072496u, .penetration={2,2,1,0}, .selected=2}, matched;
    ArmorReplayKey key;
    ArmorReplayHitKey(hit, &sample.key); ArmorReplayEventKey(event, &key);
    assert(!memcmp(&sample.key, &key, sizeof(key)));
    ArmorReplayClear();
    assert(ArmorReplayRemember(&sample, 100));
    for (unsigned i=0; i<13; ++i) {
        ArmorReplayKey wrong = key; wrong.words[i] ^= 1;
        assert(ArmorReplayMatch(&wrong, 101, &matched) == 0);
    }
    assert(ArmorReplayMatch(&key, 101, &matched) == 1 && matched.selected == 2 && matched.region == sample.region);
    assert(ArmorReplayMatch(&key, 101, &matched) == 0);
    assert(ArmorReplayRemember(&sample, 200) && ArmorReplayRemember(&sample, 201));
    assert(ArmorReplayMatch(&key, 202, &matched) == -2);
    assert(ArmorReplayMatch(&key, 203, &matched) == 0);
    assert(ArmorReplayRemember(&sample, 300));
    assert(ArmorReplayMatch(&key, 1301, &matched) == 0);
    // PT-BR: Chumbos de escopeta somados: mesmo volume e causador, posição média dentro da caixa.
    // EN: Summed shotgun pellets: same volume and dealer, averaged position inside the box.
    ArmorReplayClear();
    {
        ArmorReplaySample pellet=sample;ArmorReplayKey merged=sample.key,far=sample.key;unsigned count=9;float aps[32];unsigned char glances[32];
        const float xs[3]={10.0f,10.4f,10.2f};
        for (unsigned i=0;i<3;i++) {memcpy(&pellet.key.words[7],&xs[i],4);assert(ArmorReplayRemember(&pellet,500));}
        float mid=10.2f,out=11.0f;memcpy(&merged.words[7],&mid,4);memcpy(&far.words[7],&out,4);
        assert(ArmorReplayMatch(&merged,501,&matched)==1 && matched.selected==sample.selected);
        assert(ArmorReplayMatchMerged(&far,501,&matched,aps,glances,32,&count)==0 && count==0);
        assert(ArmorReplayMatchMerged(&merged,501,&matched,aps,glances,32,&count)==1 && count==2 && matched.region==sample.region
            && aps[0]==sample.selected && aps[1]==sample.selected);
        assert(ArmorReplayMatchMerged(&merged,502,&matched,aps,glances,32,&count)==0);
        // PT-BR: Penetração diferente por ângulo é aceita e devolvida por chumbo; perfil diferente é ambíguo.
        // EN: Different penetration by angle is accepted and returned per pellet; a different profile is ambiguous.
        ArmorReplaySample other=pellet;other.selected=sample.selected+1;
        memcpy(&pellet.key.words[7],&xs[0],4);assert(ArmorReplayRemember(&pellet,600));
        memcpy(&other.key.words[7],&xs[1],4);assert(ArmorReplayRemember(&other,600));
        assert(ArmorReplayMatchMerged(&merged,601,&matched,aps,glances,32,&count)==1 && count==2
            && aps[0]+aps[1]==2*sample.selected+1);
        other.region=sample.region+1;
        memcpy(&pellet.key.words[7],&xs[0],4);assert(ArmorReplayRemember(&pellet,600));
        memcpy(&other.key.words[7],&xs[1],4);assert(ArmorReplayRemember(&other,600));
        assert(ArmorReplayMatchMerged(&merged,601,&matched,aps,glances,32,&count)==-2 && count==2);
        assert(ArmorReplayMatchMerged(&merged,602,&matched,aps,glances,32,&count)==0);
        memcpy(&pellet.key.words[7],&xs[0],4);assert(ArmorReplayRemember(&pellet,650));
        memcpy(&pellet.key.words[7],&xs[1],4);assert(ArmorReplayRemember(&pellet,650));
        assert(ArmorReplayMatchMerged(&merged,651,&matched,aps,glances,1,&count)==-2 && count==2);
        memcpy(&pellet.key.words[7],&xs[0],4);assert(ArmorReplayRemember(&pellet,700));
        assert(ArmorReplayMatchMerged(&merged,701,&matched,aps,glances,32,&count)==0);
        ArmorReplayClear();
    }
    assert(ArmorReplayRemember(&sample, 1400));
    ArmorReplayClear();
    assert(ArmorReplayMatch(&key, 1401, &matched) == 0);
    uint32_t collider=UINT32_C(0x37ef0820),actor=123,victim=71;
    memset(hit,0,sizeof(hit));memcpy(hit+0x20,&victim,4);memcpy(hit+0x24,&actor,4);
    assert(ArmorReplayRememberCollider(100,hit,collider,2000));
    assert(!ArmorReplayTakeCollider(101,hit,2001));
    assert(ArmorReplayTakeCollider(100,hit,2001)==collider);
    assert(!ArmorReplayTakeCollider(100,hit,2002));
    assert(ArmorReplayRememberCollider(100,hit,collider,2050));
    hit[4]=7;
    assert(ArmorReplayTakeCollider(100,hit,2051)==collider);
    for (unsigned field=0;field<6;field++) {
        unsigned at=((unsigned[]){0,0x20,0x24,0x34,0x38,0x3c})[field];
        assert(ArmorReplayRememberCollider(100,hit,collider,2100));
        hit[at]^=1;assert(!ArmorReplayTakeCollider(100,hit,2101));hit[at]^=1;
    }
    assert(ArmorReplayRememberCollider(100,hit,collider,2200));
    assert(!ArmorReplayTakeCollider(100,hit,3201));
    assert(ArmorReplayRememberCollider(100,hit,collider,3300));
    assert(!ArmorReplayTakeCollider(100,hit,3299));
    assert(ArmorReplayRememberCollider(100,hit,collider,3400));
    assert(ArmorReplayRememberCollider(100,hit,0,3401));
    assert(!ArmorReplayTakeCollider(100,hit,3402));
    assert(ArmorReplayRememberCollider(100,hit,collider,3500));
    ArmorReplayClear();assert(!ArmorReplayTakeCollider(100,hit,3501));
    assert(ArmorReplayRememberCollider(100,hit,collider,3600));
    assert(ArmorReplayRememberCollider(200,hit,UINT32_C(0x668f6a68),3600));
    assert(ArmorReplayTakeCollider(200,hit,3601)==UINT32_C(0x668f6a68));
    assert(ArmorReplayTakeCollider(100,hit,3601)==collider);
    hit[0]=6;assert(ArmorReplayRememberCollider(100,hit,collider,3700));
    assert(ArmorReplayTakeCollider(100,hit,3701)==collider);
    assert(ArmorReplayRememberCollider(100,hit,collider,3800));hit[0]=0;
    assert(!ArmorReplayTakeCollider(100,hit,3801));
    assert(ArmorReplayRememberCollider(100,hit,collider,3900));hit[0]=6;
    assert(!ArmorReplayTakeCollider(100,hit,3901));
}
