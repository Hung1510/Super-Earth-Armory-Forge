#pragma once
#include "local_runtime.h"
#include <windows.h>
#undef NDEBUG
#include <assert.h>
#include <string.h>
typedef struct OwnedFixture {
    uintptr_t global;
    unsigned char *manager,*records,*descriptors;
    uintptr_t pointers[2];
    ArmorOwnedRecord local,remote;
} OwnedFixture;
static inline void fixture_u32(unsigned char *p,unsigned off,uint32_t value) {memcpy(p+off,&value,4);}
static inline void fixture_ptr(unsigned char *p,unsigned off,uintptr_t value) {memcpy(p+off,&value,8);}
static inline void fixture_float(unsigned char *p,unsigned off,float value) {memcpy(p+off,&value,4);}
static inline float fixture_value(unsigned char *p,unsigned off) {float v;memcpy(&v,p+off,4);return v;}
static inline void fixture_create(OwnedFixture *f,unsigned stride,unsigned countoff,unsigned descoff,unsigned recoff) {
    memset(f,0,sizeof(*f));
    f->manager=VirtualAlloc(NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    f->records=VirtualAlloc(NULL,8192,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    f->descriptors=VirtualAlloc(NULL,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    assert(f->manager && f->records && f->descriptors);
    f->global=(uintptr_t)f->manager;
    uint64_t resource=UINT64_C(0x4d1c334d294dfa97);
    for (unsigned i=0;i<2;i++) {
        unsigned char *d=f->descriptors+24*i;memcpy(d,&resource,8);
        fixture_u32(d,8,71+i);fixture_u32(d,12,100+i);fixture_u32(d,20,i==0 ? 1 : 0);
        f->pointers[i]=(uintptr_t)d;
    }
    fixture_u32(f->manager,countoff,2);fixture_ptr(f->manager,descoff,(uintptr_t)f->pointers);
    fixture_ptr(f->manager,recoff,(uintptr_t)f->records);
    f->local=(ArmorOwnedRecord){.global=(uintptr_t)&f->global,.manager=(uintptr_t)f->manager,
        .descriptors=(uintptr_t)f->pointers,.descriptor=f->pointers[0],.records=(uintptr_t)f->records,
        .record=(uintptr_t)f->records,.count_offset=countoff,.descriptors_offset=descoff,
        .records_offset=recoff,.index=0,.stride=stride};
    memcpy(f->local.identity,f->descriptors,24);
    f->remote=f->local;f->remote.index=1;f->remote.record+=stride;f->remote.descriptor=f->pointers[1];
    memcpy(f->remote.identity,f->descriptors+24,24);
}
static inline void fixture_destroy(OwnedFixture *f) {
    assert(VirtualFree(f->manager,0,MEM_RELEASE));assert(VirtualFree(f->records,0,MEM_RELEASE));
    assert(VirtualFree(f->descriptors,0,MEM_RELEASE));
}
