#include "melee.h"
#include "damage_source.h"
#include "actor_bridge.h"
#include "damage_commit.h"
#include "runtime_fixture.h"
#include <windows.h>
#undef NDEBUG
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
static void put(unsigned char *data,unsigned at,uint32_t value) {memcpy(data+at,&value,4);}
static uint32_t word(const unsigned char *data,unsigned at) {uint32_t value;memcpy(&value,data+at,4);return value;}
static unsigned char source_header[24],source_buckets[64],source_descriptor[12];
static int source_read(uintptr_t at,void *out,size_t size) {
    uintptr_t manager=UINT64_C(0x200000000),buckets=UINT64_C(0x300000000);
    if (at==UINT64_C(0x10346bf98) && size==8) {memcpy(out,&manager,8);return 1;}
    if (at==manager+0xf1aeb0 && size==24) {memcpy(out,source_header,24);return 1;}
    if (at>=buckets && at+size<=buckets+64) {memcpy(out,source_buckets+(at-buckets),size);return 1;}
    if (at==manager+0xf32f18+48 && size==12) {memcpy(out,source_descriptor,12);return 1;}
    return 0;
}
static void source_tests(void) {
    uintptr_t buckets=UINT64_C(0x300000000);memcpy(source_header,&buckets,8);
    put(source_header,8,8);put(source_header,12,UINT32_MAX);put(source_header,16,1);
    memset(source_buckets,255,64);put(source_buckets,8,17);put(source_buckets,12,2);
    uint64_t type=UINT64_C(0x9d8827fed763650e);memcpy(source_descriptor,&type,8);put(source_descriptor,8,17);
    uint64_t result=0;assert(ArmorSourceType(UINT64_C(0x100000000),source_read,17,&result) && result==type);
    put(source_descriptor,8,18);result=123;assert(!ArmorSourceType(UINT64_C(0x100000000),source_read,17,&result) && result==123);
    put(source_descriptor,8,17);assert(!ArmorSourceType(UINT64_C(0x100000000),source_read,18,&result));
    put(source_header,8,7);assert(!ArmorSourceType(UINT64_C(0x100000000),source_read,17,&result));
    assert(!ArmorSourceType(0,source_read,17,&result));
}
void ArmorMeleeTests(void) {
    source_tests();
    const uint32_t causes[]={0x11c4b1a5,0xf8ed1323,0xae3392c1,0xcae3c500,0xe0b04680,0x71739f3f,0x51ba8f74,0x5c934d9a};
    for (unsigned i=0;i<sizeof(causes)/sizeof(causes[0]);i++) {
        assert(ArmorMeleeKnown(6,0,causes[i]));
        assert(!ArmorMeleeKnown(0,0,causes[i]) && !ArmorMeleeKnown(6,1,causes[i]));
    }
    assert(!ArmorMeleeKnown(6,0,0x6644dc22) && !ArmorMeleeKnown(6,0,0xab3862b0) && !ArmorMeleeKnown(6,0,0));
    // PT-BR: Par confirmado até 6 m; atacante não catalogado até 3 m; dados ausentes e excluídos recusados.
    // EN: Confirmed pair up to 6 m; uncatalogued attacker up to 3 m; missing data and excluded types refused.
    {
        float distance=-1;const uint32_t other=0x12345678;
        ArmorOrigin close_hit={.flags=ARMOR_ORIGIN_NET_HEALTH|ARMOR_ORIGIN_NET_POSITION|ARMOR_ORIGIN_VICTIM_POSITION,
            .net_type=UINT64_C(0x9647B00CC3A9D36F),.net_distance=1.2f};
        assert(ArmorMeleeIdentified(UINT64_C(0x9647B00CC3A9D36F),0xab3862b0) && !ArmorMeleeIdentified(UINT64_C(0x9647B00CC3A9D36F),other));
        assert(ArmorMeleeIdentified(UINT64_C(0x67DC32DCA4F02D33),0) && !ArmorMeleeIdentified(UINT64_C(0x67DC32DCA4F02D33),0xab3862b0));
        assert(ArmorMeleeProximity(&close_hit,other,&distance)==ARMOR_MELEE_BY_DISTANCE && distance==1.2f);
        assert(ArmorMeleeProximity(&close_hit,0xab3862b0,&distance)==ARMOR_MELEE_BY_ATTACKER);
        close_hit.net_distance=3.0f;assert(ArmorMeleeProximity(&close_hit,other,&distance));
        close_hit.net_distance=3.01f;assert(!ArmorMeleeProximity(&close_hit,other,&distance));
        assert(ArmorMeleeProximity(&close_hit,0xab3862b0,&distance)==ARMOR_MELEE_BY_ATTACKER);
        close_hit.net_type=UINT64_C(0x67DC32DCA4F02D33);close_hit.net_distance=3.47f;
        assert(ArmorMeleeProximity(&close_hit,0,&distance)==ARMOR_MELEE_BY_ATTACKER && distance==3.47f);
        close_hit.net_distance=6.0f;assert(ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.net_distance=6.01f;assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.net_distance=NAN;assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.net_distance=1.2f;close_hit.flags&=~ARMOR_ORIGIN_NET_POSITION;assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.flags|=ARMOR_ORIGIN_NET_POSITION;close_hit.flags&=~ARMOR_ORIGIN_VICTIM_POSITION;assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.flags|=ARMOR_ORIGIN_VICTIM_POSITION;
        close_hit.dealer=353;close_hit.owner=355;assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.owner=353;assert(ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.net_type=UINT64_C(0xCCAE5264ACD591B7);close_hit.net_distance=2.7f;
        assert(!ArmorMeleeExcluded(close_hit.net_type) && ArmorMeleeProximity(&close_hit,0xf25abcdd,&distance)==ARMOR_MELEE_BY_ATTACKER);
        assert(!ArmorMeleeExcluded(UINT64_C(0x10081ACEF6163EF6)) && !ArmorMeleeExcluded(UINT64_C(0x6021E22338333D88)));
        assert(ArmorMeleeIdentified(UINT64_C(0xF540CA9D9D4A422E),0x6d29c458) && !ArmorMeleeIdentified(UINT64_C(0xF540CA9D9D4A422E),0));
        assert(ArmorMeleeIdentified(UINT64_C(0x137988CEA16458F7),0));
        // PT-BR: Alpha Commander a 4,35 m é reduzido; Charger Behemoth com a mesma causa continua excluído.
        // EN: Alpha Commander at 4.35 m is reduced; Charger Behemoth with the same cause stays excluded.
        close_hit.net_type=UINT64_C(0xF79CD8BB654397DF);close_hit.net_distance=4.35f;
        assert(ArmorMeleeProximity(&close_hit,0xc34aac90,&distance)==ARMOR_MELEE_BY_ATTACKER && distance==4.35f);
        assert(!ArmorMeleeProximity(&close_hit,0,&distance));
        close_hit.net_type=UINT64_C(0xA05BD1EC67B3AC4C);close_hit.net_distance=1.7f;
        assert(ArmorMeleeExcluded(close_hit.net_type) && !ArmorMeleeProximity(&close_hit,0xc34aac90,&distance));
        close_hit.net_type=UINT64_C(0x905809A4C28D8A45);close_hit.net_distance=4.79f;
        assert(ArmorMeleeProximity(&close_hit,0,&distance)==ARMOR_MELEE_BY_ATTACKER);
        close_hit.net_type=UINT64_C(0xCC188F0C80505C6C);close_hit.net_distance=3.14f;
        assert(ArmorMeleeProximity(&close_hit,0,&distance)==ARMOR_MELEE_BY_ATTACKER);
        close_hit.net_type=UINT64_C(0xCCAE5264ACD591B7);
        close_hit.net_distance=1.2f;
        const uint64_t excluded[]={UINT64_C(0x1A7FCDFF98C664B0),UINT64_C(0x9E2E17F2CCCCAFDD),UINT64_C(0xDCF8E74212FBEE3B),
            UINT64_C(0x672F7DA17F3BA34A)};
        for (unsigned i=0;i<4;i++) {close_hit.net_type=excluded[i];assert(ArmorMeleeExcluded(excluded[i]) && !ArmorMeleeProximity(&close_hit,0,&distance));}
        close_hit.net_type=0;assert(!ArmorMeleeProximity(&close_hit,0,&distance) && !ArmorMeleeProximity(NULL,0,&distance));
        assert(!ArmorMeleeExcluded(UINT64_C(0xA6A68D8AF177F3A1)));
        assert(ArmorFireNative(1,0) && ArmorFireNative(0,UINT64_C(0x6DAB2EADF5D8B692)) && ArmorFireNative(0,UINT64_C(0x82A87AD8D595B2BA)));
        assert(ArmorFireNative(0,UINT64_C(0x1897BDD32105D2DC)) && !ArmorFireNative(0,UINT64_C(0xE0353177F1329573)) && !ArmorFireNative(7,0));
        ArmorMeleeSample unlisted={.cause=0xab3862b0},got;unlisted.hit.key.words[0]=91;
        ArmorMeleeClear();assert(!ArmorMeleeRemember(&unlisted,100));
        unlisted.proximity=ARMOR_MELEE_BY_ATTACKER;unlisted.distance=1.2f;assert(ArmorMeleeRemember(&unlisted,100));
        assert(ArmorMeleeMatch(&unlisted.hit.key,0xab3862b0,100,&got)==1 && got.proximity==ARMOR_MELEE_BY_ATTACKER && got.distance==1.2f);
        unlisted.hit.key.words[1]=2;assert(!ArmorMeleeRemember(&unlisted,100));
        ArmorMeleeClear();
    }
    assert(ArmorMeleeRoute(0x12a2cf7,0x7d247e) && ArmorMeleeRoute(0x12a2cf7,0x7d2e3c));
    assert(!ArmorMeleeRoute(0x12a2cf7,0x7d27cd) && !ArmorMeleeRoute(0x12a266e,0x7d247e));
    assert(ArmorMeleeDamage(40,70)==28 && ArmorMeleeDamage(26,80)==20 && ArmorMeleeDamage(22,70)==15);
    assert(ArmorMeleeDamage(UINT32_MAX,70)==3006477106u && !ArmorMeleeDamage(0,70));
    assert(ArmorMeleeDamage(40,80)==32 && ArmorMeleeDamage(40,101)==40);
    const uint32_t regions[]={0xaa1db0b0,0x1880288e,0xb6f2baf5,0x64a3fa1d,0x87b05ff4,0x8c5570c9,0};
    const uint32_t torso[3][2]={{85,85},{85,80},{75,65}},limbs[3][2]={{100,90},{85,80},{80,75}};
    for (unsigned weight=0;weight<3;weight++) for (unsigned mode=0;mode<2;mode++) for (unsigned i=0;i<7;i++)
        assert(ArmorMeleeKeepPercent(weight,regions[i],0,mode)==(i==6 ? 100 : i==5 ? 80 : i==0 ? torso[weight][mode] : limbs[weight][mode]));
    assert(ArmorMeleeKeepPercent(1,regions[0],0x37ef0820,0)==80);
    assert(ArmorMeleeKeepPercent(1,regions[0],0x37ef0820,1)==75);
    assert(ArmorMeleeKeepPercent(3,regions[0],0,1)==100);
    ArmorMeleeSample record={.cause=causes[0]},out;
    record.hit.key.words[0]=71;
    ArmorMeleeClear();assert(ArmorMeleeRemember(&record,100));
    assert(!ArmorMeleeMatch(&record.hit.key,causes[1],100,&out));
    assert(ArmorMeleeMatch(&record.hit.key,causes[0],100,&out)==1);
    assert(!ArmorMeleeMatch(&record.hit.key,causes[0],100,&out));
    assert(ArmorMeleeRemember(&record,100));assert(!ArmorMeleeMatch(&record.hit.key,causes[0],1101,&out));
    assert(ArmorMeleeRemember(&record,100));assert(!ArmorMeleeMatch(&record.hit.key,causes[0],99,&out));
    assert(ArmorMeleeRemember(&record,100));assert(ArmorMeleeRemember(&record,100));
    assert(ArmorMeleeMatch(&record.hit.key,causes[0],100,&out)==-2);
    assert(!ArmorMeleeMatch(&record.hit.key,causes[0],100,&out));
    assert(ArmorMeleeRemember(&record,100));ArmorMeleeClear();
    assert(!ArmorMeleeMatch(&record.hit.key,causes[0],100,&out));
    puts("Corpo a corpo: classificação restrita, seis perfis e percentuais regionais de 65 a 100%, overflow, consumo único, expiração e ambiguidade aprovados.");
}
static void from_hex(unsigned char *out,const char *hex) {
    for (unsigned i=0;hex[i*2];i++) {unsigned value;assert(sscanf(hex+i*2,"%2x",&value)==1);out[i]=(unsigned char)value;}
}
static const struct {uint32_t cause;const char *hit,*event;} captures[]={
    {0xf8ed1323,"0600000000000000000000000a0000000000000000000000bf0cc000000000001106000018e500b04f8c413f643e0c3faf60b73e475539c35ccd57c231ca5a41688438c3f96f55c25bf960410000000000000040000000400000c841ffff7f7f3ac10140001df23e0000000002000000000001000100010000000000c970558ca8054000950200004f8c41bf643e0cbfaf60b7be0000000000000c42000040400000000000000000000000000000a0410000704100002041000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a80540009502000000000000000000000000000000000000","11060000060000000000000018e500b0950200009502000000000000000000000000000000000000000000001a00000014000000000020410000403f3ac10140001df23e4f8c41bf643e0cbfaf60b7be475539c35ccd57c231ca5a410a0000002313edf8000000000000000000010101"},
    {0x11c4b1a5,"0600000000000000000000000a0000000000000000000000bf0cc000000000001106000019e500b06c32003fc3be5b3fc030e4bda74a39c3ed7356c2296f52415d0e39c38ed654c2889851410000000000000040000000400000c841ffff7f7f6b18a33f40ea463e00000000020000000000010001000100000000008e288018a8054000950200006c3200bfc3be5bbfc030e43d0000000000005c42000080400000000000000000000000000000a0410000a04100002041000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000a80540009502000000000000000000000000000000000000","11060000060000000000000019e500b0950200009502000000000000000000000000000000000000000000002900000014000000000020410000403f6b18a33f40ea463e6c3200bfc3be5bbfc030e43da74a39c3ed7356c2296f52410a000000a5b1c411000000000000000000010101"},
    {0xae3392c1,"0600000000000000000000000a0000000000000000000000e2078000000000001f060000362001b032361abf31481f3f010000bfd3b43ec362e979c205f36641122d3ec34ec17bc2eb9865410000000000000040000000400000c841ffff7f7f59e0dc3f00229abc0000000002000000000001000100010000000000f5baf2b6d50080008f02000032361a3f31481fbf0100003f000000000000f0410000004000000000000000000000000000002041000000000000204100000000000000000a0000000000c8420000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d50080008f02000000000000000000000000000000000000","1f0600000600000000000000362001b08f0200008f0200000000000000000000000000000000000000000000160000000a000000000020410000403f59e0dc3f00229abc32361a3f31481fbf0100003fd3b43ec362e979c205f366410a000000c19233ae000000000000000000010101"},
    {0xcae3c500,"0600000000000000000000000b000000000000000000000058068000000000008a054000c7e300b02d0501bbc37336bf0793333f09dd71c38e7e3ac2541b40414bdd71c3e3f33bc21ad945410000000000000040000000400000c841ffff7f7fc98e13400032b7bc0000000002000000000001000100010000000000f5baf2b6da008000a20200002d05013bc373363f079333bf0000000000005c42000080400000000000000000000000000000a0410000a04100002041000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000da008000a202000000000000000000000000000000000000","8a0540000600000000000000c7e300b0a2020000a202000000000000000000000000000000000000000000002900000014000000000020410000403fc98e13400032b7bc2d05013bc373363f079333bf09dd71c38e7e3ac2541b40410b00000000c5e3ca000000000000000000010101"},
    {0xe0b04680,"0600000000000000000000000a00000000000000000000007376800000000000aa02c0008d6902b0a5ca08bf9aeb403fbc04c43eb36b3fc2b7624fc33e06ee40907540c2fa044fc324faf3400000000000000040000000400000c841ffff7f7fe7db813f003e773c00000000020000000000010001000100000000008e288018bb0600004b030000a5ca083f9aeb40bfbc04c4be000000000000704200008040000000000000000000000000000020410000204100002041000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bb0600004b03000000000000000000000000000000000000","aa02c00006000000000000008d6902b04b0300004b03000000000000000000000000000000000000000000002d0000000a000000000020410000403fe7db813f003e773ca5ca083f9aeb40bfbc04c4beb36b3fc2b7624fc33e06ee400a0000008046b0e0000000000000000000010101"},
    {0x71739f3f,"0600000000000000000000000b000000000000000000000049288001000000006703c000dfe800b00562723fa1baa0be71e7903d851c1342020972c3e339c940d9cb1542fb4172c3cbd4ca400000000000000040000000400000c841ffff7f7f221913400070203c00000000020000000000010001000100000000008e2880185a03c000fc030000056272bfa1baa03e71e790bd000000000000a042000080400000000000000000000000000000a0410000a041000070410000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000005a03c000fc03000000000000000000000000000000000000","6703c0000600000000000000dfe800b0fc030000fc030000000000000000000000000000000000000069f31b3600000014000000000070410000403f221913400070203c056272bfa1baa03e71e790bd851c1342020972c3e339c9400b0000003f9f7371000000000000000000010101"},
    {0x51ba8f74,"060000000000000000000000090000000000000000000000d16cc00000000000ed03000162e201b0c819323f74e4333f229218be60e53f4141d668c333d12a40fd07434196a368c3a32128400000000000000040000000400000c841ffff7f7fe59a533fb0aed83e00000000020000000000010001000100000000008e2880181206c00099050000c81932bf74e433bf2292183e00000000000048420000404000000000000000000000000000000c420000a0410000c8410000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001206c0009905000000000000000000000000000000000000","ed030001060000000000000062e201b09905000099050000000000000000000000000000000000000000000021000000230000000000c8410000403fe59a533fb0aed83ec81932bf74e433bf2292183e60e53f4141d668c333d12a4009000000748fba51000000000000000000010101"},
    {0x5c934d9a,"0600000000000000000000000900000000000000000000000073c00000000000160400014c6703b0bfcc1d3fa981153ffd36073f1844b43f31bf7ac3e81abf3fc1d1e63f665f7ac34d6cea3f0000000000000040000000400000c841ffff7f7f2c66cd3fb06510be0000000002000000000001000100010000000000f45fb087db030001c7050000bfcc1dbfa98115bffd3607bf000000000000c842000040400000000000000000000000000000a0410000a04100007041000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000db030001c705000000000000000000000000000000000000","1604000106000000000000004c6703b0c7050000c705000000000000000000000000000000000000000000004b00000014000000000070410000403f2c66cd3fb06510bebfcc1dbfa98115bffd3607bf1844b43f31bf7ac3e81abf3f090000009a4d935c000000000000000000010101"},
};
void ArmorMeleeIntegrationTests(void) {
    extern void ArmorEquipmentFixtureReset(void),ArmorEquipmentFixtureWeight(uint32_t),ArmorEquipmentFixtureSelect(uint32_t);
    extern int ArmorEquipmentFixtureRead(uintptr_t,void *,size_t);
    extern void ArmorBridgeTestRuntime(uintptr_t);
    OwnedFixture movement;fixture_create(&movement,0x34,0x14,0x38,0x48);fixture_float(movement.records,4,1);
    unsigned char *game=VirtualAlloc(NULL,0x4000000,MEM_RESERVE,PAGE_READWRITE);assert(game);
    assert(VirtualAlloc(game+0x3326000,4096,MEM_COMMIT,PAGE_READWRITE));
    fixture_ptr(game,0x3326cf8,(uintptr_t)movement.manager);ArmorBridgeTestRuntime((uintptr_t)game);
    ArmorBridgeTestEquipment(ArmorEquipmentFixtureRead);
    ArmorBridgeEnable(1);ArmorBridgeTestIdentity(1,1);
    for (unsigned c=0;c<sizeof(captures)/sizeof(captures[0]);c++) {
        unsigned char hit[0x118],event[0x70],stack[0xa0]={0},source[16]={0};
        from_hex(hit,captures[c].hit);from_hex(event,captures[c].event);
        uint32_t avatar=word(hit,0x20);ArmorBridgeTestSetLocal(avatar);
        uintptr_t parent=UINT64_C(0x10012a2cf7),producer=UINT64_C(0x10007d247e),source_at=(uintptr_t)source;
        memcpy(stack,&parent,8);memcpy(stack+0x50,&producer,8);memcpy(stack+0x28,&source_at,8);
        put(stack,0x88,captures[c].cause);memcpy(source+8,event+0x18,8);
        unsigned char original_hit[sizeof(hit)],original_event[sizeof(event)];
        memcpy(original_hit,hit,sizeof(hit));memcpy(original_event,event,sizeof(event));
        uint32_t damage=word(event,0x2c),keep=ArmorMeleeKeepPercent(2,word(hit,0x7c),0,0);
        ArmorEquipmentFixtureReset();ArmorBridgeEnable(1);ArmorBridgeProtect(0);ArmorBridgeProtect(1);
        for (unsigned region=0;region<7;region++) {
            const uint32_t regions[]={0xaa1db0b0,0x1880288e,0xb6f2baf5,0x64a3fa1d,0x87b05ff4,0x8c5570c9,0};
            memcpy(event,original_event,sizeof(event));put(hit,0x7c,regions[region]);
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(word(event,0x2c)==ArmorMeleeDamage(damage,ArmorMeleeKeepPercent(2,regions[region],0,0)));
        }
        memcpy(hit,original_hit,sizeof(hit));
        ArmorOriginStats linked_before,linked_after;ArmorBridgeReadOrigin(&linked_before);
        ArmorTotals melee_before,melee_after;ArmorBridgeReadTotals(&melee_before);
        for (unsigned i=0;i<90;i++) {
            memcpy(event,original_event,sizeof(event));
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(word(event,0x2c)==ArmorMeleeDamage(damage,keep));
            unsigned char expected[sizeof(event)];memcpy(expected,original_event,sizeof(event));
            put(expected,0x2c,ArmorMeleeDamage(damage,keep));assert(!memcmp(event,expected,sizeof(event)));
        }
        ArmorBridgeReadTotals(&melee_after);
        if (keep<100) assert(melee_after.melee_reduced-melee_before.melee_reduced==90 && melee_after.last_kind==3
            && melee_after.melee_prevented-melee_before.melee_prevented==90*(damage-ArmorMeleeDamage(damage,keep)));
        assert(!memcmp(hit,original_hit,sizeof(hit)));
        // PT-BR: Cada evento real liga-se exatamente ao seu preparo e alimenta o resumo por causa/produtor.
        // EN: Every real event links exactly to its preparation and feeds the cause/producer summary.
        ArmorBridgeReadOrigin(&linked_after);
        assert(linked_after.linked==linked_before.linked+90 && linked_after.ambiguous==linked_before.ambiguous);
        ArmorCauseStats cause_row;int cause_found=0;
        for (uint32_t i=0;ArmorBridgeReadCause(i,&cause_row);i++)
            if (cause_row.kind==6 && cause_row.cause==captures[c].cause && cause_row.producer==0x7d247e) {
                cause_found=1;assert(cause_row.known && cause_row.reduced && cause_row.linked>=90 && cause_row.regions&1);
            }
        assert(cause_found);
        // PT-BR: Golpe letal com vida cheia (dano >= vida máxima) ou vida máxima ilegível preserva o dano.
        // EN: A strike lethal at full health (damage >= max health) or unreadable max health keeps damage.
        if (keep<100) {
            ArmorMeleeStats lethal_before,lethal_after;ArmorBridgeReadMelee(&lethal_before);
            for (unsigned limit=0;limit<2;limit++) {
                ArmorBridgeTestMaxHealth(limit ? damage-1 : damage);memcpy(event,original_event,sizeof(event));
                ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
                assert(word(event,0x2c)==damage);
            }
            ArmorBridgeReadMelee(&lethal_after);
            assert(lethal_after.lethal==lethal_before.lethal+2 && lethal_after.refused==lethal_before.refused && lethal_after.reason==7);
            ArmorBridgeTestMaxHealth(0);memcpy(event,original_event,sizeof(event));
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(word(event,0x2c)==ArmorMeleeDamage(damage,keep));
            ArmorBridgeTestMaxHealth(damage+1);memcpy(event,original_event,sizeof(event));
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(word(event,0x2c)==ArmorMeleeDamage(damage,keep));
            ArmorBridgeTestMaxHealth(1000);
        }
        ArmorMeleeStats stats;ArmorBridgeReadMelee(&stats);
        assert(stats.before==damage && stats.after==ArmorMeleeDamage(damage,keep) && !stats.reason && stats.weight==2);
        for (unsigned weight=0;weight<3;weight++) for (unsigned mode=0;mode<2;mode++) for (unsigned chest=0;chest<2;chest++) {
            ArmorEquipmentFixtureReset();ArmorEquipmentFixtureWeight(weight);fixture_u32(movement.descriptors,8,avatar);
            assert(ArmorBridgeArmorStep(123,mode));
            const uint32_t expected[3][2][2]={{{85,85},{85,85}},{{85,80},{80,75}},{{75,75},{65,65}}};
            memcpy(hit,original_hit,sizeof(hit));put(hit,0x7c,0xaa1db0b0);memcpy(event,original_event,sizeof(event));
            if (chest) assert(ArmorReplayRememberCollider((uintptr_t)hit,hit,0x37ef0820,GetTickCount64()));
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(word(event,0x2c)==ArmorMeleeDamage(damage,expected[weight][mode][chest]));
            ArmorBridgeReadMelee(&stats);assert(stats.reinforced==mode && stats.collider==(chest ? 0x37ef0820u : 0));
            memcpy(event,original_event,sizeof(event));ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);
            assert(ArmorBridgeArmorStep(123,!mode));ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(!memcmp(event,original_event,sizeof(event)));
        }
        ArmorBridgeProfileStep(0,0);ArmorBridgeHeavyStep(0);memcpy(hit,original_hit,sizeof(hit));
        ArmorBridgeReadMelee(&stats);uint32_t applied=stats.applied;
        ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
        ArmorBridgeReadMelee(&stats);assert(stats.applied==applied && stats.reason==6);
        for (unsigned refusal=0;refusal<11;refusal++) {
            ArmorEquipmentFixtureReset();ArmorBridgeTestIdentity(1,1);ArmorBridgeEnable(1);
            ArmorBridgeProtect(0);ArmorBridgeProtect(1);memcpy(event,original_event,sizeof(event));
            put(stack,0x88,captures[c].cause);memcpy(stack+0x50,&producer,8);

            if (refusal==2) put(stack,0x88,0x6644dc22);
            if (refusal==3) {uintptr_t wrong=UINT64_C(0x10007d27cd);memcpy(stack+0x50,&wrong,8);}
            if (refusal==4) put(hit,4,1);
            ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);
            if (refusal==0) ArmorEquipmentFixtureWeight(0);
            if (refusal==1) ArmorEquipmentFixtureWeight(1);
            if (refusal==5) ArmorEquipmentFixtureSelect(124);
            if (refusal==6) ArmorBridgeTestIdentity(2,1);
            if (refusal==7) ArmorBridgeTestIdentity(1,0);
            if (refusal==8) {ArmorBridgeProtect(0);ArmorBridgeProtect(1);}
            if (refusal==9) ArmorBridgeObserveLate((uintptr_t)hit,(uintptr_t)stack);
            if (refusal==10) ArmorBridgeEnable(0);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
            assert(!memcmp(event,original_event,sizeof(event)));
            memcpy(hit,original_hit,sizeof(hit));ArmorBridgeReadMelee(&stats);assert(stats.applied==applied);
        }
    }
    ArmorBridgeEnable(1);ArmorBridgeProtect(1);ArmorBridgeTestIdentity(1,1);ArmorBridgeTestSetLocal(71);
    ArmorUnknownAttack alert;assert(sizeof(alert)==24);while (ArmorBridgePopUnknown(&alert)) {}
    unsigned char unknown_event[0x70];from_hex(unknown_event,captures[1].event);put(unknown_event,0,71);put(unknown_event,0x60,0x6644dc22);
    unsigned char unchanged[0x70];memcpy(unchanged,unknown_event,sizeof(unchanged));
    for (unsigned i=0;i<40;i++) ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);
    put(unknown_event,0x60,0x11c4b1a5);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);
    put(unknown_event,0x60,0x6644dc22);
    uint32_t previous=0;unsigned count=0;
    while (ArmorBridgePopUnknown(&alert)) {
        assert(alert.sequence>previous && alert.cause==0x6644dc22 && alert.damage==41 && alert.victim==71 && alert.kind==6 && !alert.element);
        previous=alert.sequence;++count;
    }
    assert(count==16 && !memcmp(unknown_event,unchanged,sizeof(unchanged)));
    put(unknown_event,8,1);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);assert(!ArmorBridgePopUnknown(&alert));
    put(unknown_event,8,0);ArmorBridgeTestIdentity(1,0);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);assert(!ArmorBridgePopUnknown(&alert));
    ArmorBridgeTestIdentity(1,1);put(unknown_event,0,72);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);assert(!ArmorBridgePopUnknown(&alert));
    put(unknown_event,0,71);put(unknown_event,0x2c,0);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);assert(!ArmorBridgePopUnknown(&alert));
    put(unknown_event,0x2c,41);put(unknown_event,0x60,0);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)unknown_event,0);assert(!ArmorBridgePopUnknown(&alert));
    puts("Avisos nativos: fila limitada de 16, ordem, consumo único, dano intacto e recusa de elemento não físico, sessão inválida, outro alvo e dano zero aprovados.");
    ArmorBridgeEnable(1);ArmorBridgeProtect(0);ArmorBridgeTestIdentity(1,1);ArmorEquipmentFixtureReset();
    ArmorBridgeHeavyStep(0);ArmorBridgeProfileStep(0,0);ArmorBridgeTestRuntime(0);fixture_destroy(&movement);assert(VirtualFree(game,0,MEM_RELEASE));
    puts("Capturas reais: 720 eventos repetidos e 56 cenários regionais, apenas dano alterado e cabeça com 20%; seis perfis e peitoral identificado; sem redução em habilidade desconhecida, sessão/identidade/equipamento divergentes, modo desligado ou captura ambígua.");
}
