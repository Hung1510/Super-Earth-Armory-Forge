#include "runtime_fixture.h"
#include "actor_bridge.h"
#include "ergonomics.h"
#include "swimming.h"
#include <stdio.h>
#include <math.h>
static void *allocation(size_t size) {
    void *p=VirtualAlloc(NULL,size,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);assert(p);return p;
}
static void mapped_pointer(unsigned char *base,unsigned offset,uintptr_t value) {
    uintptr_t page=((uintptr_t)base+offset)&~(uintptr_t)4095;
    assert(VirtualAlloc((void *)page,4096,MEM_COMMIT,PAGE_READWRITE));fixture_ptr(base,offset,value);
}
static void hash(unsigned char *manager,unsigned off,uint32_t (*rows)[2],uint32_t entity) {
    rows[0][0]=rows[1][0]=UINT32_MAX;rows[entity&1][0]=entity;rows[entity&1][1]=0;
    fixture_ptr(manager,off,(uintptr_t)rows);fixture_u32(manager,off+8,2);
    fixture_u32(manager,off+12,UINT32_MAX);fixture_u32(manager,off+16,1);
}
void ArmorLocalRuntimeTests(void) {
    extern void ArmorBridgeTestRuntime(uintptr_t);
    extern void ArmorEquipmentFixtureReset(void);
    extern void ArmorEquipmentFixtureWeight(uint32_t);
    extern int ArmorBridgeSwimStep(int);
    OwnedFixture weapon,air,movement;fixture_create(&weapon,0x3f0,0x20,0x48,0x58);fixture_create(&air,28,0x14,0x38,0x40);
    fixture_create(&movement,0x34,0x14,0x38,0x48);fixture_float(movement.records,4,1);
    unsigned char *game=VirtualAlloc(NULL,0x4000000,MEM_RESERVE,PAGE_READWRITE);
    unsigned char *entities=VirtualAlloc(NULL,0x1000000,MEM_RESERVE,PAGE_READWRITE);
    assert(game && entities);
    unsigned char *inventory=allocation(4096),*wielder=allocation(4096),*invrecords=allocation(4096),*slots=allocation(4096);
    unsigned char *weapon_table=allocation(0x100000),*water_table=allocation(16384);
    uint32_t ih[2][2],wh[2][2];hash(inventory,0x28,ih,71);hash(wielder,0x30,wh,71);
    fixture_ptr(inventory,0x50,(uintptr_t)invrecords);fixture_ptr(wielder,0x60,(uintptr_t)slots);
    fixture_u32(invrecords,0,555);fixture_u32(invrecords,4,557);fixture_u32(invrecords,28,1);fixture_u32(slots,0,555);
    uint64_t resource=UINT64_C(0x1234567812345678);memcpy(weapon.descriptors,&resource,8);fixture_u32(weapon.descriptors,8,555);
    memcpy(weapon_table,&resource,8);fixture_float(weapon_table,730*16+356,65);
    resource=UINT64_C(0x4d1c334d294dfa97);memcpy(water_table,&resource,8);fixture_float(water_table,122*16+12,5);
    mapped_pointer(game,0x3326738,(uintptr_t)inventory);mapped_pointer(game,0x3326420,(uintptr_t)wielder);
    mapped_pointer(game,0x3326ce0,(uintptr_t)weapon.manager);mapped_pointer(game,0x3326a80,(uintptr_t)air.manager);
    mapped_pointer(game,0x3326cf8,(uintptr_t)movement.manager);
    mapped_pointer(game,0x346bf98,(uintptr_t)entities);mapped_pointer(entities,0xf12bd8,(uintptr_t)weapon_table);
    mapped_pointer(entities,0xf12e20,(uintptr_t)water_table);
    ArmorOwnedRecord found;float source;
    assert(ArmorLocalMovement(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found));
    assert(found.record==(uintptr_t)movement.records && !ArmorLocalMovement(ArmorRuntimeReadSelf,(uintptr_t)game,72,&found));
    assert(ArmorLocalPrimary(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source) && source==65);
    assert(found.record==(uintptr_t)weapon.records && ArmorOwnedValidate(ArmorRuntimeReadSelf,&found));
    fixture_u32(slots,0,557);assert(!ArmorLocalPrimary(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source));
    fixture_u32(slots,0,555);fixture_u32(invrecords,28,2);assert(!ArmorLocalPrimary(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source));
    fixture_u32(invrecords,28,1);fixture_u32(weapon.descriptors,20,0);assert(!ArmorLocalPrimary(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source));
    fixture_u32(weapon.descriptors,20,1);
    assert(ArmorLocalAir(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source) && source==5);
    fixture_u32(air.descriptors,8,72);assert(!ArmorLocalAir(ArmorRuntimeReadSelf,(uintptr_t)game,71,&found,&source));fixture_u32(air.descriptors,8,71);
    unsigned char remote[0x3f0];memset(weapon.records+0x3f0,0x83,0x3f0);memcpy(remote,weapon.records+0x3f0,0x3f0);
    float e=.7f;fixture_float(weapon.records,0x360,70);fixture_float(weapon.records,0x3a8,70);
    fixture_float(weapon.records,0x340,1+19*e*e);fixture_float(weapon.records,0x344,1+.5f*e);
    unsigned char original[0x3f0];memcpy(original,weapon.records,0x3f0);
    ArmorBridgeTestRuntime((uintptr_t)game);ArmorBridgeTestSetLocal(71);ArmorBridgeTestIdentity(1,1);
    extern int ArmorEquipmentFixtureRead(uintptr_t,void *,size_t);
    ArmorBridgeTestEquipment(ArmorEquipmentFixtureRead);
    ArmorBridgeEnable(1);ArmorEquipmentFixtureReset();
    for (unsigned weight=0;weight<3;weight++) {
        ArmorEquipmentFixtureWeight(weight);assert(ArmorBridgeErgoStep(1));
        float expected=70*(weight==0 ? 1.15f : weight==2 ? .80f : 1);
        assert(fabsf(fixture_value(weapon.records,0x3a8)-expected)<.0001f);
        assert(!memcmp(remote,weapon.records+0x3f0,0x3f0));
        ArmorBridgeEnable(0);assert(!memcmp(original,weapon.records,0x3f0));ArmorBridgeEnable(1);
    }
    const float factors[3][2]={{1.15f,1.1f},{1.f,.9f},{.8f,.8f}};
    for (unsigned weight=0;weight<3;weight++) for (unsigned mode=0;mode<2;mode++) {
        ArmorEquipmentFixtureWeight(weight);assert(ArmorBridgeProfileStep(123,mode));assert(ArmorBridgeErgoStep(1));
        assert(fabsf(fixture_value(weapon.records,0x3a8)-70*factors[weight][mode])<.0001f);
        assert(!memcmp(remote,weapon.records+0x3f0,0x3f0));assert(ArmorBridgeErgoRestore());
        assert(!memcmp(original,weapon.records,0x3f0));
    }
    ArmorBridgeProfileStep(0,0);
    assert(fixture_value(weapon_table,730*16+356)==65 && fixture_value(water_table,122*16+12)==5);
    ArmorBridgeTestIdentity(1,0);assert(!ArmorBridgeErgoStep(1));
    ArmorBridgeTestIdentity(1,1);ArmorEquipmentFixtureWeight(0);assert(ArmorBridgeErgoStep(1));
    ArmorBridgeEnable(0);assert(!memcmp(original,weapon.records,0x3f0));
    ArmorBridgeEnable(1);air.records[0]=1;fixture_float(air.records,20,4);
    assert(ArmorBridgeSwimStep(1) && fixture_value(air.records,20)==5);
    // PT-BR: A leve reforçada também repõe o fôlego.
    // EN: Reinforced light also refills breath.
    assert(ArmorBridgeProfileStep(123,1));fixture_float(air.records,20,4);
    assert(ArmorBridgeSwimStep(1) && fixture_value(air.records,20)==5);fixture_float(air.records,20,4);
    assert(ArmorBridgeProfileStep(123,0));assert(ArmorBridgeSwimStep(1) && fixture_value(air.records,20)==5);
    ArmorEquipmentFixtureWeight(2);fixture_float(air.records,20,4);
    assert(ArmorBridgeSwimStep(1) && fixture_value(air.records,20)==4);
    ArmorBridgeProtect(1);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==.95f);
    for (unsigned i=0;i<100;i++) {
        assert(ArmorBridgeArmorStep(123,1) && fixture_value(movement.records,4)==.9f);
        assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==.95f);
    }
    assert(!ArmorBridgeArmorStep(124,1) && fixture_value(movement.records,4)==1);
    // PT-BR: Leve: padrão +10%, reforçada +5%; trocar para média restaura o fator nativo.
    // EN: Light: standard +10%, reinforced +5%; switching to medium restores the native factor.
    ArmorBridgeTestHurt(0);
    ArmorEquipmentFixtureWeight(0);
    for (unsigned i=0;i<100;i++) {
        assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==1.10f);
        assert(ArmorBridgeArmorStep(123,1) && fixture_value(movement.records,4)==1.05f);
    }
    ArmorEquipmentFixtureWeight(2);
    assert(ArmorBridgeArmorStep(123,0));ArmorEquipmentFixtureWeight(1);
    assert(ArmorBridgeArmorStep(123,1) && fixture_value(movement.records,4)==1);
    // PT-BR: Lentidão ao levar golpe: leve x0,75 por 1,5 s, média 0,85 por 1 s, pesada sem lentidão; depois volta ao normal.
    // EN: Slow-on-hit: light x0.75 for 1.5 s, medium 0.85 for 1 s, heavy no slow; afterwards it returns to normal.
    ArmorBridgeTestNow(100000);ArmorBridgeTestHurt(99000);
    ArmorEquipmentFixtureWeight(0);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==1.10f*.75f);
    assert(ArmorBridgeArmorStep(123,1) && fixture_value(movement.records,4)==1.05f*.75f);
    ArmorEquipmentFixtureWeight(1);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==.85f);
    ArmorEquipmentFixtureWeight(2);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==.95f);
    ArmorBridgeTestNow(100200);
    ArmorEquipmentFixtureWeight(1);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==1);
    ArmorEquipmentFixtureWeight(0);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==1.10f*.75f);
    ArmorBridgeTestNow(100600);
    assert(ArmorBridgeArmorStep(123,0) && fixture_value(movement.records,4)==1.10f);
    ArmorBridgeTestNow(0);ArmorBridgeTestHurt(0);
    ArmorEquipmentFixtureWeight(2);ArmorBridgeProfileStep(0,0);
    assert(ArmorBridgeHeavyStep(1) && fixture_value(movement.records,4)==.9f);
    ArmorEquippedStats equipped;ArmorBridgeReadEquipped(&equipped);
    assert(sizeof(equipped)==16 && equipped.valid==1 && equipped.weight==2 && equipped.avatar==71);
    // PT-BR: Cache de 250 ms: troca de categoria só aparece após expirar ou mudar a época de proteção.
    // EN: 250 ms cache: a category change appears only after expiry or a protection epoch change.
    ArmorBridgeTestCategoryCache(60000);ArmorBridgeReadEquipped(&equipped);assert(equipped.weight==2);
    ArmorEquipmentFixtureWeight(1);ArmorBridgeReadEquipped(&equipped);assert(equipped.valid==1 && equipped.weight==2);
    ArmorBridgeProtect(0);ArmorBridgeProtect(1);ArmorBridgeReadEquipped(&equipped);assert(equipped.weight==1);
    ArmorEquipmentFixtureWeight(2);ArmorBridgeTestCategoryCache(0);ArmorBridgeReadEquipped(&equipped);assert(equipped.weight==2);
    assert(!ArmorBridgeHeavyArmorStep(equipped.armor_id+1) && fixture_value(movement.records,4)==1);
    assert(ArmorBridgeHeavyArmorStep(equipped.armor_id) && fixture_value(movement.records,4)==.9f);
    assert(ArmorBridgeHeavyStep(1) && fixture_value(movement.records,4)==.9f);
    ArmorEquipmentFixtureWeight(1);assert(!ArmorBridgeHeavyStep(1) && fixture_value(movement.records,4)==1);
    ArmorEquipmentFixtureWeight(2);assert(ArmorBridgeHeavyStep(1));
    assert(!ArmorBridgeHeavyStep(0) && fixture_value(movement.records,4)==1);
    ArmorBridgeTestIdentity(1,0);assert(!ArmorBridgeHeavyStep(1) && fixture_value(movement.records,4)==1);
    ArmorBridgeTestIdentity(1,1);assert(ArmorBridgeHeavyStep(1));
    ArmorBridgeEnable(0);ArmorBridgeTestRuntime(0);
    assert(fixture_value(movement.records,4)==1);
    fixture_destroy(&weapon);fixture_destroy(&air);fixture_destroy(&movement);
    for (unsigned i=0;i<8;i++) {
        void *p=((void *[]){game,entities,inventory,wielder,invrecords,slots,weapon_table,water_table})[i];
        assert(VirtualFree(p,0,MEM_RELEASE));
    }
    puts("Localizadores proprios aprovados: inventario, arma segurada, dono, categorias e folego; catalogos e jogador remoto intactos; nenhum Ammunition utilizado.");
}
