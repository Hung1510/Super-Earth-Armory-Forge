local function u32(n)
    local parts={}
    for i=1,4 do parts[i]=string.char(n%256);n=math.floor(n/256) end
    return table.concat(parts)
end
local function ptr(n) return u32(n%4294967296)..u32(math.floor(n/4294967296)) end
local function put(s,offset,bytes) return s:sub(1,offset)..bytes..s:sub(offset+#bytes+1) end
local memory,draws,closed,binds={}, {},0,0
local surface_instance,resources_ready
resources_ready=true
local env={};setmetatable(env,{__index=_G});env._G=env
env.HAPI18n=assert(loadfile(HAP_ROOT..'/src/i18n.lua'))()
env.HAPSilhouette=assert(loadfile(HAP_ROOT..'/src/silhouette.lua'))()
env.HAPSurface={new=function()
    surface_instance={
        close=function() closed=closed+1;surface_instance.gui=nil end,
        ready=function() return resources_ready end,
        valid=function() return resources_ready end,
        bind=function() binds=binds+1;surface_instance.gui=true;return true end,
        sync=function(items) draws[#draws+1]=items;return true end}
    return surface_instance
end}
local file=assert(io.open(HAP_ROOT..'/src/presentation.lua','rb'));local source=file:read('*a');file:close()
local mod=setfenv(assert(loadstring(source)),env)()
local base=0x1000000000
local menu,manager,owner,catalog,array,armor,helmet=0x100000,0x200000,0x300000,0x400000,0x500000,0x600004,0x610004
memory[base+0x347ce28]=ptr(menu);memory[menu+0x4294]=u32(5)
memory[base+0x3326e68]=ptr(manager);memory[manager+0x166c]=u32(1)
memory[manager+0x1670]=ptr(owner)..u32(224)..u32(0)
memory[owner+0x7fde8+0x92fc4]=u32(3);memory[owner+0x136f5c]=u32(101)
local panel=owner+0x119488+0x91c0
memory[panel]=u32(0x10);memory[panel+84]=u32(0x3f800000)
memory[base+0x33264f8]=ptr(catalog);memory[catalog]=ptr(array)..u32(2)
memory[array]=ptr(armor)..ptr(helmet)
memory[armor]=put(put(put(string.rep('\0',64),0,u32(101)),48,ptr(0x700000)),56,ptr(1))
memory[helmet]=put(put(string.rep('\0',64),0,u32(102)),40,u32(1))
memory[0x700000]=ptr(0)..ptr(0x800004)..ptr(13)
for i=0,12 do memory[0x800004+i*96]=put(string.rep('\0',20),16,u32(i==0 and 1 or 2)) end
for _,font in ipairs({{0x1388044,'\x48\x8b\x3d'},{0x1388054,'\x48\x8b\x35'},{0x1388030,'\x48\x8b\x1d'}}) do
    memory[base+font[1]]=font[2]..u32(64)
    memory[base+font[1]+7+64]=font[1]==0x1388030 and ptr(0x900000) or string.rep('\1',8)
end
memory[0x900000+24]=string.rep('\2',8)
local applied,restored=0,0
local saved_profiles
local api={game_base=function() return base end,
    load_profiles=function() return saved_profiles end,
    save_profiles=function(data) saved_profiles=data;return true end,
    heavy_step=function() return 1 end,
    profile_step=function() return 1 end,
    swim_step=function() return 1 end,
    readonly=function(at,size) local data=memory[at];if data and #data>=size then return data:sub(1,size) end end,
    ergo_restore=function() restored=restored+1;return 1 end,
    ergo_step=function(wanted) assert(wanted);applied=applied+1;return 1 end,
    ergo_stats=function() return {weight=2,reason=0,before=60,expected=54,observed=54,record=0xa00000} end}
local sr={Gui={resolution=function() return 1920,1080 end},Application={main_world=function() return 'principal' end,
    worlds=function() return {'principal','menu'} end}}
local profiles=assert(loadfile(HAP_ROOT..'/src/profiles.lua'))().new(api,function() end)
local ui=mod.new(api,function() end,profiles)

local function part(id)
    for _,item in ipairs(draws[#draws] or {}) do if item.id==id then return item end end
end
local box=mod.selector_layout(1920,1080)
assert(box.x==875 and box.y==960 and box.w==220 and box.h==44)
for _,resolution in ipairs({{1280,720},{2560,1080},{3840,2160}}) do
    local layout=mod.selector_layout(resolution[1],resolution[2])
    assert(layout.x>=0 and layout.x+layout.w+442*layout.scale<=resolution[1])
    assert(layout.y-76*layout.scale>526*layout.scale)
end
local mouse={x=box.x-10,y=box.y+20,down=false}
api.cursor=function() return mouse.x,mouse.y,mouse.down end
local clock=0
local function step(language,protection,ergonomics,swimming,descriptions)
    clock=clock+1
    ui.step(sr,clock,true,protection~=false,ergonomics~=false,language or 1,swimming,descriptions)
end
local function color(id,r,g,b)
    local p=assert(part(id),id)
    assert(p.color[2]==r and p.color[3]==g and p.color[4]==b,id)
end
local function weight(n)
    for i=0,12 do memory[0x800004+i*96]=put(string.rep('\0',20),16,u32(n)) end
end
step()
assert(part('selector_value').text=='STANDARD (AV3)')
assert(not part('title') and not part('line1') and not part('card_background'))
-- PT-BR: Um redesenho extra logo após criar o painel; depois disso, quadros iguais não redesenham.
-- EN: One extra redraw right after creating the panel; after that, identical frames do not redraw.
local first_draws=#draws;step();assert(#draws==first_draws+1)
local previous_draws=#draws;step();assert(#draws==previous_draws)
mouse.x=box.x+20;step()
assert(part('card_title').text=='STANDARD ARMOR - HEAVY')
assert(ui.body_values.chest==3 and part('stat_value_chest')==nil and part('stat_value_speed').text=='-5%')
-- PT-BR: Silhueta da pesada padrão: cabeça/peito/tronco AV3, membros AV2; lentidão "nenhuma" em verde.
-- EN: Heavy standard silhouette: head/chest/torso, arms and legs AV3; slow "none" in green.
assert(ui.body_values.head==3 and ui.body_values.chest==3 and ui.body_values.torso==3 and part('body_label_head')==nil)
assert(ui.body_values.legs==3 and part('body_a_1') and part('body_b_197'))
assert(ui.body_values.arms==3 and ui.body_values.legs==3 and ui.body_values.shoulders==3 and part('stat_value_shoulders')==nil and part('stat_value_limbs')==nil)
assert(part('legend_text_0').text=='NONE' and part('legend_text_4').text=='AV4' and part('legend_box_2'))
assert(part('stat_value_slow').text=='NONE');color('stat_value_slow',120,230,85)
assert(part('stat_value_gaps').text=='20% full damage');color('stat_value_gaps',255,80,65)
-- PT-BR: O mouse vai do seletor até a linha das frestas: o cartão continua aberto e mostra a explicação flutuante.
-- EN: The mouse moves from the selector to the gaps row: the card stays open and shows the floating explanation.
do
    local r=assert(ui.row_rects.gaps)
    local bx,by=mouse.x,mouse.y
    mouse.x,mouse.y=box.x+box.w+4,box.y+10;step()
    assert(part('card_title') and not part('tooltip_background'))
    mouse.x,mouse.y=r.x+r.w/2,r.y+r.h/2;step()
    assert(part('card_title') and part('stat_hover') and part('tooltip_background') and part('tooltip_text_1'))
    assert(part('tooltip_text_1').text:find('Heavy armor only',1,true))
    mouse.x,mouse.y=r.x+r.w/2,r.y-200;step();assert(not part('tooltip_background'))
    mouse.x,mouse.y=bx,by;step()
end
assert(part('stat_value_melee_torso').text=='-25%' and part('stat_value_melee_limbs').text=='-20%')
color('stat_value_melee_torso',120,230,85);color('stat_value_melee_limbs',120,230,85)
color('stat_value_ergo',255,80,65)
color('stat_value_speed',255,80,65);color('stat_label_ergo',235,235,235)
local card=part('card_background')
assert(card.x>=box.x+box.w+12 and card.y>526 and card.x+card.w<=1920)
mouse.x=box.x-10;step();assert(not part('card_background'))
mouse.x=box.x+20;mouse.down=true;step();assert(ui.open and part('profile_row2'))
step();assert(ui.open and not profiles.get(101))
mouse.y=box.y-72-4+18;mouse.down=false;step()
assert(part('card_title').text=='REINFORCED ARMOR - HEAVY' and ui.body_values.chest==4)
assert(ui.body_values.chest==4 and ui.body_values.torso==3)
assert(part('stat_value_speed').text=='-10%' and not profiles.get(101))
assert(part('selector_value').text=='STANDARD (AV3)')
color('stat_value_speed',255,80,65)
mouse.down=true;step()
assert(not ui.open and profiles.get(101) and part('selector_value').text=='REINFORCED (AV4)')
assert(not part('card_background'))
mouse.y=box.y+20;mouse.down=false
for language=1,3 do
    step(language)
    local words=env.HAPI18n.get(language)
    assert(part('card_title').text==words.card_av4..' - '..words.armor_names[2] and part('card_description').text==words.card_heavy)
    assert(ui.body_values.chest==4 and part('stat_label_chest')==nil)
end
step(2,false,false)
assert(part('stat_value_protection')==nil and part('stat_value_ergo').text=='DESLIGADA')
assert(part('stat_value_speed').text=='DESLIGADA')
assert(part('stat_value_melee_torso').text=='DESLIGADA' and part('stat_value_melee_limbs').text=='DESLIGADA')
color('stat_value_ergo',180,180,180)
mouse.down=true;step(2);assert(ui.open)
mouse.y=box.y-36-4+18;mouse.down=false;step(2)
assert(ui.body_values.chest==3 and part('stat_value_chest')==nil and part('stat_value_speed').text=='-5%')
assert(profiles.get(101) and part('selector_value').text=='REFORÇADA (AV4)')
local successful_save=api.save_profiles;api.save_profiles=function() return false end
mouse.down=true;step(2)
assert(profiles.get(101) and part('profile_error') and part('selector_value').text=='REFORÇADA (AV4)')
api.save_profiles=successful_save
local armor2=0x620004
memory[armor2]=put(memory[armor],0,u32(103));memory[catalog]=ptr(array)..u32(3)
memory[array]=ptr(armor)..ptr(helmet)..ptr(armor2);memory[owner+0x136f5c]=u32(103)
mouse.y=box.y+20;step(2)
assert(not profiles.get(103) and not ui.open and part('selector_value').text=='PADRÃO (AV3)')
assert(not part('profile_error'))
step(2,true,true,false,false)
assert(part('selector') and part('card_title') and not part('title'))
mouse.down=false;step(2);mouse.down=true;step(2);assert(ui.open)
mouse.x=nil;step(2);assert(not ui.open and ui.down==nil and not part('card_background'))
mouse.x,mouse.y,mouse.down=box.x+20,box.y+20,false
weight(0);step(2,true,true,true)
assert(part('selector_arrow') and part('selector_value').text=='PADRÃO')
assert(ui.body_values.legs==0 and part('stat_value_ergo').text=='+15%' and ui.body_values.shoulders==2)
assert(ui.body_values.legs==0 and ui.body_values.chest==2 and part('stat_value_slow').text=='-25% 1,5 s')
color('stat_value_slow',255,80,65)
assert(part('stat_value_melee_torso').text=='-15%' and part('stat_value_melee_limbs').text=='0%')
assert(part('stat_value_speed').text=='+10%')
color('stat_value_ergo',120,230,85)
assert(part('stat_value_swim').text=='SIM')
mouse.down=true;step(2);assert(ui.open and part('profile_row2'))
mouse.y=box.y-72-4+18;mouse.down=false;step(2,true,true,true)
assert(part('stat_value_ergo').text=='+10%' and ui.body_values.legs==1 and part('stat_value_melee_limbs').text=='-10%')
assert(ui.body_values.legs==1 and ui.body_values.shoulders==3)
assert(part('stat_value_speed').text=='+5%')
assert(part('stat_value_swim').text=='SIM' and not profiles.get(103))
mouse.down=true;step(2,true,true,true);assert(profiles.get(103) and not ui.open)
mouse.y=box.y+20;mouse.down=false;step(2,true,true,true)
assert(part('stat_value_ergo').text=='+10%' and part('stat_value_swim').text=='SIM')
assert(profiles.choose(103,false));step(2,true,true,true)
mouse.down=false;step(2,false,false,false)
assert(part('stat_value_swim').text=='NÃO' and part('stat_value_ergo').text=='DESLIGADA')
step(2,true,true,false,false);assert(surface_instance.gui and part('selector_arrow'))
weight(1);step(3)
assert(part('card_title').text==env.HAPI18n.get(3).card_av3..' - '..env.HAPI18n.get(3).armor_names[1])
assert(ui.body_values.chest==3 and ui.body_values.torso==2)
assert(ui.body_values.legs==2 and part('stat_value_ergo').text=='0%')
assert(ui.body_values.torso==2 and part('stat_value_slow').text=='-15% 1 s')
-- PT-BR: Frestas nos braços só na pesada.
-- EN: Arm gaps only on heavy.
assert(part('stat_value_gaps')==nil)
assert(ui.body_values.shoulders==3 and ui.body_values.shins==3 and ui.body_values.shins==3 and ui.body_values.legs==2)
color('stat_value_ergo',235,235,235)
assert(part('stat_value_melee_chest').text=='-20%' and not part('stat_value_melee_torso') and part('stat_value_melee_limbs').text=='-15%')
assert(profiles.choose(103,true));step(3)
assert(ui.body_values.chest==3 and part('stat_value_speed').text=='0%')
assert(part('stat_value_melee_chest').text=='-25%' and not part('stat_value_melee_torso') and part('stat_value_melee_limbs').text=='-20%')
assert(part('stat_value_melee_limbs').text=='-20%' and part('stat_value_ergo').text=='-10%' and part('stat_value_angled')==nil)
-- PT-BR: Média reforçada: antebraço AV3 na silhueta.
-- EN: Reinforced medium: forearm AV3 on the silhouette.
assert(ui.body_values.arms==3)
assert(profiles.choose(103,false))
memory[owner+0x136f5c]=u32(102);memory[owner+0x7fde8+0x92fc4]=u32(6)
step(2)
assert(part('card_title').text=='BLINDAGEM DO CAPACETE' and ui.body_values.head==3 and part('stat_value_head')==nil)
assert(not part('stat_value_ergo') and not part('selector_arrow'))
mouse.x=box.x-10;step(2);assert(not part('card_title') and part('selector_value').text=='AV3')
mouse.x=box.x+20
for language=1,3 do step(language);assert(part('card_title').text==env.HAPI18n.get(language).helmet_title) end
-- PT-BR: Capacete: só a cabeça aparece pintada; o resto do corpo fica apagado e sem rótulo.
-- EN: Helmet: only the head is painted; the rest of the body is dimmed and unlabeled.
assert(ui.body_values.head==3 and part('body_a_100') and ui.body_values.chest==nil and part('stat_value_slow')==nil)
step(99);assert(part('card_title').text=='HELMET PROTECTION')
local count=#draws
memory[panel+84]=u32(0);step();assert(#draws==count and not surface_instance.gui)
step();assert(#draws==count and memory[owner+0x136f5c]==u32(102))
memory[panel+84]=u32(0x3f800000);step();assert(surface_instance.gui)
memory[panel]=u32(0);ui.before_ui(sr,true);assert(not surface_instance.gui)
memory[panel]=u32(0x10);memory[panel+84]=nil;assert(not mod.detail_visible(api.readonly,owner))
memory[panel+84]=u32(0x3f000000);assert(not mod.detail_visible(api.readonly,owner))
memory[panel+84]=u32(0x7fc00000);assert(not mod.detail_visible(api.readonly,owner))
memory[panel+84]=u32(0x3f800000);assert(mod.detail_visible(api.readonly,owner))
step();resources_ready=false
local previous_closed=closed;ui.before_ui(sr,true);assert(closed==previous_closed+1 and not surface_instance.gui)
resources_ready=true;step();resources_ready=false;previous_closed=closed
step();assert(closed==previous_closed+1 and not surface_instance.gui)
resources_ready=true;step();memory[menu+0x4294]=u32(0)
ui.before_ui(sr,true);assert(not surface_instance.gui);memory[menu+0x4294]=u32(5)
memory[helmet]=put(memory[helmet],40,u32(2));count=#draws;step();assert(#draws==count and not surface_instance.gui)
memory[helmet]=put(memory[helmet],40,u32(1));memory[owner+0x136f5c]=u32(104)
step();assert(#draws==count)
memory[owner+0x136f5c]=u32(101);weight(2)
memory[0x800004+12*96]=put(string.rep('\0',20),16,u32(3));step();assert(#draws==count)
weight(2);step();ui.step(sr,9000,false,true,true);assert(not surface_instance.gui)
ui.ergo_after(false);assert(applied==0)
ui.ergo_after(true);assert(applied==1)
assert(ui.ergo_status=='aplicada e relida na principal local' and ui.ergo_sample.observed==54)
assert(rawget(env,'HD2EnhancedAmmoEngine')==nil)
api.ergo_step=function() return 0 end
api.ergo_stats=function() return {weight=4294967295,reason=3,record=0} end
ui.ergo_after(true);assert(ui.ergo_status=='aguardando missão confirmada')
ui.stop()
api.ergo_step=function() return 1 end
api.ergo_stats=function() return {weight=1,reason=0,before=60,expected=60,observed=60,record=0xa00000} end
ui.ergo_after(true);assert(ui.ergo_status=='ergonomia original confirmada')
ui.stop()
local swim_wanted
api.swim_step=function(wanted,at) assert(at==nil);swim_wanted=wanted end
ui.swim_after(true);assert(swim_wanted)
ui.swim_after(false);assert(not swim_wanted)
local baseline,value,pending,factor=100,100,nil,1.1
api.ergo_restore=function()
    if pending then assert(math.abs(value-pending*factor)<0.00001);value=pending;pending=nil end
    return 1
end
api.ergo_step=function(wanted)
    assert(wanted and not pending and value==baseline)
    pending=value;value=value*factor;return 1
end
api.ergo_stats=function() return {weight=0,reason=0,before=baseline,expected=baseline*factor,observed=value,record=0xa00000} end
for frame=1,1000 do
    ui.ergo_after(true);assert(math.abs(value-baseline*factor)<0.00001)
    ui.ergo_before();assert(value==baseline and not pending)
    baseline=frame%2==0 and 65 or 80;value=baseline
end
ui.ergo_after(false);assert(value==baseline and not pending)
ui.stop();assert(value==baseline)
assert(mod.pointer(ptr(0x600004))==0x600004 and not mod.pointer(ptr(0x600003)))

print('Interface aprovada: indicador compacto, painel somente ao passar o mouse ou abrir, valores coloridos, prévia sem gravar, escolha por modelo, três idiomas e limpeza ao sair. Testes isolados; sem jogo utilizado.')
