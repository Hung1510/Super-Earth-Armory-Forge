#include "ergonomics.h"
#include "runtime_fixture.h"
#include <math.h>
#include <stdio.h>
static void values(unsigned char *r,float v) {
    float e=fminf(v,100)*0.01f;
    fixture_float(r,0x360,v);fixture_float(r,0x3a8,v);
    fixture_float(r,0x340,1+19*e*e);fixture_float(r,0x344,1+0.5f*e);
}
void ArmorErgonomicsTests(void) {
    OwnedFixture f;fixture_create(&f,0x3f0,0x20,0x48,0x58);
    unsigned char initial[0x3f0],remote[0x3f0];
    memset(f.records,0x31,0x3f0);values(f.records,70);memcpy(initial,f.records,sizeof(initial));
    memset(f.records+0x3f0,0x65,0x3f0);memcpy(remote,f.records+0x3f0,sizeof(remote));
    ArmorErgoStats stats;assert(sizeof(stats)==72);
    for (unsigned cycle=0;cycle<1000;cycle++) for (unsigned weight=0;weight<3;weight++) {
        assert(ArmorErgoApply(&f.local,65,weight));
        float expected=70*(weight==0 ? 1.15f : weight==2 ? 0.80f : 1);
        assert(fabsf(fixture_value(f.records,0x3a8)-expected)<0.0001f);
        float e=fminf(expected,100)*0.01f;
        assert(fabsf(fixture_value(f.records,0x340)-(1+19*e*e))<0.0001f);
        assert(fabsf(fixture_value(f.records,0x344)-(1+0.5f*e))<0.00001f);
        ArmorErgoReadStats(&stats);assert(stats.weight==weight && !stats.reason && stats.observed==expected);
        assert(!memcmp(remote,f.records+0x3f0,sizeof(remote)));
        if (weight!=1) assert(!ArmorErgoApply(&f.local,65,weight));
        assert(ArmorErgoRestore() && !memcmp(initial,f.records,sizeof(initial)));
    }
    for (unsigned cycle=0;cycle<1000;cycle++) {
        assert(ArmorOwnedRefresh(ArmorRuntimeReadSelf,&f.local,&f.local));
        assert(ArmorErgoApply(&f.local,65,cycle%2 ? 2 : 0));
        unsigned char swap[0x3f0];memcpy(swap,f.records,0x3f0);
        memcpy(f.records,f.records+0x3f0,0x3f0);memcpy(f.records+0x3f0,swap,0x3f0);
        uintptr_t descriptor=f.pointers[0];f.pointers[0]=f.pointers[1];f.pointers[1]=descriptor;
        assert(!ArmorOwnedValidate(ArmorRuntimeReadSelf,&f.local));
        assert(ArmorErgoRestore());
        assert(ArmorOwnedRefresh(ArmorRuntimeReadSelf,&f.local,&f.local));
        assert(!memcmp((void *)f.local.record,initial,0x3f0));
        unsigned remote_index=1-f.local.index;
        assert(!memcmp(f.records+remote_index*0x3f0,remote,0x3f0));
    }
    assert(f.local.index==0);
    assert(ArmorErgoApply(&f.local,65,0));
    unsigned char *moved=VirtualAlloc(NULL,8192,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    assert(moved);memcpy(moved,f.records,8192);
    fixture_ptr(f.manager,0x58,(uintptr_t)moved);
    assert(VirtualFree(f.records,0,MEM_RELEASE));f.records=moved;
    assert(ArmorErgoRestore());
    assert(ArmorOwnedRefresh(ArmorRuntimeReadSelf,&f.local,&f.local));
    assert(!memcmp(f.records,initial,0x3f0) && !memcmp(f.records+0x3f0,remote,0x3f0));
    assert(!ArmorErgoApply(&f.remote,65,0));assert(!memcmp(remote,f.records+0x3f0,sizeof(remote)));
    assert(ArmorErgoApply(&f.local,65,0));fixture_float(f.records,0x3a8,83);
    assert(!ArmorErgoRestore());assert(fixture_value(f.records,0x3a8)==83 && fixture_value(f.records,0x360)==70);
    values(f.records,70);assert(ArmorErgoApply(&f.local,65,2));f.descriptors[12]^=1;
    assert(!ArmorErgoRestore());assert(fabsf(fixture_value(f.records,0x3a8)-56.0f)<0.0001f);
    f.descriptors[12]^=1;values(f.records,70);
    DWORD old;assert(VirtualProtect(f.records,8192,PAGE_READONLY,&old));
    assert(!ArmorErgoApply(&f.local,65,0));assert(!memcmp(initial,f.records,sizeof(initial)));
    MEMORY_BASIC_INFORMATION page;assert(VirtualQuery(f.records,&page,sizeof(page))==sizeof(page) && page.Protect==PAGE_READONLY);
    assert(VirtualProtect(f.records,8192,PAGE_READWRITE,&old));
    fixture_float(f.records,0x340,99);assert(!ArmorErgoApply(&f.local,65,0));
    values(f.records,NAN);assert(!ArmorErgoApply(&f.local,65,0));
    ArmorErgoReadStats(&stats);assert(stats.protection_windows==0 && stats.protection_failed==0 && !stats.pending);
    fixture_destroy(&f);
    puts("Ergonomia: 3.000 ciclos e 1.000 compactacoes sem acumular fator; principal local e coeficientes relidos; remoto intacto; identidade, valores externos e paginas nao gravaveis respeitados.");
}
