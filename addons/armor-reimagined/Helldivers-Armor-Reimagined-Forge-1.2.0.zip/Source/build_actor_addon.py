import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

from build_bridge import build as build_library

ROOT = Path(__file__).resolve().parent
GUID = 'bd17fd49-74ea-49d0-af16-9d5601c4c389'
REVISION = '3d7e3a120828178573ef1ee0a5c7eeae4a951865'


def entry_text():
    binary = (ROOT / 'native-build/LobaoArmorBridge.dll').read_bytes()
    identity = hashlib.sha256(binary).hexdigest()
    encoded = ''.join('\\%03d' % value for value in binary)
    marker, _, addon = (ROOT / 'src/actor_addon.lua').read_text(encoding='utf-8').partition('\n')
    bridge = (ROOT / 'src/bridge.lua').read_text(encoding='utf-8')
    i18n = (ROOT / 'src/i18n.lua').read_text(encoding='utf-8')
    surface = (ROOT / 'src/surface.lua').read_text(encoding='utf-8')
    presentation = (ROOT / 'src/presentation.lua').read_text(encoding='utf-8')
    profiles = (ROOT / 'src/profiles.lua').read_text(encoding='utf-8')
    alerts = (ROOT / 'src/alerts.lua').read_text(encoding='utf-8')
    feedback = (ROOT / 'src/feedback.lua').read_text(encoding='utf-8')
    silhouette = (ROOT / 'src/silhouette.lua').read_text(encoding='utf-8')
    return (marker + '\nlocal HAP_BINARY_ID = "' + identity + '"\n'
            + 'local HAP_NATIVE_BYTES = "' + encoded + '"\n'
            + 'local HAP_SOURCE_NAMES = (function()\n' + (ROOT / 'src/source_names.lua').read_text(encoding='utf-8') + '\nend)()\n'
            + 'local HAPBridge = (function()\n' + bridge + '\nend)()\n'
            + 'local HAPI18n = (function()\n' + i18n + '\nend)()\n'
            + 'local HAPProfiles = (function()\n' + profiles + '\nend)()\n'
            + 'local HAPSurface = (function()\n' + surface + '\nend)()\n'
            + 'local HAPSilhouette = (function()\n' + silhouette + '\nend)()\n'
            + 'local HAPAlerts = (function()\n' + alerts + '\nend)()\n'
            + 'local HAPFeedback = (function()\n' + feedback + '\nend)()\n'
            + 'local HAPPresentation = (function()\n' + presentation + '\nend)()\n' + addon)


def build(output):
    library = build_library()
    source = entry_text()
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='armor-bridge-') as directory:
        temporary = Path(directory)
        for name in ['build_addon.py', 'archive.py']:
            with urllib.request.urlopen(f'https://raw.githubusercontent.com/CowboyBingus/BingusSharedLoader/{REVISION}/scripts/{name}', timeout=25) as response:
                (temporary / name).write_bytes(response.read())
        entry = temporary / 'entry.lua'
        entry.write_text(source, encoding='utf-8', newline='\n')
        intermediate = temporary / 'mod.zip'
        subprocess.run([sys.executable, '-B', str(temporary / 'build_addon.py'), '--name',
                        'mods/lobao/armor_probe', '--entry', str(entry), '--guid', GUID,
                        '--display-name', 'Armor Reimagined (Armory Forge Edition) - 1.2.0',
                        '--output', str(intermediate)], check=True, capture_output=True)
        with zipfile.ZipFile(intermediate) as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
    manifest = json.loads(files['manifest.json'])
    description = ('Light, medium and heavy armor finally play differently. Each class gets its own protection against shots by body region, '
                   'melee damage reduction, movement speed and weapon ergonomics, and helmets soften melee hits to the head. '
                   'Pick standard or reinforced for each armor in the Armory. Only your own character is affected; play in private lobbies or with friends. '
                   'Armory Forge Edition: heavier armor shrugs off glancing shots better. Turns itself off after game updates. Requires Bingus Shared Loader (last).')
    manifest['Description'] = description
    manifest['Options'][0]['Description'] = description
    files['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    files['README.txt'] = (ROOT / 'README_1.0.md').read_bytes()
    files['Source/entry.lua'] = source.encode('utf-8')
    files['Source/LobaoArmorBridge.dll'] = library.read_bytes()
    for name in ['build_actor_addon.py', 'build_bridge.py', 'ACTOR_BRIDGE.md',
                 'src/actor_addon.lua', 'src/bridge.lua', 'native/actor_bridge.c', 'native/actor_bridge.s',
                 'src/surface.lua', 'src/presentation.lua', 'src/i18n.lua', 'tests/test_i18n.lua', 'tests/test_surface.lua', 'native/ergonomics.c', 'native/ergonomics.h', 'native/swimming.c', 'native/swimming.h', 'native/handling.h', 'tests/swimming_test.c',
                 'tests/ergonomics_test.c', 'tests/test_presentation.lua',
                 'native/local_runtime.c', 'native/local_runtime.h', 'native/private_session.c', 'native/private_session.h',
                 'tests/runtime_fixture.h', 'tests/local_runtime_test.c', 'tests/private_session_test.c',
                 'native/movement.c', 'native/movement.h', 'tests/movement_test.c',
                 'src/profiles.lua', 'tests/test_profiles.lua', 'src/alerts.lua', 'tests/test_alerts.lua', 'src/feedback.lua', 'tests/test_feedback.lua', 'src/silhouette.lua', 'tools/generate_silhouette.py', 'assets/silhouette.png',
                 'tools/analyze_combat_log.py',
                 'native/spin_lock.h', 'native/actor_bridge.h', 'native/armor_rules.c', 'native/armor_rules.h',
                 'native/projectile_replay.c', 'native/projectile_replay.h', 'tests/projectile_replay_test.c',
                 'native/armor_equipment.c', 'native/armor_equipment.h', 'tests/armor_equipment_test.c',
                 'native/damage_commit.c', 'native/damage_commit.h', 'tests/damage_commit_test.c',
                 'src/source_names.lua', 'native/damage_source.c', 'native/damage_source.h', 'native/melee.c', 'native/melee.h', 'tests/melee_test.c', 'tests/melee_captures.json',
                 'VALIDACAO_0.16.0.md', 'VALIDACAO_0.16.1.md', 'VALIDACAO_0.16.2.md', 'VALIDACAO_0.17.0.md', 'VALIDACAO_0.17.1.md', 'VALIDACAO_0.17.2.md', 'VALIDACAO_0.18.0.md', 'VALIDACAO_0.18.1.md', 'VALIDACAO_0.18.2.md', 'VALIDACAO_0.18.3.md', 'VALIDACAO_0.19.0.md', 'VALIDACAO_0.19.1.md', 'VALIDACAO_1.0.0.md', 'README_1.0.md', 'tools/generate_source_names.py', 'native/damage_origin.c', 'native/damage_origin.h', 'tests/origin_test.c',
                 'tests/actor_bridge_test.c', 'tests/actor_bridge_test.s', 'tests/test_actor_addon.lua',
                 'tests/run_actor.py']:
        files['Source/' + name] = (ROOT / name).read_bytes()
    files['Source/build_identity.json'] = (json.dumps({'guid': GUID, 'builder_revision': REVISION}, indent=2)+'\n').encode()
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()): archive.writestr(name, data)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert json.loads(archive.read('manifest.json'))['Guid'] == GUID
        packed = archive.read('Addon/9ba626afa44a3aa3.patch_0')
        resource_entry = struct.unpack_from('<7Q6I', packed, 104)
        resource = packed[resource_entry[2]:resource_entry[2] + resource_entry[7]]
        length, mode = struct.unpack_from('<II', resource)
        assert mode == 2 and resource[8:8+length] == source.encode('utf-8')
    print('Pacote criado: ' + str(output))
    print('SHA-256: ' + hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Empacota a blindagem regional local com identificação de volumes.')
    parser.add_argument('--output', type=Path, required=True)
    build(parser.parse_args().output)
