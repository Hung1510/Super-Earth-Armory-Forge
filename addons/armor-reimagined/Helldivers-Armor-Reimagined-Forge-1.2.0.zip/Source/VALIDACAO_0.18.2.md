# Validação da 0.18.2

## Partida da 0.18.1 (10/10/2026)

Menu só com idioma e velocidade da leve confirmados pelo usuário. Medidor de performance: Regional Armor 40,9 ms/s (pior 3 ms), maior entre os mods. Painel da média mostrava "restante" e "membros" com o mesmo valor.

## Alterações

- `runtime_category` (identidade local + categoria equipada, duas leituras completas cada) guarda o resultado confirmado por 250 ms, invalidado por mudança da época de proteção (perfil, modo, proteção). Chamado várias vezes por quadro (equipado, perfil, movimento, ergonomia, natação). Escritas de movimento/ergonomia continuam validadas pelo registro próprio; a proteção de dano continua resolvendo identidade em cada golpe.
- Painel da média: linha "restante" removida; fica "membros" (mesmo valor).

## Verificação

Suítes nativa e LuaJIT/DLL/interface aprovadas, incluindo cache retendo a categoria até expirar/mudar a época. Em partida: comparar ms/s do Regional Armor no medidor.
