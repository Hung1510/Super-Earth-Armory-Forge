# Validação da 0.19.0 (coleta)

## Objetivo

Tiro bloqueado pela armadura ainda mostra sangue no ponto do impacto e na tela, porque o mod só zera o dano no evento. Para a 1.0, usar o caminho nativo de ricochete. Esta versão só coleta dados para localizar o campo do impacto que distingue ricochete de penetração.

## Alterações

- Com `RegionalArmorDiagnostics.txt`: impactos em outros alvos (preparo 0x118 bytes, tipo/nome da vítima pelo descritor de vida, chamador, produtor) e o evento de dano ligado pela chave de 13 palavras (0x70 bytes). Fila própria de 32, cota de 48 por 10 s checada antes de qualquer leitura. Somente leitura; regras de dano idênticas à 0.18.3.
- Log: `Impacto em outro alvo: etapa=...; sequência=...; ligado a=...`.

## Teste em partida

Com diagnóstico ligado: atirar com arma de penetração baixa (Liberator) na armadura de um Charger/Devastador (faísca de ricochete) e depois na parte desprotegida (penetra). Também tomar tiros bloqueados no próprio personagem para comparar o evento local.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas, incluindo fila vazia sem diagnóstico, cota/anel e impacto original intacto.
