"""Gera src/source_names.lua: nomes do raw-health.json (prioridade) e do catálogo SkyeShade já incluído."""
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT.parent / 'armor-research/raw-health.json'


def main():
    names = dict(re.findall(r'\["([0-9A-F]{16})"\]="([^"]*)"', (ROOT / 'src/source_names.lua').read_text(encoding='utf-8')))
    for entity in json.loads(RAW.read_text(encoding='utf-8'))['entities']:
        for key, value in entity.items():
            name = value.get('name')
            if name and re.fullmatch(r'0x[0-9A-Fa-f]{16}', key):
                names[key[2:].upper()] = name
    lines = ['return {'] + [f'    ["{key}"]={json.dumps(value, ensure_ascii=False)},' for key, value in sorted(names.items())] + ['}']
    (ROOT / 'src/source_names.lua').write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
    print(f'{len(names)} nomes gravados em src/source_names.lua')


if __name__ == '__main__':
    sys.exit(main())
