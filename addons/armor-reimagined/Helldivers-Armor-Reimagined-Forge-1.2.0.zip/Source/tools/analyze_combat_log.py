import argparse
import json
import math
from pathlib import Path
import re
import struct

LINE = re.compile(r'Diagnóstico de combate: etapa=(\d+); tipo=(\d+); avatar=(\d+); chamador=0x([0-9a-f]+); '
                  r'parâmetros posteriores presentes=(\d+); dados=([0-9a-f]+); parâmetros=([0-9a-f]+)\.')
ORIGIN = re.compile(r'Origem do impacto: etapa=(?P<etapa>\d+); tipo=(?P<tipo>\d+); avatar=(?P<avatar>\d+); '
                    r'sequência=(?P<sequencia>\d+); ligado=(?P<ligado>\d); ambíguo=(?P<ambiguo>\d); '
                    r'causa=0x(?P<causa>[0-9a-f]{8}); produtor=0x(?P<produtor>[0-9a-f]{8}); região=0x(?P<regiao>[0-9a-f]{8}); '
                    r'causador=(?P<causador>\d+); tipo causador=(?P<tipo_causador>[^;]+); nome causador=(?P<nome_causador>[^;]+); '
                    r'dono=(?P<dono>\d+); tipo dono=(?P<tipo_dono>[^;]+); nome dono=(?P<nome_dono>[^;]+); '
                    r'tipo mapa causador=(?P<tipo_mapa>[0-9A-F]{16}); unidade causador=(?P<unidade>\d+); (?:id completo causador=(?P<completo>\d+); )?'
                    r'distância=(?P<distancia>[^;]+); (?:alcance do golpe=(?P<alcance>[^;]+); via rede: '
                    r'entidade=(?P<rede_entidade>\d+), tipo=(?P<rede_tipo>[^,]+), nome=(?P<rede_nome>[^,]+), '
                    r'distância=(?P<rede_distancia>[^;]+); )?marcas=0x(?P<marcas>[0-9a-f]+)\.')
SUMMARY = re.compile(r'Resumo de causa: tipo=(?P<tipo>\d+); elemento=(?P<elemento>\d+); causa=0x(?P<causa>[0-9a-f]{8}); '
                     r'produtor=0x(?P<produtor>[0-9a-f]{8}); tipo causador=(?P<tipo_causador>[^;]+); '
                     r'nome causador=(?P<nome_causador>[^;]+); eventos=(?P<eventos>\d+); ligados=(?P<ligados>\d+); '
                     r'na lista corpo a corpo=(?P<conhecida>\d+); reduzidos=(?P<reduzidos>\d+); dano mín=(?P<dano_min>\d+); '
                     r'médio=(?P<dano_medio>[\d.]+); máx=(?P<dano_max>\d+); distância mín=(?P<dist_min>[^;]+); '
                     r'média=(?P<dist_media>[^;]+); máx=(?P<dist_max>[^;]+); amostras de distância=(?P<amostras>\d+); '
                     r'regiões=0x(?P<regioes>[0-9a-f]+)(?:; alcance mín=(?P<alc_min>[^;]+); médio=(?P<alc_medio>[^;]+); '
                     r'máx=(?P<alc_max>[^;]+); tipo via rede=(?P<rede_tipo>[^;]+); nome via rede=(?P<rede_nome>[^;]+); '
                     r'eventos via rede=(?P<rede_eventos>\d+))?\.')
REGIONS = ['tronco', 'cabeça', 'membro 0x1880288e', 'membro 0xb6f2baf5', 'perna esquerda', 'membro 0x87b05ff4', 'outra']


def metres(text):
    match = re.fullmatch(r'([\d.]+) m', text.strip())
    return float(match[1]) if match else None


def origins(text):
    """Junta preparo e evento pela sequência gravada pela DLL; nunca por tempo ou dano."""
    prepared, events = {}, []
    for match in ORIGIN.finditer(text):
        row = match.groupdict()
        record = {'etapa': int(row['etapa']), 'tipo': int(row['tipo']), 'avatar': int(row['avatar']),
                  'sequencia': int(row['sequencia']), 'ligado': row['ligado'] == '1', 'ambiguo': row['ambiguo'] == '1',
                  'causa': row['causa'], 'produtor': row['produtor'], 'regiao': row['regiao'],
                  'causador': int(row['causador']), 'tipo_causador': row['tipo_causador'],
                  'nome_causador': row['nome_causador'], 'dono': int(row['dono']), 'tipo_dono': row['tipo_dono'],
                  'nome_dono': row['nome_dono'], 'tipo_mapa_causador': row['tipo_mapa'],
                  'unidade_causador': int(row['unidade']),
                  'id_completo_causador': int(row['completo']) if row['completo'] else None,'distancia_m': metres(row['distancia']),
                  'alcance_golpe_m': metres(row['alcance']) if row['alcance'] else None,
                  'rede': {'entidade': int(row['rede_entidade']), 'tipo': row['rede_tipo'], 'nome': row['rede_nome'],
                           'distancia_m': metres(row['rede_distancia'])} if row['rede_entidade'] else None,
                  'marcas': int(row['marcas'], 16)}
        if record['etapa'] == 1 and record['sequencia']:
            prepared[record['sequencia']] = record
        elif record['etapa'] == 2:
            events.append(record)
    joined = []
    for event in events:
        source = prepared.get(event['sequencia']) if event['ligado'] else None
        joined.append({**event, 'preparo_registrado': source is not None,
                       'produtor_do_preparo': source['produtor'] if source else None})
    return list(prepared.values()), joined


def summaries(text):
    latest = {}
    for match in SUMMARY.finditer(text):
        row = match.groupdict()
        key = (row['tipo'], row['elemento'], row['causa'], row['produtor'], row['tipo_causador'])
        mask = int(row['regioes'], 16)
        latest[key] = {'tipo': int(row['tipo']), 'elemento': int(row['elemento']), 'causa': row['causa'],
                       'produtor': row['produtor'], 'tipo_causador': row['tipo_causador'],
                       'nome_causador': row['nome_causador'], 'eventos': int(row['eventos']),
                       'ligados': int(row['ligados']), 'na_lista_corpo_a_corpo': int(row['conhecida']),
                       'reduzidos': int(row['reduzidos']), 'dano_min': int(row['dano_min']),
                       'dano_medio': float(row['dano_medio']), 'dano_max': int(row['dano_max']),
                       'distancia_min_m': metres(row['dist_min']), 'distancia_media_m': metres(row['dist_media']),
                       'distancia_max_m': metres(row['dist_max']), 'amostras_distancia': int(row['amostras']),
                       'regioes': [name for bit, name in enumerate(REGIONS) if mask >> bit & 1],
                       'alcance_min_m': metres(row['alc_min']) if row['alc_min'] else None,
                       'alcance_medio_m': metres(row['alc_medio']) if row['alc_medio'] else None,
                       'alcance_max_m': metres(row['alc_max']) if row['alc_max'] else None,
                       'tipo_via_rede': row['rede_tipo'], 'nome_via_rede': row['rede_nome'],
                       'eventos_via_rede': int(row['rede_eventos']) if row['rede_eventos'] else None}
    return sorted(latest.values(), key=lambda row: (-row['eventos'], row['causa']))


def analyze(text):
    records = []
    for match in LINE.finditer(text):
        stage, kind, avatar = map(int, match.group(1, 2, 3))
        try:
            data, extra = bytes.fromhex(match[6]), bytes.fromhex(match[7])
        except ValueError:
            continue
        if stage not in (1, 2) or len(data) != (280 if stage == 1 else 112) or len(extra) != 20:
            continue
        record = {'etapa': stage, 'tipo': kind, 'avatar': avatar, 'chamador': match[4]}
        if stage == 1:
            raw, = struct.unpack_from('<f', data, 0x98)
            ap = struct.unpack_from('<4f', data, 0x9c)
            record.update(regiao=f'{struct.unpack_from("<I", data, 0x7c)[0]:08x}',
                          dano_na_preparacao=raw if math.isfinite(raw) else None,
                          ap_na_preparacao=[value if math.isfinite(value) else None for value in ap],
                          flags_impacto=data[0x70:0x80].hex())
            if kind == 6 and match[4] == '012a2cf7' and match[5] == '1':
                scale, _, delta = struct.unpack_from('<3f', extra, 8)
                try:
                    candidate = [struct.unpack('<f', struct.pack('<f', value + delta))[0] for value in ap]
                except OverflowError:
                    candidate = [float('nan')]
                if all(math.isfinite(value) for value in (*candidate, scale, raw)):
                    record.update(ap_candidata_apos_construtor=candidate,
                                  dano_candidato_apos_construtor=raw * scale,
                                  limite='Cópia dos parâmetros de leitura; tipo 6 ainda não comprova ataque inimigo nem AP final.')
        else:
            record['dano_calculado_original'] = struct.unpack_from('<I', data, 0x2c)[0]
        records.append(record)
    prepared, joined = origins(text)
    return {'registros': records, 'escritas': 0,
            'preparos_com_origem': prepared, 'eventos_com_origem': joined, 'resumo_causas': summaries(text),
            'limite': 'Registros brutos não são correlacionados entre si; eventos com origem (0.16.0+) usam somente a '
                      'sequência gravada pela DLL. O resumo indica candidatos, não autoriza redução. Não atribui AP fixa ao corpo a corpo.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Analisa somente os registros copiados de combate da versão 0.8.0.')
    parser.add_argument('log', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.log.read_text(encoding='utf-8', errors='replace'))
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(f'Relatório criado com {len(result["registros"])} registros, {len(result["eventos_com_origem"])} eventos com origem '
          f'e {len(result["resumo_causas"])} causas resumidas; nenhuma leitura do processo ou escrita no jogo.')
