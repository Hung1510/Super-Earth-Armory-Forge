import argparse
import hashlib
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def build(test=False):
    zig = None
    output = ROOT / 'native-build'
    output.mkdir(exist_ok=True)
    target = output / ('actor-bridge-tests.exe' if test else 'LobaoArmorBridge.dll')
    command = [sys.executable, '-m', 'ziglang', 'cc', '-target', 'x86_64-windows-gnu', '-O2', '-Wall', '-Wextra',
               '-Werror', '-Wno-unused-command-line-argument',
               '-DWIN32_LEAN_AND_MEAN', '-DNOMINMAX', '-I' + str(ROOT / 'native')]
    if test:
        command += ['-DARMOR_BRIDGE_TEST', str(ROOT / 'tests/actor_bridge_test.c'),
                    str(ROOT / 'tests/projectile_replay_test.c'),
                    str(ROOT / 'tests/armor_equipment_test.c'),
                    str(ROOT / 'tests/damage_commit_test.c'),
                    str(ROOT / 'tests/melee_test.c'),
                    str(ROOT / 'tests/origin_test.c'),
                    str(ROOT / 'tests/ergonomics_test.c'),
                    str(ROOT / 'tests/movement_test.c'),
                    str(ROOT / 'tests/swimming_test.c'),
                    str(ROOT / 'tests/local_runtime_test.c'),
                    str(ROOT / 'tests/private_session_test.c'),
                    str(ROOT / 'tests/actor_bridge_test.s')]
    else:
        command += ['-shared']
    command += [str(ROOT / 'native' / file) for file in ('actor_bridge.c', 'actor_bridge.s', 'armor_rules.c', 'projectile_replay.c', 'armor_equipment.c', 'damage_commit.c', 'melee.c', 'damage_source.c', 'damage_origin.c', 'ergonomics.c', 'movement.c', 'swimming.c', 'local_runtime.c', 'private_session.c')]
    command += ['-lbcrypt', '-o', str(target)]
    subprocess.run(command, check=True, cwd=output)
    print('Compilado: ' + str(target), flush=True)
    if test:
        subprocess.run([str(target)], check=True, cwd=output)
    print('SHA-256: ' + hashlib.sha256(target.read_bytes()).hexdigest())
    return target


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Compila o adaptador por ponteiro de dados e suas regras.')
    parser.add_argument('--test', action='store_true')
    build(parser.parse_args().test)
