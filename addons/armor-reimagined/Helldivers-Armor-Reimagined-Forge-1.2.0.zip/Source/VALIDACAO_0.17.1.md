# Validação da 0.17.1

## Partida da 0.17.0 (10/10/2026)

Regra por distância funcionou: Devastator, Devastator MK3, Rocket Devastator, Overseer (causa zero) e Fleshmob reduzidos; tiros do Overseer a 17 m chegaram como projétil e não entraram no corpo a corpo; zero recusas/ambíguos. Fleshmob bateu de 1,8 a 3,5 m e dois golpes na perna (3,01 e 3,40 m) ficaram sem redução pelo limite de 3 m.

## Alterações

- Pares atacante+causa confirmados (ID de rede) aceitos até 6 m: Devastator (ab3862b0, 5c934d9a), Devastator MK3 (ab3862b0), Rocket Devastator (ab3862b0), Female Agiator (51ba8f74), Overseer (0), Fleshmob (0), Berserker (71739f3f, 5c934d9a), Marauder (e0b04680), Scout Strider (0). Demais golpes físicos continuam até 3 m.
- Pedido do usuário: ácido do Cuspidor de Bile nunca reduzido. Excluídos pelo tipo: Bile Spewer (MK1/MK2), Nursing Spewer (MK1/MK2), Rupture Spewer, Bile Spitter, Bile Warrior — além do elemento físico já exigido. Exclusões passam a valer também para as 8 causas listadas quando o atacante é resolvido.
- Log: `reduções fora da lista=N (por inimigo+golpe=M)`.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas: par a 3,47 m aceito, 6,00 aceito/6,01 recusado, não catalogado 3,01 recusado, exclusões de ácido. Em partida: Fleshmob a >3 m reduzido; Cuspidor de Bile com dano original.
