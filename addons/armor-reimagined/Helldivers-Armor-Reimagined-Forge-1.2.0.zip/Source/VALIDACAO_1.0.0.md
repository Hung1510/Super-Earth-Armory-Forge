# Validação da 1.0.0

## Validado em partida (09–10/10/2026)

- Tiros: bloqueio/65%/nativo por região e volume, solo e **como convidado** (14 alterações, 0 recusas).
- Corpo a corpo: causas listadas + pares inimigo+golpe até 6 m + outros até 3 m via ID de rede. Validados Devastator (comum/MK3/foguete), Berserker, Marauder, Female Agiator, Hulk Bruiser, Overseer, Fleshmob, Stalker, Bile Spewer (golpe), insetos (incl. causa nova reduzida pela distância); **como convidado** 11 reduções, 0 recusas.
- Exclusões: Charger (112), Bile Titan (750), Impaler (350), respingo de ácido — originais. Golpe letal preservado; vida máxima lida 125.
- Velocidade (leve +10/+5, pesada −5/−10) e ergonomia aplicadas, inclusive como convidado.
- Performance: 40,9 → 9,8 ms/s; Watchdog 41 min: 13,5 ms/s médio, 0 travamentos.

## Alterações desde 0.19.1

- Aviso na tela por 15 s quando o mod se desliga (versão do jogo diferente — códigos 21/22/46/51/52/61 — ou falha de segurança), sem exigir missão.
- Removida a coleta de impactos em outros alvos (pesquisa de ricochete abandonada).
- Modo normal do log: linhas técnicas por segundo só com diagnóstico; resumos de corpo a corpo/tiros no máximo a cada 5 s; mensagem de abertura curta.
- README de usuário bilíngue (README_1.0.md) com créditos; notas técnicas permanecem em ACTOR_BRIDGE.md.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas (aviso de versão/recusa nos três idiomas, modo normal sem linhas técnicas, diagnóstico por arquivo).

## Pendências pós-1.0

Ajuste do bloqueio total (10–20%), desgaste das placas com restauração ao reabastecer, lentidão ao levar golpe, 2.0 com cobertura por volume e por modelo.
