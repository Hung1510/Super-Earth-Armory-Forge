# Validação da 0.16.1

## Motivo

Teste real da 0.16.0 contra Autômatos (subfacção de fogo), 09/10/2026: ligação preparo→evento funcionou (35/35 ligados, zero ambíguos), posição do personagem local resolvida, mas o descritor de vida nunca resolveu o atacante (marcas `0x1e3`). O mapa de entidades devolveu tipos incoerentes para os causadores (`96DE9CD50F7306E6` = ARC-3 Arc Thrower, `E85E623F93F96FB3` = CQC-73 Entrenchment Tool), indício de que o evento traz o índice de 22 bits sem a geração e o mapa encontra outra entidade com o mesmo número.

Relato do usuário: dois socos e escudadas do Devastador da subfacção de fogo. Eventos `0xab3862b0`, 40–45 de dano, produtor `0x7d247e`, causadores 1050/1052, sem redução (causa fora da lista, compartilhada com o plasma do Overseer).

## Alteração

`ArmorEntityComplete`: quando o descritor de vida não resolve, completa o ID com a geração atual do gerenciador de entidades do executável (`exe+0x1b135b8`, tamanho `+0x80`, gerações `+0x88`; referência SkyeShade `engine.entities`) e tenta de novo; o tipo do mapa usa o mesmo ID completo. Marcas novas 1024/2048 e campo `id completo causador` no log. Mensagem de abertura agora recomenda lobby privado.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas, incluindo teste de índice sem geração completado e resolvido com distância. Em partida: conferir se as marcas passam a incluir 4 e 1024 e se aparecem nomes de Autômatos.
