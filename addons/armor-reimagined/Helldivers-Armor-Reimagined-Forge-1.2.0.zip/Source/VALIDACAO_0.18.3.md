# Validação da 0.18.3

## Pedido

"Qualquer dano corpo a corpo que seja hit kill continua sendo hit kill" — após o golpe de 350 do Impaler (`0xf1d1fd34`) e a investida do Charger (112).

## Alteração

Antes de escrever a redução corpo a corpo, lê a vida máxima do avatar local no gerenciador de vida (extensão `+0x1060`, passo 28, campo `+20`; referência SkyeShade `health.extArray/extStride/maxHealth`, mesmo build). Se dano nativo ≥ vida máxima: motivo 7, contador `golpes letais preservados`, dano intacto, sem contar como recusa. Vida máxima fora de 50–2000 ou ilegível não bloqueia a redução (falha não pode desligar o corpo a corpo). Log mostra `vida máxima lida`.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas: dano = vida máxima e dano > vida máxima preservados; vida máxima = dano+1 reduz; vida ilegível reduz. Em partida: conferir `vida máxima lida` (esperado ~125–150 conforme boosters) e golpe letal preservado.
