# Validação da 0.19.1 (performance)

## Motivo

Medidor em missão: Regional Armor ~23 ms/s, subindo em combate. Cada quadro faz ~150 leituras de memória (identidade, registros de movimento/ergonomia/fôlego, validações antes de escrever) e cada golpe acrescenta outras; todas usavam ReadProcessMemory no próprio processo (chamada ao sistema por campo). A ideia de ricochete nativo foi abandonada pelo usuário; a coleta da 0.19.0 permanece só com diagnóstico.

## Alteração

`ArmorSafeCopy` (assembly, `rep movsb` dentro de um intervalo SEH com `__C_specific_handler`, mesmo padrão de `ArmorExchangeDamage`): cópia direta que devolve 0 em falha de acesso. `read_at` (ponte) e `ArmorRuntimeReadSelf` (registros locais) passam a usá-la, mantendo os limites de endereço/tamanho. Escritas continuam por troca atômica validada; a conferência do evento antes de escrever o dano segue com ReadProcessMemory.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas. Teste próprio: cópia válida, endereço 0x1000, cópia atravessando página PAGE_NOACCESS e início em página sem acesso devolvem 0 sem encerrar o processo. Medição: ReadProcessMemory 324 ns, cópia protegida 4 ns por leitura. Em partida: comparar ms/s no medidor (antes ~23).
