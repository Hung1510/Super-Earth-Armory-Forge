local M = {}
function M.selector_layout(width,height)
    local scale=math.min(width/1920,height/1080)
    return {x=(width-1920*scale)/2+875*scale,y=960*scale,w=220*scale,h=44*scale,scale=scale}
end
function M.inside(box,x,y)
    return box and x and y and x>=box.x and x<box.x+box.w and y>=box.y and y<box.y+box.h
end
function M.u32(bytes, offset)
    offset=offset or 0
    if type(bytes)~='string' or #bytes<offset+4 then return nil end
    local a,b,c,d=bytes:byte(offset+1,offset+4)
    return a+b*256+c*65536+d*16777216
end
-- PT-BR: Blindagem por parte do corpo para a silhueta; nil = parte não coberta por este item (capacete só mostra a cabeça).
-- 0 = sem placa (leve padrão nos membros). preview = perfil reforçado.
-- EN: Armor per body part for the silhouette; nil = part not covered by this item (helmet only shows the head).
-- 0 = no plate (light standard limbs). preview = reinforced profile.
function M.body(kind,weight,preview)
    if kind==1 then return {head=3} end
    if weight==0 then local limbs=preview and 1 or 0;return {head=3,chest=2,torso=2,arms=limbs,shoulders=preview and 3 or 2,legs=limbs,shins=limbs} end
    if weight==1 then return {head=3,chest=3,torso=2,arms=preview and 3 or 2,shoulders=3,legs=2,shins=3} end
    return {head=3,chest=preview and 4 or 3,torso=3,arms=3,shoulders=3,legs=3,shins=3}
end
function M.pointer(bytes, offset)
    offset=offset or 0
    if type(bytes)~='string' or #bytes<offset+8 then return nil end
    local n=M.u32(bytes,offset)+M.u32(bytes,offset+4)*4294967296
    if n<65536 or n>=140737488355328 or n%4~=0 then return nil end
    return n
end
function M.majority(read, kit)
    local data=read(kit,64)
    if not data or M.u32(data,40)~=0 then return nil end
    local bodies,nbody=M.pointer(data,48),M.u32(data,56)
    if not bodies or not nbody or nbody<1 or nbody>8 or M.u32(data,60)~=0 then return nil end
    local body=read(bodies,nbody*24)
    if not body then return nil end
    local counts,total={0,0,0},0
    for b=0,nbody-1 do
        local pieces,n=M.pointer(body,b*24+8),M.u32(body,b*24+16)
        if not pieces or not n or n<1 or n>64 or M.u32(body,b*24+20)~=0 then return nil end
        for i=0,n-1 do
            local piece=read(pieces+i*96,20)
            if not piece then return nil end
            if M.u32(piece,12)==0 then
                local weight=M.u32(piece,16)
                if weight>2 then return nil end
                counts[weight+1]=counts[weight+1]+1; total=total+1
            end
        end
    end
    if read(kit,64)~=data or read(bodies,nbody*24)~=body then return nil end
    for weight=0,2 do if counts[weight+1]>total/2 then return weight end end
end
function M.detail_visible(read,owner)
    if not owner then return false end
    local root=owner+0x119488+0x91c0
    local flags,alpha=M.u32(read(root,4)),M.u32(read(root+84,4))
    -- PT-BR: A seleção persiste fora da lista; exige o painel visível e opacidade normal acima de 0,5.
    -- EN: Selection persists outside the list; require a visible panel and normal opacity above 0.5.
    return flags~=nil and math.floor(flags/16)%2==1 and alpha~=nil
        and alpha>0x3f000000 and alpha<=0x3f800000
end
function M.new(api,note,profiles)
    local self,cache,scan={status='aguardando arma',ergo_status='aguardando arma principal'},{},nil
    local surface=HAPSurface.new(note)
    local signature,displayed_owner,selected_key=nil,nil,nil
    profiles=profiles or {get=function() return false end,choose=function() return false end}
    self.open,self.down,self.save_error=false,nil,false
    local function viewed()
        local base,read=api.game_base(),api.readonly
        if not base then return nil end
        local menu=M.pointer(read(base+0x347ce28,8))
        if not menu or M.u32(read(menu+0x4294,4))~=5 then return nil end
        local manager=M.pointer(read(base+0x3326e68,8))
        local n=manager and M.u32(read(manager+0x166c,4))
        if not n or n<1 or n>64 then return nil end
        local rows,owner=read(manager+0x1670,n*16),nil
        for i=0,n-1 do
            if M.u32(rows,i*16+8)==224 then
                if owner then return nil end
                owner=M.pointer(rows,i*16)
            end
        end
        if not M.detail_visible(read,owner) then return nil end
        local tab=M.u32(read(owner+0x7fde8+0x92fc4,4))
        if not tab or tab>64 then return nil end
        local id=M.u32(read(owner+0x136f5c,4))
        local catalog=M.pointer(read(base+0x33264f8,8))
        local header=catalog and read(catalog,12)
        local array,count=M.pointer(header),M.u32(header,8)
        if not id or not array or not count or count<1 or count>2048 then return nil end
        local key=tostring(catalog)..':'..tostring(array)..':'..count
        if cache.key~=key then cache={key=key,entries={},seen={}};scan={index=0,array=array,count=count} end
        if scan then
            local batch=math.min(32,scan.count-scan.index)
            local entries=read(scan.array+scan.index*8,batch*8)
            if not entries then cache={}; scan=nil; return nil end
            for i=0,batch-1 do
                local at=M.pointer(entries,i*8)
                local descriptor=at and read(at,44)
                local item=M.u32(descriptor)
                if not item then cache={};scan=nil;return nil end
                if cache.seen[item] then cache.entries[item]=nil
                else cache.entries[item]={at=at,kind=M.u32(descriptor,40)} end
                cache.seen[item]=true
            end
            scan.index=scan.index+batch
            if scan.index<scan.count then return nil end
            if read(catalog,12)~=header then cache={};scan=nil;return nil end
            scan=nil
        end
        local item=cache.entries[id]
        local descriptor=item and read(item.at,44)
        if not descriptor or M.u32(descriptor)~=id then return nil end
        -- PT-BR: Os filtros de armadura também mudam a aba interna; o catálogo identifica o tipo real.
        -- EN: Armor filters also change the internal tab; the catalog identifies the actual item type.
        local kind=M.u32(descriptor,40)
        if kind~=0 and kind~=1 then return nil end
        local weight=kind==0 and M.majority(read,item.at) or nil
        if kind==0 and weight==nil then return nil end
        if M.u32(read(owner+0x136f5c,4))~=id or M.u32(read(owner+0x7fde8+0x92fc4,4))~=tab
            or not M.detail_visible(read,owner) then return nil end
        return {id=id,kind=kind,weight=weight,base=base,owner=owner}
    end
    local function get_fonts(base)
        local function target(rva,prefix)
            local code=api.readonly(base+rva,7)
            if not code or code:sub(1,3)~=prefix then return nil end
            local delta=M.u32(code,3);if delta>=2147483648 then delta=delta-4294967296 end
            return base+rva+7+delta
        end
        local function hash(at)
            local bytes=at and api.readonly(at,8)
            if not bytes or bytes==string.rep('\0',8) or bytes==string.rep('\255',8) then return nil end
            local out={};for i=8,1,-1 do out[#out+1]=string.format('%02x',bytes:byte(i)) end
            return table.concat(out)
        end
        local f=target(0x1388044,'\x48\x8b\x3d')
        local a=target(0x1388054,'\x48\x8b\x35')
        local m=target(0x1388030,'\x48\x8b\x1d')
        local material=m and M.pointer(api.readonly(m,8))
        local font,atlas,ink=hash(f),hash(a),hash(material and material+24)
        if not font or not atlas or not ink then return nil end
        return {font=font,atlas=atlas,material=ink}
    end
    function self.alert_fonts()
        local base=api.game_base()
        return base and get_fonts(base) or nil
    end
    function self.close()
        signature,displayed_owner,selected_key=nil,nil,nil
        self.open,self.down,self.save_error=false,nil,false;surface.close()
    end
    -- PT-BR: Código da tela atual do jogo (5 = Arsenal); nil quando o menu não existe.
    -- EN: Current game screen code (5 = Armory); nil when the menu does not exist.
    function self.screen()
        local base=api.game_base()
        local menu=base and M.pointer(api.readonly(base+0x347ce28,8))
        return menu and M.u32(api.readonly(menu+0x4294,4)) or nil
    end
    function self.before_ui(sr,active)
        if not surface.gui then return end
        local base=api.game_base()
        local menu=base and M.pointer(api.readonly(base+0x347ce28,8))
        -- PT-BR: Limpa antes da atualização nativa; pcall não recupera falhas nativas de recursos ausentes.
        -- EN: Clear before the native update; pcall cannot recover native missing-resource faults.
        if not active or not menu or M.u32(api.readonly(menu+0x4294,4))~=5 or not surface.valid(sr)
            or not M.detail_visible(api.readonly,displayed_owner) then self.close() end
    end
    function self.stop() self.ergo_requested=false;self.ergo_before();api.swim_step(false);api.profile_step(0,false);api.heavy_step(false);self.close() end
    function self.step(sr,now,active,protection,ergonomics,language,swimming,descriptions)
        if surface.gui and (not active or not surface.valid(sr)
            or not M.detail_visible(api.readonly,displayed_owner)) then self.close();return end
        if not active or not sr or not sr.Gui or not sr.Application then self.close();return end
        local item=viewed()
        if not item then self.close();return end
        local width,height=sr.Gui.resolution()
        if type(width)~='number' or type(height)~='number' or width<=0 or height<=0 then return end
        local world,main=nil,sr.Application.main_world()
        for _,candidate in pairs(sr.Application.worlds() or {}) do if candidate~=main then world=candidate;break end end
        if not world then self.close();return end
        local fonts=get_fonts(item.base)
        if not fonts or not surface.ready(sr,world,fonts) then self.close();return end
        language=HAPI18n.index(language)
        local text=HAPI18n.get(language)
        local selector=item.kind==0
        local function caption(reinforced)
            if item.weight==2 then return reinforced and text.selector_av4 or text.selector_av3 end
            return reinforced and text.selector_reinforced or text.selector_standard
        end
        local current_key=item.owner..':'..item.id
        if current_key~=selected_key then
            selected_key=current_key;self.open,self.down,self.save_error=false,nil,false
        end
        local heavy=selector and profiles.get(item.id)
        local box,hover,button_hover=M.selector_layout(width,height),nil,false
        if not selector then self.open=false end
        if api.cursor then
            local x,y,down=api.cursor(width,height)
            self.cx,self.cy=x,y
            if x and y and type(down)=='boolean' then
                -- PT-BR: Entrar com o mouse já pressionado não escolhe um perfil; exige novo clique na lista visível.
                -- EN: Entering with the mouse already held does not choose a profile; require a fresh click in the visible list.
                local press=self.down==false and down;self.down=down
                button_hover=M.inside(box,x,y)
                if self.open then
                    for row=1,2 do
                        if M.inside({x=box.x,y=box.y-row*36*box.scale-4*box.scale,w=box.w,h=36*box.scale},x,y) then hover=row end
                    end
                end
                if press and selector then
                    if button_hover then self.open=not self.open
                    elseif self.open then
                        if hover then
                            local saved=profiles.choose(item.id,hover==2)
                            self.save_error=not saved
                            if saved then heavy=profiles.get(item.id) end
                        end
                        self.open=false
                    end
                end
            else self.down=nil;self.open=false end
        else self.down=nil;self.open=false;self.cx,self.cy=nil,nil end
        -- PT-BR: O cartão continua aberto enquanto o mouse estiver sobre ele (do seletor até a borda direita), e a linha sob o
        -- mouse ganha uma explicação flutuante, como nos RPGs. Usa as áreas desenhadas no quadro anterior.
        -- EN: The card stays open while the mouse is over it (from the selector to its right edge), and the row under the
        -- mouse gets a floating explanation, as in RPGs. Uses the areas drawn on the previous frame.
        local card_hover=self.card_rect and M.inside(self.card_rect,self.cx,self.cy) or false
        local tip=nil
        if card_hover and self.row_rects then
            for id,rect in pairs(self.row_rects) do if M.inside(rect,self.cx,self.cy) then tip=id end end
        end
        descriptions=descriptions~=false
        if not descriptions and not selector then self.close();return end
        local key=table.concat({item.owner,item.id,item.kind,tostring(item.weight),width,height,tostring(world),
            fonts.font,fonts.atlas,fonts.material,
            tostring(protection),tostring(ergonomics),self.ergo_status,language,tostring(swimming),tostring(heavy),tostring(self.angled),tostring(self.gaps),
            tostring(descriptions),tostring(self.open),tostring(hover),tostring(button_hover),tostring(self.save_error),
            tostring(card_hover),tostring(tip)},':')
        if key==signature and not self.resync then return end
        if not surface.bind(sr,world,fonts) then return end
        local scale=math.min(width/1920,height/1080)
        local items={}
        local gold,white,gray={255,250,220,40},{255,235,235,235},{255,180,180,180}
        local green,red={255,120,230,85},{255,255,80,65}
        do
            items[#items+1]={id='selector',kind='rect',x=box.x,y=box.y,w=box.w,h=box.h,
                color=button_hover and {245,42,42,30} or {235,12,14,16},layer=996}
            items[#items+1]={id='selector_edge',kind='rect',x=box.x,y=box.y,w=box.w,h=2*scale,color=gold,layer=997}
            items[#items+1]={id='selector_caption',kind='text',text=item.kind==1 and text.helmet_title or text.selector_caption,x=box.x+10*scale,y=box.y+29*scale,size=11*scale,color=white,layer=998}
            local value=selector and caption(heavy)
                or item.kind==1 and 'AV3' or text.armor_names[item.weight]..(item.weight==0 and ' (AV2)' or ' (AV3/AV2)')
            items[#items+1]={id='selector_value',kind='text',text=value,
                x=box.x+10*scale,y=box.y+8*scale,size=17*scale,color=gold,layer=998}
            if selector then
                items[#items+1]={id='selector_arrow',kind='text',text=self.open and '^' or 'v',x=box.x+box.w-22*scale,y=box.y+12*scale,size=17*scale,color=gold,layer=998}
            end
            if self.open then
                items[#items+1]={id='profile_border',kind='rect',x=box.x,y=box.y-76*scale,w=box.w,h=74*scale,color=gold,layer=996}
                for row=1,2 do
                    local y=box.y-row*36*scale-4*scale
                    items[#items+1]={id='profile_row'..row,kind='rect',x=box.x+2*scale,y=y+2*scale,w=box.w-4*scale,h=34*scale,
                        color=row==hover and {250,55,55,30} or {245,12,14,16},layer=997}
                    items[#items+1]={id='profile_text'..row,kind='text',text=caption(row==2),
                        x=box.x+10*scale,y=y+10*scale,size=16*scale,color=(row==2)==heavy and gold or white,layer=998}
                end
            end
            if self.save_error then
                items[#items+1]={id='profile_error',kind='text',text=text.selector_error,x=box.x,y=box.y-24*scale,
                    size=14*scale,color={255,255,100,100},layer=998}
            end
        end
        if not (button_hover or self.open or card_hover) then self.card_rect,self.row_rects=nil,nil end
        if button_hover or self.open or card_hover then
            -- PT-BR: Passar o mouse só antecipa os valores; apenas o clique grava o perfil da armadura.
            -- EN: Hover only previews values; only a click saves the armor profile.
            local preview=heavy
            if selector and self.open and hover then preview=hover==2 end
            local rows={}
            local function row(id,label,value,color)
                rows[#rows+1]={id=id,label=label,value=value,color=color}
            end
            -- PT-BR: A blindagem por região aparece na silhueta; a tabela mostra só o resto.
            -- EN: Armor by region is shown on the silhouette; the table only shows the rest.
            if item.kind==1 then
                row('melee_head',text.stat_melee_head,protection and '-20%' or text.stat_off,protection and green or gray)
            else
                local ergo=(preview and {[0]='+10%',[1]='-10%',[2]='-20%'} or {[0]='+15%',[1]='0%',[2]='-20%'})[item.weight]
                row('ergo',text.stat_ergo,ergonomics and ergo or text.stat_off,
                    not ergonomics and gray or ergo:sub(1,1)=='+' and green or ergo:sub(1,1)=='-' and red or white)
                local speed=item.weight==2 and (preview and '-10%' or '-5%') or item.weight==0 and (preview and '+5%' or '+10%') or '0%'
                row('speed',text.stat_speed,item.weight==1 and '0%' or protection and speed or text.stat_off,
                    item.weight==1 and white or not protection and gray or item.weight==0 and green or red)
                -- PT-BR: Lentidão ao levar golpe que não foi bloqueado: leve -25% 1,5 s, média -15% 1 s, pesada nenhuma.
                -- EN: Slow when hit by an unblocked hit: light -25% 1.5 s, medium -15% 1 s, heavy none.
                if item.weight~=0 and self.angled then row('angled',text.stat_angled,protection and text.angled_value or text.stat_off,protection and green or gray) end
                if item.weight==2 and self.gaps~=false then row('gaps',text.stat_gaps,protection and text.gaps_value or text.stat_off,protection and red or gray) end
                local slow=({[0]=text.slow_light,[1]=text.slow_medium,[2]=text.stat_none})[item.weight]
                row('slow',text.stat_slow,protection and slow or text.stat_off,not protection and gray or item.weight==2 and green or red)
                local torso=({[0]='-15%',[1]=preview and '-20%' or '-15%',[2]=preview and '-35%' or '-25%'})[item.weight]
                local limbs=({[0]=preview and '-10%' or '0%',[1]=preview and '-20%' or '-15%',[2]=preview and '-25%' or '-20%'})[item.weight]
                if item.weight==1 then
                    row('melee_chest',text.stat_melee_chest,protection and (preview and '-25%' or '-20%') or text.stat_off,protection and green or gray)
                end
                -- PT-BR: Na média, restante do tronco e membros têm o mesmo valor; mostra só "Membros".
                -- EN: On medium, rest of torso and limbs share the same value; show only "Limbs".
                if item.weight~=1 then
                    row('melee_torso',text.stat_melee_torso,protection and torso or text.stat_off,protection and green or gray)
                end
                row('melee_limbs',text.stat_melee_limbs,protection and limbs or text.stat_off,not protection and gray or limbs=='0%' and white or green)
                if item.weight==0 then row('swim',text.stat_swim,swimming and text.stat_yes or text.stat_no,swimming and green or gray) end
            end
            local x,top,w=box.x+box.w+12*scale,box.y+box.h,680*scale
            local h=math.max(82+#rows*22,385)*scale
            items[#items+1]={id='card_background',kind='rect',x=x,y=top-h,w=w,h=h,color={250,12,14,16},layer=997}
            items[#items+1]={id='card_edge',kind='rect',x=x,y=top-2*scale,w=w,h=2*scale,color=gold,layer=998}
            local title=item.kind==1 and text.helmet_title or selector and (preview and text.card_av4 or text.card_av3)..' - '..text.armor_names[item.weight]
                or text.armor_title..text.armor_names[item.weight]
            local description=item.kind==1 and text.card_helmet or selector and text.card_heavy or text.card_standard
            items[#items+1]={id='card_title',kind='text',text=title,x=x+10*scale,y=top-25*scale,size=15*scale,color=gold,layer=999}
            items[#items+1]={id='card_description',kind='text',text=description,x=x+10*scale,y=top-48*scale,size=13*scale,color=gray,layer=999}
            self.card_rect={x=box.x+box.w,y=top-h,w=w+12*scale,h=h}
            self.row_rects={}
            for i,stat in ipairs(rows) do
                local y=top-(64+i*22)*scale
                items[#items+1]={id='stat_label_'..stat.id,kind='text',text=stat.label,x=x+255*scale,y=y,size=13*scale,color=white,layer=999}
                items[#items+1]={id='stat_value_'..stat.id,kind='text',text=stat.value,x=x+545*scale,y=y,size=13*scale,color=stat.color,layer=999}
                self.row_rects[stat.id]={x=x+250*scale,y=y-6*scale,w=w-255*scale,h=22*scale}
                if tip==stat.id then
                    items[#items+1]={id='stat_hover',kind='rect',x=x+250*scale,y=y-6*scale,w=w-255*scale,h=22*scale,color={120,250,220,40},layer=998}
                end
            end
            -- PT-BR: Explicação flutuante da linha sob o mouse (quebrada em linhas de até 46 caracteres).
            -- EN: Floating explanation for the row under the mouse (wrapped at up to 46 characters).
            local tip_text=tip and text['tip_'..tip]
            if tip_text and self.cx and self.cy then
                local lines,current={},''
                local function length(s) local _,n=s:gsub('[\128-\191]','');return #s-n end
                for word in tip_text:gmatch('%S+') do
                    if current~='' and length(current)+1+length(word)>46 then lines[#lines+1]=current;current=word
                    else current=current=='' and word or current..' '..word end
                end
                if current~='' then lines[#lines+1]=current end
                local longest=0
                for _,line in ipairs(lines) do longest=math.max(longest,length(line)) end
                local tw,th=(longest*7.2+20)*scale,(#lines*17+14)*scale
                local tx=math.min(self.cx+18*scale,width-tw-4*scale)
                local ty=math.max(self.cy-8*scale,th+4*scale)
                items[#items+1]={id='tooltip_background',kind='rect',x=tx,y=ty-th,w=tw,h=th,color={250,8,9,11},layer=1001}
                items[#items+1]={id='tooltip_edge',kind='rect',x=tx,y=ty-2*scale,w=tw,h=2*scale,color=gold,layer=1002}
                for n,line in ipairs(lines) do
                    items[#items+1]={id='tooltip_text_'..n,kind='text',text=line,x=tx+10*scale,y=ty-(n*17+4)*scale,size=13*scale,color=white,layer=1003}
                end
            end
            -- PT-BR: Silhueta do corpo: cada parte pintada pela blindagem (sem placa, AV1..AV4); o eixo Y cresce para cima.
            -- EN: Body silhouette: each part painted by its armor (no plate, AV1..AV4); the Y axis grows upwards.
            local av=M.body(item.kind,item.weight,preview)
            local tiers={[0]={255,70,74,78},{255,110,160,210},{255,90,190,90},{255,235,200,45},{255,240,130,40}}
            local dim={255,45,48,52}
            -- PT-BR: Faixas geradas de assets/silhouette.png (tools/generate_silhouette.py); cada faixa pega a cor da sua região.
            -- EN: Strips generated from assets/silhouette.png (tools/generate_silhouette.py); each strip takes its region's color.
            local hs=275*scale
            local ws=hs*HAPSilhouette.aspect
            local sx,sy=x+14*scale,top-64*scale
            local by_region={head=av.head,chest=av.chest,torso=av.torso,arms=av.arms,shoulders=av.shoulders,legs=av.legs,shins=av.shins}
            -- PT-BR: A blindagem por região aparece só pelas cores da silhueta e pela legenda (sem texto em cima do corpo nem
            -- linhas de AV na tabela); os valores ficam guardados para os testes.
            -- EN: Armor by region is shown only by the silhouette colors and the legend (no text on the body and no AV rows
            -- in the table); the values are kept for tests.
            self.body_values=by_region
            -- PT-BR: Cada forma é um trapézio (topo/base) desenhado com dois triângulos em sentido anti-horário (Y para cima).
            -- EN: Each shape is a trapezoid (top/base) drawn as two counter-clockwise triangles (Y up).
            for i,shape in ipairs(HAPSilhouette.shapes) do
                local value=by_region[shape[1]]
                local color=value and tiers[value] or dim
                local tl={sx+shape[2]*ws,sy-shape[4]*hs}
                local tr={sx+shape[3]*ws,sy-shape[4]*hs}
                local bl={sx+shape[5]*ws,sy-shape[7]*hs}
                local br={sx+shape[6]*ws,sy-shape[7]*hs}
                items[#items+1]={id='body_a_'..i,kind='triangle',a=tl,b=bl,c=br,color=color,layer=998}
                items[#items+1]={id='body_b_'..i,kind='triangle',a=tl,b=br,c=tr,color=color,layer=998}
            end
            -- PT-BR: Legenda das cores abaixo da silhueta.
            -- EN: Color legend below the silhouette.
            local legend_y=sy-hs-24*scale
            for tier=0,4 do
                local lx=sx+(tier*48)*scale
                items[#items+1]={id='legend_box_'..tier,kind='rect',x=lx,y=legend_y,w=11*scale,h=11*scale,color=tiers[tier],layer=998}
                items[#items+1]={id='legend_text_'..tier,kind='text',text=tier==0 and text.legend_none or 'AV'..tier,x=lx+15*scale,y=legend_y+1*scale,
                    size=11*scale,color=white,layer=999}
            end
        end
        -- PT-BR: Formas novas só aparecem depois da primeira atualização no jogo; redesenha uma vez no quadro seguinte.
        -- EN: New shapes only show after their first update in game; redraw once on the next frame.
        local fresh=key~=signature
        if surface.sync(items) then signature=key;displayed_owner=item.owner;self.resync=fresh end
    end
    function self.ergo_before()
        if api.ergo_restore()==0 then self.ergo_status='mudança externa preservada' end
    end
    function self.ergo_after(wanted)
        self.ergo_before()
        self.ergo_sample=nil
        if not wanted then self.ergo_status='desligada';return end
        local result=api.ergo_step(true)
        self.ergo_sample=api.ergo_stats();self.ergo_sample.weapon=tostring(self.ergo_sample.record)
        if result==1 then
            self.ergo_status=self.ergo_sample.expected==self.ergo_sample.before and 'ergonomia original confirmada'
                or 'aplicada e relida na principal local'
        else
            local reasons={
                [1]='integração desligada',[2]='avatar local não confirmado',
                [3]='aguardando missão confirmada',[4]='categoria da armadura não confirmada',
                [5]='identidade local mudou',[6]='aguardando principal na mão',
                [7]='valores nativos da mira não confirmados',[8]='restauração anterior pendente',
                [9]='troca dos valores recusada',[10]='leitura após a escrita não confirmou os valores',
                [11]='instância local não gravável'}
            self.ergo_status=reasons[self.ergo_sample.reason] or 'aplicação recusada'
        end
    end
    function self.swim_after(wanted) api.swim_step(wanted) end
    return self
end
return M
