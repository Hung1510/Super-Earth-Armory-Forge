local M={}
-- PT-BR: Indicador rápido de proteção aplicada e relatório da armadura ao fim da missão.
-- EN: Quick indicator of applied protection and an armor report at the end of the mission.
local GREEN,YELLOW,WHITE,ORANGE={255,120,230,85},{255,250,220,40},{255,235,235,235},{255,255,140,30}
-- PT-BR: Relatório expandido (regiões, quem mais feriu, matador) adiado pelo usuário em 11/10/2026; os dados continuam
-- sendo coletados e registrados no log, só não aparecem na tela. Ligar aqui numa atualização futura.
-- EN: Expanded report (regions, who hurt you most, killer) postponed by the user on 2026-10-11; the data is still
-- collected and logged, it is just not drawn. Turn it on here in a future update.
M.EXPANDED=false
-- PT-BR: Nome do inimigo pelo catálogo de tipos (descritor de vida); desconhecido quando ausente ou "N/A".
-- EN: Enemy name from the type catalog (health descriptor); unknown when missing or "N/A".
function M.name(hex,text)
    local names=rawget(_G,'HAP_SOURCE_NAMES') or HAP_SOURCE_NAMES
    local name=hex and names and names[hex]
    if not name or name=='N/A' or hex=='0000000000000000' then return text.report_unknown end
    return name
end
-- PT-BR: Parte exata pelo volume atingido (nomes do próprio jogo: chest, l_clavicle, l_shoulder, l_elbow, l_hand,
-- l_thigh, l_knee, l_foot, l_ball...); sem volume conhecido, cai para a região (cabeça, tronco, braços, pernas).
-- EN: Exact part from the struck volume (the game's own names: chest, l_clavicle, l_shoulder, l_elbow, l_hand,
-- l_thigh, l_knee, l_foot, l_ball...); without a known volume it falls back to the region (head, torso, arms, legs).
local PARTS={[0x37ef0820]='chest',[0x668f6a68]='torso',[0x58d886fb]='torso',[0x5a4bbaa2]='torso',[0x9b115563]='torso',
    [0xc4787b4e]='shoulder',[0xb2bcd839]='shoulder',[0x03752c98]='shoulder',[0x1620b2ce]='shoulder',
    [0x1ca2cd66]='forearm',[0x31e34dac]='forearm',[0x5c0c68d3]='hand',[0x248004f5]='hand',
    [0x8e1c9de6]='thigh',[0x748f4281]='thigh',[0x8fd2dfec]='shin',[0x3ac8154a]='shin',
    [0x8eb19d6a]='foot',[0x46ddad11]='foot',[0xecd5bb39]='foot',[0x68bbeb52]='foot'}
local GROUP_PARTS={'head','torso','arms','legs'}
function M.part(region,collider)
    if region==0x8c5570c9 then return 'head' end
    return collider and PARTS[collider] or GROUP_PARTS[M.group(region)]
end
function M.group(region)
    if region==0x8c5570c9 then return 1 end
    if region==0xaa1db0b0 then return 2 end
    if region==0x1880288e or region==0xb6f2baf5 then return 3 end
    if region==0x64a3fa1d or region==0x87b05ff4 then return 4 end
    return 0
end
function M.new(api,note,presentation)
    local self,surface={},HAPSurface.new(note)
    local last_sequence,flash,mission,away_since,report,reported=nil,nil,nil,nil,nil,nil
    local waiting,free_since=nil,nil
    local last_avatar,deaths,killer=nil,0,nil
    local seen_seq,seen_at,lost_at,candidate=nil,nil,nil,nil
    local function valid_avatar(a) return a and a~=0 and a~=4294967295 end
    local function region_diff(r,b)
        local out={}
        for g=1,4 do
            local now_row,base_row=r and r.regions[g],b and b.regions[g]
            local row={}
            for _,field in ipairs({'hits','blocked','reduced','full','taken','prevented'}) do
                row[field]=((now_row and now_row[field] or 0)-(base_row and base_row[field] or 0))%4294967296
            end
            out[g]=row
        end
        return out
    end
    local function attacker_diff(r,b)
        local base={}
        for _,a in ipairs(b and b.attackers or {}) do base[a.type]=a end
        local out={}
        for _,a in ipairs(r and r.attackers or {}) do
            local o=base[a.type] or {hits=0,taken=0,prevented=0}
            local row={type=a.type,hits=(a.hits-o.hits)%4294967296,taken=(a.taken-o.taken)%4294967296,prevented=(a.prevented-o.prevented)%4294967296}
            if row.hits>0 then out[#out+1]=row end
        end
        table.sort(out,function(x,y) if x.taken~=y.taken then return x.taken>y.taken end return x.type<y.type end)
        while #out>3 do out[#out]=nil end
        return out
    end
    function self.close() flash=nil;report=nil;surface.close() end
    function self.waiting() return waiting end
    function self.before_ui(sr)
        if surface.gui and not surface.valid(sr) then surface.close() end
    end
    local function since(t,b,field) return ((t[field] or 0)-(b[field] or 0))%4294967296 end
    -- PT-BR: Só lógica; separado do desenho para testar sem o motor.
    -- EN: Logic only; kept apart from drawing so it can be tested without the engine.
    -- PT-BR: screen = código da tela do jogo. Depois da missão o jogo abre as estatísticas (código 13 no teste de 11/10/2026):
    -- o relatório espera alguma tela diferente de 0 abrir e fechar, e então 2 s de tela livre. Sem isso, sai após 90 s.
    -- EN: screen = game screen code. After the mission the game opens the statistics (code 13 in the 2026-10-11 test):
    -- the report waits for some non-zero screen to open and close, then 2 s of free screen. Otherwise it shows after 90 s.
    -- PT-BR: armor = relatório nativo por região/atacante; avatar = personagem local (troca durante a missão = morte).
    -- EN: armor = native per-region/attacker report; avatar = local character (a change during the mission = death).
    function self.update(now,t,screen,armor,avatar)
        if not t then return end
        if waiting then
            -- PT-BR: Enquanto uma tela estiver aberta (estatísticas etc.) a espera não tem limite; os 90 s de reserva só valem
            -- quando nenhuma tela apareceu (antes, ficar mais de 90 s nas estatísticas mostrava o relatório por trás delas).
            -- EN: While a screen is open (statistics etc.) the wait has no limit; the 90 s fallback only applies when no screen
            -- showed up (before, staying over 90 s on the statistics showed the report behind them).
            if t.mission==1 and t.session~=0 then waiting=nil;free_since=nil
            elseif screen~=nil and screen~=0 then waiting.seen_screen=true;free_since=nil
            elseif screen==0 and waiting.seen_screen then
                free_since=free_since or now
                if now-free_since>=2000 then
                    report=waiting;report.until_at=now+15000;waiting=nil;free_since=nil
                end
            elseif now-waiting.ended_at>=90000 then
                report=waiting;report.until_at=now+15000;waiting=nil;free_since=nil
            else free_since=nil end
        end
        if t.mission==1 and t.session~=0 then
            away_since=nil
            if not mission or mission.session~=t.session then
                -- PT-BR: Voltar à mesma missão (oscilação do estado) mantém a base original e cancela o relatório.
                -- EN: Returning to the same mission (state flicker) keeps the original baseline and cancels the report.
                if reported and reported.session==t.session then mission=reported;report=nil;waiting=nil
                else mission={session=t.session,base=t,armor=armor};deaths,killer,last_avatar,lost_at,candidate=0,nil,nil,nil,nil end
                reported=nil
            end
            -- PT-BR: Morte = o personagem some e volta outro. O matador só conta se o último golpe veio até 3 s antes de sumir,
            -- para fogo, queda ou explosão (não registrados) não apontarem um tiro antigo.
            -- EN: Death = the character disappears and another returns. The killer only counts if the last hit came up to 3 s
            -- before it disappeared, so fire, falls or explosions (not recorded) do not point at an old shot.
            local last=armor and armor.last
            if last and last.sequence~=seen_seq then seen_seq,seen_at=last.sequence,now end
            if valid_avatar(avatar) then
                if valid_avatar(last_avatar) and avatar~=last_avatar then
                    deaths=deaths+1;killer=candidate
                end
                last_avatar,lost_at,candidate=avatar,nil,nil
            elseif valid_avatar(last_avatar) and not lost_at then
                lost_at=now
                candidate=last and last.avatar==last_avatar and last.sequence>0 and seen_at and now-seen_at<=3000 and last or nil
            end
            if last_sequence and t.sequence~=last_sequence and t.last_kind>=1 and t.last_kind<=4 then
                flash={kind=t.last_kind,prevented=t.last_prevented,after=t.last_after,region=t.last_region,collider=t.last_collider,until_at=now+900}
            end
        elseif mission then
            away_since=away_since or now
            if now-away_since>=3000 then
                local b=mission.base
                local r={blocked=since(t,b,'shots_blocked'),reduced=since(t,b,'shots_reduced'),melee=since(t,b,'melee_reduced'),
                    prevented=since(t,b,'shot_prevented')+since(t,b,'melee_prevented'),gaps=since(t,b,'gaps'),
                    regions=region_diff(armor,mission.armor),attackers=attacker_diff(armor,mission.armor),deaths=deaths,killer=killer}
                reported,mission,away_since,flash=mission,nil,nil,nil
                if r.blocked+r.reduced+r.melee>0 then
                    r.ended_at=now;waiting=r;free_since=nil
                    note(string.format('Relatório da missão: tiros bloqueados=%u; tiros reduzidos=%u; golpes reduzidos=%u; dano evitado=%u; '
                        ..'tiros que passaram pelas frestas=%u.',r.blocked,r.reduced,r.melee,r.prevented,r.gaps))
                    for g,row in ipairs(r.regions) do
                        note(string.format('Relatório região %u: golpes=%u; bloqueados=%u; reduzidos=%u; inteiros=%u; recebido=%u; evitado=%u.',
                            g,row.hits,row.blocked,row.reduced,row.full,row.taken,row.prevented))
                    end
                    for _,a in ipairs(r.attackers) do
                        note(string.format('Relatório atacante %s: golpes=%u; recebido=%u; evitado=%u.',a.type,a.hits,a.taken,a.prevented))
                    end
                    if r.killer then
                        note(string.format('Relatório morte: mortes=%u; último atacante=%s; região=0x%08x; dano antes=%u; dano depois=%u.',
                            deaths,r.killer.type,r.killer.region,r.killer.before,r.killer.after))
                    end
                end
            end
        end
        last_sequence=t.sequence
    end
    function self.state() return flash,report,mission end
    function self.draw(sr,now,language)
        if report and now>=report.until_at then report=nil end
        if flash and now>=flash.until_at then flash=nil end
        if not report and not flash then surface.close();return end
        if not sr or not sr.Gui or not sr.Application then surface.close();return end
        local fonts=presentation.alert_fonts()
        local world=sr.Application.main_world()
        if not fonts or not world or not surface.bind(sr,world,fonts) then surface.close();return end
        local width,height=sr.Gui.resolution()
        if type(width)~='number' or type(height)~='number' or width<=0 or height<=0 then surface.close();return end
        local scale=math.min(width/1920,height/1080)
        local text=HAPI18n.get(language)
        local items={}
        if flash then
            -- PT-BR: Tipo 4 = fresta no braço da pesada: mostra o dano que passou (20%) em laranja.
            -- EN: Kind 4 = gap in a heavy arm: shows the damage that got through (20%) in orange.
            local label=flash.kind==1 and text.flash_blocked or flash.kind==4 and string.format(text.flash_gap,flash.after or 0)
                or string.format(text.flash_reduced,flash.prevented)
            -- PT-BR: Mostra onde o golpe pegou (cabeça, tronco, braços, pernas) quando a região é conhecida.
            -- EN: Shows where the hit landed (head, torso, arms, legs) when the region is known.
            local where=flash.region and text.flash_parts[M.part(flash.region,flash.collider)]
            if where then label=label..' | '..where end
            local size=20*scale
            items[#items+1]={id='flash',kind='text',text=label,x=width/2-#label*size*0.3,y=height*0.42,size=size,
                color=flash.kind==1 and GREEN or flash.kind==4 and ORANGE or YELLOW,layer=1090}
        end
        if report then
            -- PT-BR: Linhas de cima para baixo; o eixo Y da GUI cresce para cima.
            -- EN: Lines from top to bottom; the GUI Y axis grows upwards.
            local lines={{'report_title',text.report_title,YELLOW,18},
                {'report_shots',string.format(text.report_shots,report.blocked,report.reduced),WHITE,15},
                {'report_melee',string.format(text.report_melee,report.melee),WHITE,15},
                {'report_saved',string.format(text.report_saved,report.prevented),GREEN,15}}
            for g,row in ipairs(M.EXPANDED and report.regions or {}) do
                if row.hits>0 then
                    lines[#lines+1]={'report_region_'..g,string.format(text.report_region,text.report_regions[g],row.hits,row.blocked,row.reduced,row.full),WHITE,14}
                end
            end
            if M.EXPANDED and report.attackers and #report.attackers>0 then
                lines[#lines+1]={'report_top',text.report_top,YELLOW,15}
                for i,a in ipairs(report.attackers) do
                    lines[#lines+1]={'report_attacker_'..i,string.format(text.report_attacker,M.name(a.type,text),a.taken,a.prevented),WHITE,14}
                end
            end
            if M.EXPANDED and report.deaths and report.deaths>0 then
                lines[#lines+1]={'report_deaths',string.format(text.report_deaths,report.deaths),WHITE,14}
                local k=report.killer
                if k then
                    lines[#lines+1]={'report_killer',string.format(text.report_killer,M.name(k.type,text),k.after,
                        text.report_regions[M.group(k.region)] or '?',k.before-k.after),WHITE,14}
                end
            end
            local step,w=23*scale,700*scale
            local h=(#lines*23+16)*scale
            local x,top=(width-w)/2,height-190*scale
            items[#items+1]={id='report_bg',kind='rect',x=x,y=top-h,w=w,h=h,color={225,12,14,16},layer=1080}
            for i,line in ipairs(lines) do
                items[#items+1]={id=line[1],kind='text',text=line[2],x=x+14*scale,y=top-(i*step)+2*scale,size=line[4]*scale,color=line[3],layer=1081}
            end
        end
        surface.sync(items)
    end
    return self
end
return M
