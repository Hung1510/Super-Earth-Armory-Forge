local M = {}
function M.new(binary, mode)
    mode = mode or 'legacy'
    assert(mode == 'legacy' or mode == 'actor', 'Adaptador desconhecido')
    local ffi = require('ffi')
    assert(ffi.os == 'Windows' and ffi.abi('64bit'), 'Windows x64 necessário')
    for _, declaration in ipairs({
        'void *GetModuleHandleA(const char *);', 'void *GetProcAddress(void *, const char *);',
        'typedef struct LobaoArmorMvpStats { uint32_t evaluated,blocked,partial,passed,unresolved; '
            ..'float last_ap,last_factor,last_damage; uint32_t installed,enabled; } LobaoArmorMvpStats;',
        'typedef struct LobaoArmorMvpDiagnostic { uint32_t stage,status,win32_error,protect_failed; '
            ..'uint32_t region_protect,region_state,region_kind,allocation_protect; '
            ..'uint32_t query_error,dynamic_policy_flags,dynamic_policy_error,patch_size; } LobaoArmorMvpDiagnostic;',
        'typedef struct LobaoArmorBridgeStats { uint32_t installed,enabled,status,slot_protection; '
            ..'uint32_t init_seen,apply_seen,captured,dropped,read_failed; '
            ..'uint32_t stage,victim,zone,source_kind,damage,protection_active; } LobaoArmorBridgeStats;',
        'typedef struct LobaoArmorBridgeDetail { uint32_t late_installed,local_avatar,local_init_seen,local_apply_seen; '
            ..'uint32_t late_seen,local_late_seen,local_captured,local_read_failed,region,source_kind,parent_return_rva,sample_avatar; '
            ..'float penetration[4],raw_damage,multiplier; } LobaoArmorBridgeDetail;',
        'typedef struct LobaoArmorBridgeSampling { uint32_t projectile_seen,other_seen,projectile_captured,other_captured; '
            ..'uint32_t quota_avatar,projectile_remaining,other_remaining; } LobaoArmorBridgeSampling;',
        'typedef struct LobaoArmorBridgePrediction { uint32_t rebuilt,rejected,matched,unmatched,ambiguous,victim,region,damage; '
            ..'float penetration[4],selected; } LobaoArmorBridgePrediction;',
        'typedef struct LobaoArmorBridgeDecision { uint32_t evaluated,unavailable,blocked,reduced,original; '
            ..'uint32_t victim,region,armor_id,weight,damage,projected,rule; float penetration,factor; '
            ..'uint32_t collider,identified,fallback,heavy_av4; } LobaoArmorBridgeDecision;',
        'typedef struct LobaoArmorMovementStats { uintptr_t record; uint32_t reason,avatar,applied,restored,refused,active; '
            ..'float before,expected,observed; uint32_t reserved; } LobaoArmorMovementStats;',
        'typedef struct LobaoArmorUnknownAttack {uint32_t sequence,victim,cause,damage,kind,element;} LobaoArmorUnknownAttack;',
        'typedef struct LobaoArmorEquippedStats { uint32_t avatar,armor_id,weight,valid; } LobaoArmorEquippedStats;',
        'typedef struct {uint32_t id,on;float value,clock,ends;} LobaoArmorStatusEntry;',
        'typedef struct {uint32_t valid,owner,count,reserved;LobaoArmorStatusEntry entry[16];} LobaoArmorStatusDump;',
        'typedef struct {uint32_t stat,op;float value;uint32_t reserved;} LobaoArmorPassiveModifier;',
        'typedef struct {uint32_t sequence,kind,region,damage; uint8_t base[96],extra[96],projectile[128];} LobaoArmorSettingsDump;',
        'typedef struct {uint32_t sequence,kind,element,cause,region,collider,weight,reinforced,before,after,reason,flags; '
            ..'float ap,distance; uint64_t attacker;} LobaoArmorHitLog;',
        'typedef struct {uint32_t id,name,count,reserved;LobaoArmorPassiveModifier modifier[8];} LobaoArmorPassiveTable;',
        'typedef struct {uint32_t valid,owner,key,tables;LobaoArmorPassiveTable table[2];} LobaoArmorPassiveDump;',
        'typedef struct LobaoArmorFireStats {uint32_t sequence,ticks,direct,ground,burning,duration_ms,armor_id,weight;float damage,first_damage; '
            ..'uint32_t ignition,avatar,health_start[7],health_end[7];} LobaoArmorFireStats;',
        'typedef struct { int32_t x,y; } LobaoArmorPoint;',
        'typedef struct { int32_t left,top,right,bottom; } LobaoArmorRect;',
        'typedef struct LobaoArmorRegionStats { uint32_t hits,blocked,reduced,full,taken,prevented; } LobaoArmorRegionStats;',
        'typedef struct LobaoArmorAttackerStats { uint64_t type; uint32_t hits,taken,prevented,reserved; } LobaoArmorAttackerStats;',
        'typedef struct LobaoArmorReport { LobaoArmorRegionStats regions[4]; LobaoArmorAttackerStats attackers[16]; '
            ..'uint32_t attacker_count,overflow; uint64_t last_type; '
            ..'uint32_t last_sequence,last_avatar,last_region,last_before,last_after,last_kind; } LobaoArmorReport;',
        'typedef struct LobaoArmorTotals { uint32_t sequence,shots_blocked,shots_reduced,shot_prevented,melee_reduced,melee_prevented; '
            ..'uint32_t last_kind,last_prevented,mission,last_region; uint64_t session; uint32_t last_collider,last_after; } LobaoArmorTotals;',
        'typedef struct LobaoArmorBridgeEffect { uint32_t enabled,applied,blocked,reduced,refused; '
            ..'uint32_t victim,region,before,after,reason; } LobaoArmorBridgeEffect;',
        'typedef struct LobaoArmorMeleeStatsV4 { uint32_t prepared,rejected,matched,ambiguous,unknown,applied,refused; '
            ..'uint32_t victim,cause,region,armor_id,weight,before,after,reason,keep_percent,collider,reinforced; uint32_t proximity; float distance; uint32_t by_attacker,lethal,max_health,reserved; } LobaoArmorMeleeStatsV4;',
        'typedef struct LobaoArmorErgoStats { uintptr_t record; '
            ..'uint32_t weight,reason,writes,verified,neutral,restores,restore_refused,refused; '
            ..'float before,expected,observed; uint32_t pending,protection_windows,protection_failed,locked; } LobaoArmorErgoStats;',
        'typedef struct LobaoArmorSwimStats { uintptr_t field; uint32_t reason,weight,applied,restored,refused,active; '
            ..'float before,expected,observed; uint32_t locked; } LobaoArmorSwimStats;',
        'typedef struct LobaoArmorHandlingRow { uint32_t entity,unit; float base,current,response_a,response_b; } LobaoArmorHandlingRow;',
        'typedef struct LobaoArmorHandlingStats { uintptr_t source; uint64_t resource; float source_value; '
            ..'uint32_t count,reason; LobaoArmorHandlingRow rows[8]; } LobaoArmorHandlingStats;',
        'typedef struct LobaoArmorOriginV3 { uint32_t sequence,kind,victim,parent,producer,cause,flags,region; '
            ..'uint32_t dealer,owner,dealer_unit,victim_unit; uint64_t dealer_type,owner_type,dealer_health_type,owner_health_type; '
            ..'float dealer_position[3],victim_position[3],distance; uint32_t reserved; '
            ..'uint32_t net_entity,net_unit; uint64_t net_type; float net_position[3],net_distance,reach,hit_to_victim,hit_to_dealer,unused; } LobaoArmorOriginV3;',
        'typedef struct LobaoArmorCombatSampleV3 { uint32_t stage,kind,victim,parent; '
            ..'unsigned char data[280],extra[20]; uint32_t extra_valid,producer,dealer,owner; uint64_t dealer_type,owner_type; '
            ..'LobaoArmorOriginV3 origin; } LobaoArmorCombatSampleV3;',
        'typedef struct LobaoArmorCauseStatsV3 { uint64_t dealer_type,damage_sum; double distance_sum; '
            ..'uint32_t kind,element,cause,producer,count,linked,known,reduced; '
            ..'uint32_t damage_min,damage_max,distance_count,regions; float distance_min,distance_max; '
            ..'double reach_sum; uint64_t net_type; float reach_min,reach_max; uint32_t reach_count,net_count; } LobaoArmorCauseStatsV3;',
        'typedef struct LobaoArmorOriginStats { uint32_t built,linked,ambiguous,unlinked,link_busy,recorded,overflow,version; } LobaoArmorOriginStats;'}) do
        pcall(ffi.cdef,declaration)
    end
    local kernel = ffi.load('kernel32')
    local function proc(name, signature)
        local address = kernel.GetProcAddress(kernel.GetModuleHandleA('kernel32.dll'),name)
        assert(address ~= nil, 'API indisponível: '..name)
        return ffi.cast(signature,address)
    end
    local environment = proc('GetEnvironmentVariableW','uint32_t (*)(const uint16_t *, uint16_t *, uint32_t)')
    local directory = proc('CreateDirectoryW','int (*)(const uint16_t *, void *)')
    local open = proc('CreateFileW','void *(*)(const uint16_t *, uint32_t, uint32_t, void *, uint32_t, uint32_t, void *)')
    local read = proc('ReadFile','int (*)(void *, void *, uint32_t, uint32_t *, void *)')
    local write = proc('WriteFile','int (*)(void *, const void *, uint32_t, uint32_t *, void *)')
    local close = proc('CloseHandle','int (*)(void *)')
    local load = proc('LoadLibraryExW','void *(*)(const uint16_t *, void *, uint32_t)')
    local clock = proc('GetTickCount64','uint64_t (*)(void)')
    local file_size = proc('GetFileSizeEx','int (*)(void *, int64_t *)')
    local invalid = ffi.cast('void *',-1)
    local function wide_ascii(s)
        local out = ffi.new('uint16_t[?]',#s+1)
        for i=1,#s do out[i-1] = s:byte(i) end
        return out
    end
    local path, length = ffi.new('uint16_t[32768]'), nil
    length = tonumber(environment(wide_ascii('LOCALAPPDATA'),path,32768))
    assert(length > 0 and length < 32000, 'LOCALAPPDATA indisponível')
    local function local_file(suffix)
        local value=ffi.new('uint16_t[?]',length+#suffix+1)
        ffi.copy(value,path,length*2)
        for i=1,#suffix do value[length+i-1]=suffix:byte(i) end
        return value
    end
    local profiles_path=local_file('\\CowboyBingus\\Helldivers2\\RegionalArmorProfiles.txt')
    local profiles_temp=local_file('\\CowboyBingus\\Helldivers2\\RegionalArmorProfiles.txt.tmp')
    local diagnostics_path=local_file('\\CowboyBingus\\Helldivers2\\RegionalArmorDiagnostics.txt')
    -- PT-BR: Arquivos de teste do tranco (pesquisa da 1.2): A troca 0x73734d67 para 1; B troca 0xafae3b47 para 0.
    -- EN: Flinch test files (1.2 research): A sets 0x73734d67 to 1; B sets 0xafae3b47 to 0.
    local flinch_paths={A=local_file('\\CowboyBingus\\Helldivers2\\RegionalArmorFlinchA.txt'),
        B=local_file('\\CowboyBingus\\Helldivers2\\RegionalArmorFlinchB.txt')}
    local function append(s)
        assert(length+#s < 32767, 'Caminho excessivamente longo')
        for i=1,#s do path[length+i-1] = s:byte(i) end
        length = length+#s
        path[length] = 0
    end
    for _, folder in ipairs({'CowboyBingus','Helldivers2','Native',mode == 'actor' and 'ArmorBridge' or 'ArmorMvp',HAP_BINARY_ID}) do
        append('\\'..folder)
        directory(path,nil)
    end
    append(mode == 'actor' and '\\LobaoArmorBridge.dll' or '\\LobaoArmorMvp.dll')
    local handle = open(path,0x80000000,1,nil,3,0x80,nil)
    if handle == invalid then
        handle = open(path,0x40000000,0,nil,1,0x80,nil)
        assert(handle ~= invalid, 'Não foi possível extrair a biblioteca nativa')
        local count = ffi.new('uint32_t[1]')
        local ok = write(handle,binary,#binary,count,nil) ~= 0 and tonumber(count[0]) == #binary
        close(handle)
        assert(ok, 'Extração da biblioteca nativa incompleta')
        handle = open(path,0x80000000,1,nil,3,0x80,nil)
    end
    assert(handle ~= invalid, 'Biblioteca nativa indisponível')
    local size, count = ffi.new('int64_t[1]'), ffi.new('uint32_t[1]')
    local buffer = ffi.new('uint8_t[?]',#binary)
    local ok = file_size(handle,size) ~= 0 and tonumber(size[0]) == #binary
        and read(handle,buffer,#binary,count,nil) ~= 0 and tonumber(count[0]) == #binary
        and ffi.string(buffer,#binary) == binary
    close(handle)
    assert(ok, 'Biblioteca nativa não corresponde ao pacote; carregamento recusado')
    -- PT-BR: A referência à DLL permanece válida enquanto o avaliador estiver interceptado.
    -- EN: The DLL reference remains valid while the evaluator is intercepted.
    local module = load(path,nil,0x00000100+0x00000800)
    assert(module ~= nil, 'O Windows recusou o carregamento da biblioteca nativa')
    local function export(name, signature)
        local address = kernel.GetProcAddress(module,name)
        assert(address ~= nil, 'Exportação nativa ausente: '..name)
        return ffi.cast(signature,address)
    end
    local prefix = mode == 'actor' and 'ArmorBridge' or 'Armor'
    local install = export(prefix..'Install','int (*)(void)')
    local enable = export(prefix..'Enable','void (*)(int)')
    local struct = mode == 'actor' and 'LobaoArmorBridgeStats' or 'LobaoArmorMvpStats'
    local stats = export(prefix..'ReadStats','void (*)('..struct..' *)')
    local diagnostic = mode == 'legacy' and export('ArmorReadDiagnostic','void (*)(LobaoArmorMvpDiagnostic *)') or nil
    local state = ffi.new(struct..'[1]')
    local detail = mode == 'legacy' and ffi.new('LobaoArmorMvpDiagnostic[1]') or nil
    local self = {module=module,kernel=kernel,ffi=ffi}
    function self.now() return tonumber(clock()) end
    function self.install() return tonumber(install()) end
    function self.enable(value) enable(value and 1 or 0) end
    function self.diagnostic()
        assert(diagnostic, 'Diagnóstico disponível somente no adaptador anterior')
        diagnostic(detail)
        local out = {}
        for _, field in ipairs({'stage','status','win32_error','protect_failed','region_protect',
            'region_state','region_kind','allocation_protect','query_error','dynamic_policy_flags',
            'dynamic_policy_error','patch_size'}) do out[field] = tonumber(detail[0][field]) end
        return out
    end
    function self.stats()
        stats(state)
        local out = {}
        local fields = mode == 'actor' and {'installed','enabled','status','slot_protection','init_seen',
            'apply_seen','captured','dropped','read_failed','stage','victim','zone','source_kind','damage','protection_active'}
            or {'evaluated','blocked','partial','passed','unresolved','last_ap','last_factor','last_damage','installed','enabled'}
        for _, field in ipairs(fields) do
            out[field] = tonumber(state[0][field])
        end
        return out
    end
    if mode == 'actor' then
        local move_file=proc('MoveFileExW','int (*)(const uint16_t *,const uint16_t *,uint32_t)')
        local flush_file=proc('FlushFileBuffers','int (*)(void *)')
        local delete_file=proc('DeleteFileW','int (*)(const uint16_t *)')
        local set_diagnostics=export('ArmorBridgeDiagnostics','void (*)(int)')
        function self.diagnostics(value) set_diagnostics(value and 1 or 0) end
        local set_angled=export('ArmorBridgeAngledPlates','void (*)(int)')
        function self.angled_plates(value) set_angled(value and 1 or 0) end
        local read_fire=export('ArmorBridgeReadFire','void (*)(LobaoArmorFireStats *)')
        local fire_stats=ffi.new('LobaoArmorFireStats[1]')
        -- PT-BR: Registro de vida em hexadecimal e como float, para achar o campo da vida atual.
        -- EN: Health record as hexadecimal and as float, to find the current-health field.
        local function words(array)
            local out,value={},ffi.new('float[1]')
            for i=0,6 do
                ffi.copy(value,array+i,4)
                out[#out+1]=string.format('%d:%u/%.4g',i*4,tonumber(array[i]),tonumber(value[0]))
            end
            return table.concat(out,' ')
        end
        function self.fire()
            read_fire(fire_stats)
            local f=fire_stats[0]
            return {sequence=tonumber(f.sequence),ticks=tonumber(f.ticks),direct=tonumber(f.direct),ground=tonumber(f.ground),
                burning=tonumber(f.burning),duration_ms=tonumber(f.duration_ms),armor_id=tonumber(f.armor_id),
                weight=tonumber(f.weight),damage=tonumber(f.damage),first_damage=tonumber(f.first_damage),
                ignition=tonumber(f.ignition),health_start=words(f.health_start),health_end=words(f.health_end)}
        end
        -- PT-BR: Pesquisa de derrubada/tranco: status ativos (id, ligado, valor, relógio, fim) e modificadores do passivo.
        -- EN: Knockdown/flinch research: active statuses (id, on, value, clock, end) and the passive's modifiers.
        local read_status=export('ArmorBridgeReadStatus','void (*)(LobaoArmorStatusDump *)')
        local status_dump=ffi.new('LobaoArmorStatusDump[1]')
        function self.statuses()
            read_status(status_dump)
            local d=status_dump[0]
            if d.valid==0 then return nil end
            local out={}
            for i=0,tonumber(d.count)-1 do
                local e=d.entry[i]
                out[#out+1]={id=tonumber(e.id),on=e.on~=0,value=tonumber(e.value),clock=tonumber(e.clock),ends=tonumber(e.ends)}
            end
            return out
        end
        local read_research=export('ArmorBridgeResearchState','void (*)(uint32_t *)')
        local research_words=ffi.new('uint32_t[9]')
        function self.research_state()
            read_research(research_words)
            return string.format('estado=%d; etapa com falha=%u; entidade local=%u; dono=%u; chave=%u; helldiver da tabela de jogadores=%u; '
                ..'contadores crus=%u/%u; helldiver cru=%u',
                tonumber(ffi.cast('int32_t',research_words[0])),tonumber(research_words[1]),tonumber(research_words[2]),
                tonumber(research_words[3]),tonumber(research_words[4]),tonumber(research_words[5]),
                tonumber(research_words[6]),tonumber(research_words[7]),tonumber(research_words[8]))
        end
        local read_passives=export('ArmorBridgeReadPassives','void (*)(LobaoArmorPassiveDump *)')
        local passive_dump=ffi.new('LobaoArmorPassiveDump[1]')
        function self.passives()
            read_passives(passive_dump)
            local d=passive_dump[0]
            if d.valid==0 then return nil end
            local parts={}
            for t=0,tonumber(d.tables)-1 do
                local p=d.table[t]
                local mods={}
                for m=0,math.min(tonumber(p.count),8)-1 do
                    local x=p.modifier[m]
                    mods[#mods+1]=string.format('0x%08x op%u=%.4g',tonumber(x.stat),tonumber(x.op),tonumber(x.value))
                end
                parts[#parts+1]=string.format('passivo 0x%08x/0x%08x [%s]',tonumber(p.id),tonumber(p.name),table.concat(mods,', '))
            end
            return table.concat(parts,'; ')
        end
        -- PT-BR: Cada impacto local (só com diagnóstico), um por chamada; nil quando a fila está vazia.
        -- EN: Every local hit (diagnostics only), one per call; nil when the queue is empty.
        local pop_hit=export('ArmorBridgePopHit','int (*)(LobaoArmorHitLog *)')
        local hit_row=ffi.new('LobaoArmorHitLog[1]')
        assert(ffi.sizeof('LobaoArmorHitLog')==64,'Layout do registro de impacto incompatível')
        function self.pop_hit()
            if pop_hit(hit_row)~=1 then return nil end
            local h=hit_row[0]
            local out={}
            for _,field in ipairs({'sequence','kind','element','cause','region','collider','weight','reinforced','before','after','reason','flags','ap','distance'}) do
                out[field]=tonumber(h[field])
            end
            out.attacker=string.format('%08X%08X',tonumber(h.attacker/4294967296ULL),tonumber(h.attacker%4294967296ULL))
            return out
        end
        local pop_settings=export('ArmorBridgePopSettings','int (*)(LobaoArmorSettingsDump *)')
        local settings_row=ffi.new('LobaoArmorSettingsDump[1]')
        local function hex(bytes,n)
            local out={}
            for i=0,n-1 do out[#out+1]=string.format('%02x',bytes[i]) end
            return table.concat(out)
        end
        function self.pop_settings()
            if pop_settings(settings_row)~=1 then return nil end
            local d=settings_row[0]
            return {sequence=tonumber(d.sequence),kind=tonumber(d.kind),region=tonumber(d.region),
                base=hex(d.base,96),extra=hex(d.extra,96),projectile=hex(d.projectile,128)}
        end
        local key_down=export('ArmorBridgeKeyDown','int (*)(int)')
        function self.key_down(vk) return key_down(vk)==1 end
        local passive_override=export('ArmorBridgePassiveOverride','int (*)(uint32_t,float,int)')
        function self.passive_override(stat,value,enable) return tonumber(passive_override(stat,value,enable and 1 or 0)) end
        local refused_protection=export('ArmorBridgeRefusedProtection','uint32_t (*)(void)')
        local refused_state=export('ArmorBridgeRefusedState','uint32_t (*)(void)')
        function self.refused_page() return tonumber(refused_protection()),tonumber(refused_state()) end
        local read_gaps=export('ArmorBridgeReadGaps','uint32_t (*)(void)')
        function self.gaps() return tonumber(read_gaps()) end
        local fire_native=export('ArmorBridgeFireNative','uint32_t (*)(void)')
        function self.fire_native() return tonumber(fire_native()) end
        local set_gaps=export('ArmorBridgeArmGaps','void (*)(int)')
        function self.arm_gaps(value) set_gaps(value and 1 or 0) end
        function self.flinch_test()
            for mode,file_path in pairs(flinch_paths) do
                local file=open(file_path,0x80000000,7,nil,3,0x80,nil)
                if file~=invalid then close(file);return mode end
            end
            return nil
        end
        function self.diagnostics_requested()
            local file=open(diagnostics_path,0x80000000,7,nil,3,0x80,nil)
            if file==invalid then return false end
            close(file);return true
        end
        function self.load_profiles()
            local file=open(profiles_path,0x80000000,1,nil,3,0x80,nil)
            if file==invalid then return nil end
            local size,count=ffi.new('int64_t[1]'),ffi.new('uint32_t[1]')
            if file_size(file,size)==0 or size[0]<0 or size[0]>65536 then close(file);return nil end
            local length=tonumber(size[0]);local data=ffi.new('uint8_t[?]',math.max(1,length))
            local loaded=read(file,data,length,count,nil)~=0 and tonumber(count[0])==length
            close(file);return loaded and ffi.string(data,length) or nil
        end
        function self.save_profiles(data)
            if type(data)~='string' or #data>65536 then return false end
            local file=open(profiles_temp,0x40000000,0,nil,2,0x80,nil)
            if file==invalid then return false end
            local count=ffi.new('uint32_t[1]')
            local saved=write(file,data,#data,count,nil)~=0 and tonumber(count[0])==#data and flush_file(file)~=0
            local closed=close(file)~=0
            -- PT-BR: Substitui só depois de concluir o arquivo temporário; falhas preservam a preferência anterior.
            -- EN: Replace only after completing the temporary file; failures preserve the previous preference.
            if saved and closed and move_file(profiles_temp,profiles_path,9)~=0 then return true end
            delete_file(profiles_temp);return false
        end
        local user=ffi.load('user32')
        self.user=user
        local function user_proc(name,signature)
            local address=kernel.GetProcAddress(kernel.GetModuleHandleA('user32.dll'),name)
            assert(address~=nil,'API de cursor indisponível: '..name)
            return ffi.cast(signature,address)
        end
        local beep=user_proc('MessageBeep','int (*)(uint32_t)')
        function self.alert_sound() return beep(0x40)~=0 end
        local foreground=user_proc('GetForegroundWindow','void *(*)(void)')
        local owner=user_proc('GetWindowThreadProcessId','uint32_t (*)(void *,uint32_t *)')
        local cursor=user_proc('GetCursorPos','int (*)(LobaoArmorPoint *)')
        local client=user_proc('ScreenToClient','int (*)(void *,LobaoArmorPoint *)')
        local client_rect=user_proc('GetClientRect','int (*)(void *,LobaoArmorRect *)')
        local key=user_proc('GetAsyncKeyState','int16_t (*)(int)')
        local pid=proc('GetCurrentProcessId','uint32_t (*)(void)')()
        local point,rect,window_pid=ffi.new('LobaoArmorPoint[1]'),ffi.new('LobaoArmorRect[1]'),ffi.new('uint32_t[1]')
        function self.cursor(width,height)
            local window=foreground()
            if window==nil or owner(window,window_pid)==0 or window_pid[0]~=pid then return nil end
            if cursor(point)==0 or client(window,point)==0 or client_rect(window,rect)==0 then return nil end
            local w,h=rect[0].right-rect[0].left,rect[0].bottom-rect[0].top
            if w<=0 or h<=0 or point[0].x<0 or point[0].y<0 or point[0].x>=w or point[0].y>=h then return nil end
            return tonumber(point[0].x)*width/w,(h-tonumber(point[0].y))*height/h,key(1)<0
        end
        local process = proc('GetCurrentProcess','void *(*)(void)')()
        local memory = proc('ReadProcessMemory','int (*)(void *, const void *, void *, size_t, size_t *)')
        local received, read_buffer = ffi.new('size_t[1]'), ffi.new('uint8_t[4096]')
        local ergo_restore = export('ArmorBridgeErgoRestore','int (*)(void)')
        local ergo_step = export('ArmorBridgeErgoStep','int (*)(int)')
        local read_ergo = export('ArmorBridgeReadErgo','void (*)(LobaoArmorErgoStats *)')
        local ergo_state=ffi.new('LobaoArmorErgoStats[1]')
        local swim_step=export('ArmorBridgeSwimStep','int (*)(int)')
        local read_swim=export('ArmorBridgeReadSwim','void (*)(LobaoArmorSwimStats *)')
        local swim_state=ffi.new('LobaoArmorSwimStats[1]')
        local heavy_step=export('ArmorBridgeHeavyArmorStep','int (*)(uint32_t)')
        local read_movement=export('ArmorBridgeReadMovement','void (*)(LobaoArmorMovementStats *)')
        local read_record=export('ArmorBridgeReadCharacterRecord','int (*)(uint32_t *)')
        local record_words=ffi.new('uint32_t[13]')
        local record_float=ffi.new('float[1]')
        -- PT-BR: Pesquisa: devolve os 13 valores do registro local como float e hexadecimal, ou nil.
        -- EN: Research: returns the local record's 13 values as float and hexadecimal, or nil.
        function self.character_record()
            if read_record(record_words)~=1 then return nil end
            local out={}
            for i=0,12 do
                ffi.copy(record_float,record_words+i,4)
                out[#out+1]=string.format('%d:%.4g(%08x)',i*4,tonumber(record_float[0]),tonumber(record_words[i]))
            end
            return table.concat(out,' ')
        end
        local movement_state=ffi.new('LobaoArmorMovementStats[1]')
        assert(ffi.sizeof('LobaoArmorMovementStats')==48,'Layout da velocidade incompatível')
        function self.heavy_step(wanted,armor_id) return tonumber(heavy_step(wanted and armor_id or 4294967295)) end
        local read_equipped=export('ArmorBridgeReadEquipped','void (*)(LobaoArmorEquippedStats *)')
        local equipped=ffi.new('LobaoArmorEquippedStats[1]')
        assert(ffi.sizeof('LobaoArmorEquippedStats')==16,'Layout da armadura equipada incompatível')
        -- PT-BR: Lido todo quadro: devolve a mesma tabela enquanto nada muda (sem lixo para o coletor). Quem recebe não altera.
        -- EN: Read every frame: returns the same table while nothing changes (no garbage for the collector). Callers never modify it.
        local equipped_out={}
        function self.equipped()
            read_equipped(equipped)
            local e=equipped[0]
            local avatar,armor_id,weight,valid=tonumber(e.avatar),tonumber(e.armor_id),tonumber(e.weight),tonumber(e.valid)
            local o=equipped_out
            if o.avatar~=avatar or o.armor_id~=armor_id or o.weight~=weight or o.valid~=valid then
                equipped_out={avatar=avatar,armor_id=armor_id,weight=weight,valid=valid}
            end
            return equipped_out
        end
        function self.movement_stats()
            read_movement(movement_state)
            local out={}
            for _,field in ipairs({'record','reason','avatar','applied','restored','refused','active','before','expected','observed'}) do
                out[field]=tonumber(movement_state[0][field])
            end
            return out
        end
        local read_handling=export('ArmorBridgeReadHandling','void (*)(uintptr_t, LobaoArmorHandlingStats *)')
        local handling_state=ffi.new('LobaoArmorHandlingStats[1]')
        assert(ffi.sizeof('LobaoArmorErgoStats')==72,'Layout do diagnóstico de ergonomia incompatível')
        assert(ffi.sizeof('LobaoArmorSwimStats')==48 and ffi.sizeof('LobaoArmorHandlingStats')==224,
            'Layout dos diagnósticos novos incompatível')
        function self.swim_step(wanted) return tonumber(swim_step(wanted and 1 or 0)) end
        function self.swim_stats()
            read_swim(swim_state)
            local out={}
            for _,field in ipairs({'field','reason','weight','applied','restored','refused','active',
                'before','expected','observed','locked'}) do out[field]=tonumber(swim_state[0][field]) end
            return out
        end
        function self.handling(at)
            read_handling(at or 0,handling_state)
            local s=handling_state[0]
            local out={reason=tonumber(s.reason),source_value=tonumber(s.source_value),rows={}}
            if out.reason==0 then
                for i=0,tonumber(s.count)-1 do
                    local row=s.rows[i]
                    out.rows[#out.rows+1]={entity=tonumber(row.entity),unit=tonumber(row.unit),
                        base=tonumber(row.base),current=tonumber(row.current),
                        response_a=tonumber(row.response_a),response_b=tonumber(row.response_b)}
                end
            end
            return out
        end
        function self.ergo_stats()
            read_ergo(ergo_state)
            local out={}
            for _,field in ipairs({'record','weight','reason','writes','verified','neutral','restores',
                'restore_refused','refused','before','expected','observed','pending',
                'protection_windows','protection_failed','locked'}) do
                out[field]=tonumber(ergo_state[0][field])
            end
            return out
        end
        function self.ergo_restore() return tonumber(ergo_restore()) end
        function self.ergo_step(wanted) return tonumber(ergo_step(wanted and 1 or 0)) end
        function self.readonly(at, size)
            if type(at)~='number' or at<65536 or at>=140737488355328 or type(size)~='number'
                or size<1 or size>4096 or size%1~=0 then return nil end
            received[0]=0
            if memory(process,ffi.cast('const void *',at),read_buffer,size,received)==0
                or tonumber(received[0])~=size then return nil end
            return ffi.string(read_buffer,size)
        end
        function self.game_base()
            local game=kernel.GetModuleHandleA('game.dll')
            return game~=nil and tonumber(ffi.cast('uintptr_t',game)) or nil
        end
        local pop_combat=export('ArmorBridgePopCombat','int (*)(LobaoArmorCombatSampleV3 *)')
        assert(ffi.sizeof('LobaoArmorOriginV3')==160 and ffi.sizeof('LobaoArmorCombatSampleV3')==512,'Layout da origem incompatível')
        assert(ffi.sizeof('LobaoArmorCauseStatsV3')==112,'Layout do resumo de causas incompatível')
        local combat=ffi.new('LobaoArmorCombatSampleV3[1]')
        local function hex(bytes)
            return (bytes:gsub('.',function(c) return string.format('%02x',c:byte()) end))
        end
        local type_box=ffi.new('uint64_t[1]')
        local function type_hex(value)
            type_box[0]=value
            local words=ffi.cast('const uint32_t *',type_box)
            return string.format('%08X%08X',tonumber(words[1]),tonumber(words[0]))
        end
        function self.combat()
            if pop_combat(combat)~=1 then return nil end
            local out={}
            for _,field in ipairs({'stage','kind','victim','parent','extra_valid','producer','dealer','owner'}) do out[field]=tonumber(combat[0][field]) end
            out.data=hex(ffi.string(combat[0].data,out.stage==1 and 280 or 112))
            out.extra=hex(ffi.string(combat[0].extra,20))
            out.dealer_type=type_hex(combat[0].dealer_type)
            out.owner_type=type_hex(combat[0].owner_type)
            local o=combat[0].origin
            local origin={}
            for _,field in ipairs({'sequence','kind','victim','parent','producer','cause','flags','region',
                'dealer','owner','dealer_unit','victim_unit','distance','reserved','net_entity','net_unit','net_distance','reach','hit_to_victim','hit_to_dealer'}) do origin[field]=tonumber(o[field]) end
            origin.net_type=type_hex(o.net_type)
            origin.net_position={tonumber(o.net_position[0]),tonumber(o.net_position[1]),tonumber(o.net_position[2])}
            origin.dealer_full=origin.reserved
            origin.dealer_health_type=type_hex(o.dealer_health_type)
            origin.owner_health_type=type_hex(o.owner_health_type)
            origin.dealer_position={tonumber(o.dealer_position[0]),tonumber(o.dealer_position[1]),tonumber(o.dealer_position[2])}
            origin.victim_position={tonumber(o.victim_position[0]),tonumber(o.victim_position[1]),tonumber(o.victim_position[2])}
            out.origin=origin
            return out
        end
        local read_cause=export('ArmorBridgeReadCause','int (*)(uint32_t,LobaoArmorCauseStatsV3 *)')
        local cause=ffi.new('LobaoArmorCauseStatsV3[1]')
        function self.cause(index)
            if read_cause(index,cause)~=1 then return nil end
            local out={}
            for _,field in ipairs({'kind','element','cause','producer','count','linked','known','reduced',
                'damage_min','damage_max','distance_count','regions','distance_min','distance_max','distance_sum',
                'reach_sum','reach_min','reach_max','reach_count','net_count'}) do
                out[field]=tonumber(cause[0][field])
            end
            out.damage_sum=tonumber(cause[0].damage_sum)
            out.dealer_type=type_hex(cause[0].dealer_type)
            out.net_type=type_hex(cause[0].net_type)
            return out
        end
        local read_origin=export('ArmorBridgeReadOrigin','void (*)(LobaoArmorOriginStats *)')
        local origin_stats=ffi.new('LobaoArmorOriginStats[1]')
        function self.origin_stats()
            read_origin(origin_stats)
            local out={}
            for _,field in ipairs({'built','linked','ambiguous','unlinked','link_busy','recorded','overflow','version'}) do
                out[field]=tonumber(origin_stats[0][field])
            end
            return out
        end
        local detach = export('ArmorBridgeDetach','int (*)(void)')
        function self.detach() return tonumber(detach()) end
        local refresh = export('ArmorBridgeRefreshLocal','void (*)(void)')
        local details = export('ArmorBridgeReadDetail','void (*)(LobaoArmorBridgeDetail *)')
        local info = ffi.new('LobaoArmorBridgeDetail[1]')
        local protect = export('ArmorBridgeProtect','void (*)(int)')
        function self.protect(value) protect(value and 1 or 0) end
        local profile_step=export('ArmorBridgeProfileStep','int (*)(uint32_t,int)')
        function self.profile_step(id,reinforced) return tonumber(profile_step(id or 0,reinforced and 1 or 0)) end
        local armor_step=export('ArmorBridgeArmorStep','int (*)(uint32_t,int)')
        function self.armor_step(id,reinforced) return tonumber(armor_step(id or 0,reinforced and 1 or 0)) end
        local read_effect = export('ArmorBridgeReadEffect','void (*)(LobaoArmorBridgeEffect *)')
        local read_melee = export('ArmorBridgeReadMelee','void (*)(LobaoArmorMeleeStatsV4 *)')
        assert(ffi.sizeof('LobaoArmorTotals')==56,'Layout dos totais incompatível')
        assert(ffi.sizeof('LobaoArmorReport')==520,'Layout do relatório incompatível')
        local read_report=export('ArmorBridgeReadReport','void (*)(LobaoArmorReport *)')
        local armor_report=ffi.new('LobaoArmorReport[1]')
        local function hex64(v) return string.format('%08X%08X',tonumber(v/4294967296ULL),tonumber(v%4294967296ULL)) end
        -- PT-BR: O relatório só muda junto com a última sequência (sobe a cada registro); sem mudança, a mesma tabela volta.
        -- EN: The report only changes together with the last sequence (raised on every record); unchanged, the same table returns.
        local report_out=nil
        function self.report()
            read_report(armor_report)
            local r=armor_report[0]
            if report_out and report_out.last.sequence==tonumber(r.last_sequence) then return report_out end
            local out={regions={},attackers={}}
            for g=0,3 do
                local row=r.regions[g]
                out.regions[g+1]={hits=tonumber(row.hits),blocked=tonumber(row.blocked),reduced=tonumber(row.reduced),
                    full=tonumber(row.full),taken=tonumber(row.taken),prevented=tonumber(row.prevented)}
            end
            for i=0,math.min(tonumber(r.attacker_count),16)-1 do
                local a=r.attackers[i]
                out.attackers[#out.attackers+1]={type=hex64(a.type),hits=tonumber(a.hits),taken=tonumber(a.taken),prevented=tonumber(a.prevented)}
            end
            out.last={type=hex64(r.last_type),sequence=tonumber(r.last_sequence),avatar=tonumber(r.last_avatar),region=tonumber(r.last_region),
                before=tonumber(r.last_before),after=tonumber(r.last_after),kind=tonumber(r.last_kind)}
            report_out=out
            return out
        end
        local read_totals=export('ArmorBridgeReadTotals','void (*)(LobaoArmorTotals *)')
        local totals=ffi.new('LobaoArmorTotals[1]')
        -- PT-BR: Os totais só mudam com a sequência (sobe por último), a missão ou a sessão; sem mudança, a mesma tabela volta.
        -- EN: Totals only change with the sequence (raised last), the mission or the session; unchanged, the same table returns.
        local totals_fields={'sequence','shots_blocked','shots_reduced','shot_prevented','melee_reduced','melee_prevented','last_kind','last_prevented','mission','last_region','last_collider','last_after'}
        local totals_out=nil
        function self.totals()
            read_totals(totals)
            local t=totals[0]
            local sequence,mission,session=tonumber(t.sequence),tonumber(t.mission),tonumber(t.session)
            local o=totals_out
            if o and o.sequence==sequence and o.mission==mission and o.session==session then return o end
            local out={}
            for _,field in ipairs(totals_fields) do out[field]=tonumber(t[field]) end
            out.session=session
            out.gaps=self.gaps and self.gaps() or 0
            totals_out=out
            return out
        end
        assert(ffi.sizeof('LobaoArmorMeleeStatsV4')==96,'Layout do corpo a corpo incompatível')
        assert(ffi.sizeof('LobaoArmorUnknownAttack')==24,'Layout do aviso incompatível')
        local pop_unknown=export('ArmorBridgePopUnknown','int (*)(LobaoArmorUnknownAttack *)')
        local unknown=ffi.new('LobaoArmorUnknownAttack[1]')
        function self.unknown_attack()
            if pop_unknown(unknown)~=1 then return nil end
            local out={}
            for _,field in ipairs({'sequence','victim','cause','damage','kind','element'}) do out[field]=tonumber(unknown[0][field]) end
            return out
        end
        local melee = ffi.new('LobaoArmorMeleeStatsV4[1]')
        function self.melee_stats()
            read_melee(melee)
            local out={}
            for _,field in ipairs({'prepared','rejected','matched','ambiguous','unknown','applied','refused',
                'victim','cause','region','armor_id','weight','before','after','reason','keep_percent','collider','reinforced','proximity','distance','by_attacker','lethal','max_health'}) do out[field]=tonumber(melee[0][field]) end
            return out
        end
        local effect = ffi.new('LobaoArmorBridgeEffect[1]')
        function self.effect()
            read_effect(effect)
            local out = {}
            for _, field in ipairs({'enabled','applied','blocked','reduced','refused','victim','region','before','after','reason'}) do
                out[field] = tonumber(effect[0][field])
            end
            return out
        end
        local read_decision = export('ArmorBridgeReadDecision','void (*)(LobaoArmorBridgeDecision *)')
        assert(ffi.sizeof('LobaoArmorBridgeDecision')==72,'Layout da identificação de volumes incompatível')
        local decision = ffi.new('LobaoArmorBridgeDecision[1]')
        function self.decision()
            read_decision(decision)
            local out = {}
            for _, field in ipairs({'evaluated','unavailable','blocked','reduced','original','victim','region',
                'armor_id','weight','damage','projected','rule','penetration','factor','collider','identified','fallback','heavy_av4'}) do
                out[field] = tonumber(decision[0][field])
            end
            return out
        end
        local read_prediction = export('ArmorBridgeReadPrediction','void (*)(LobaoArmorBridgePrediction *)')
        local predicted = ffi.new('LobaoArmorBridgePrediction[1]')
        function self.prediction()
            read_prediction(predicted)
            local out = {}
            for _, field in ipairs({'rebuilt','rejected','matched','unmatched','ambiguous','victim','region','damage','selected'}) do
                out[field] = tonumber(predicted[0][field])
            end
            out.penetration = {}
            for i=0,3 do out.penetration[i+1] = tonumber(predicted[0].penetration[i]) end
            return out
        end
        local sampling = export('ArmorBridgeReadSampling','void (*)(LobaoArmorBridgeSampling *)')
        local quota = ffi.new('LobaoArmorBridgeSampling[1]')
        function self.sampling()
            sampling(quota)
            local out = {}
            for _, field in ipairs({'projectile_seen','other_seen','projectile_captured','other_captured',
                'quota_avatar','projectile_remaining','other_remaining'}) do out[field] = tonumber(quota[0][field]) end
            return out
        end
        function self.refresh_local() refresh() end
        function self.detail()
            details(info)
            local out = {}
            for _, field in ipairs({'late_installed','local_avatar','local_init_seen','local_apply_seen',
                'late_seen','local_late_seen','local_captured','local_read_failed','region','source_kind',
                'parent_return_rva','sample_avatar','raw_damage','multiplier'}) do out[field] = tonumber(info[0][field]) end
            out.penetration = {}
            for i=0,3 do out.penetration[i+1] = tonumber(info[0].penetration[i]) end
            return out
        end
    end
    return self
end
return M
