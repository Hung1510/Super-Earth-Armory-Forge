local M={}
local function key(id)
    if type(id)~='number' or id<1 or id>=4294967295 or id%1~=0 then return nil end
    return string.format('0x%08x',id)
end
function M.decode(data)
    local profiles={}
    if type(data)~='string' or #data>65536 then return profiles end
    for line in data:gmatch('[^\r\n]+') do
        local id,mode=line:match('^(0x%x%x%x%x%x%x%x%x)=([a-z]+[34]?)$')
        local normalized=id and key(tonumber(id:sub(3),16))
        if normalized and (mode=='av3' or mode=='av4' or mode=='standard' or mode=='reinforced') then
            profiles[normalized]=(mode=='av4' or mode=='reinforced') or nil
        end
    end
    return profiles
end
function M.encode(profiles)
    local ids,lines={},{}
    for id,value in pairs(profiles) do
        local normalized=type(id)=='string' and id:match('^0x%x%x%x%x%x%x%x%x$') and key(tonumber(id:sub(3),16))
        if normalized==id and value==true then ids[#ids+1]=id end
    end
    table.sort(ids)
    for _,id in ipairs(ids) do lines[#lines+1]=id..'=reinforced' end
    return table.concat(lines,'\n')..'\n'
end
function M.new(api,note)
    local self={}
    local ok,data=pcall(api.load_profiles)
    local profiles=M.decode(ok and data or nil)
    function self.get(id) local id_key=key(id);return id_key and profiles[id_key]==true or false end
    function self.choose(id,reinforced)
        local id_key=key(id)
        if not id_key or type(reinforced)~='boolean' then return false end
        local next_profiles={};for existing,value in pairs(profiles) do next_profiles[existing]=value end
        next_profiles[id_key]=reinforced or nil
        local encoded=M.encode(next_profiles)
        local saved,result=pcall(api.save_profiles,encoded)
        if not saved or result~=true then note('Perfil não salvo; a escolha anterior foi preservada.');return false end
        profiles=next_profiles
        note('Perfil no Arsenal: armadura='..id_key..'; modo='..(reinforced and 'reforçado' or 'padrão'))
        return true
    end
    return self
end
return M
