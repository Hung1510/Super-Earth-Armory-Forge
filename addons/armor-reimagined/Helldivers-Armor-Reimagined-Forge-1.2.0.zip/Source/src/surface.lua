local M = {}
function M.new(note)
    local self = {parts = {}}
    note = note or function() end
    local function exists(sr,world)
        if not sr or not sr.Application or type(sr.Application.worlds)~='function' then return false end
        for _,candidate in pairs(sr.Application.worlds() or {}) do if candidate==world then return true end end
        return false
    end
    function self.ready(sr,world,fonts)
        if not exists(sr,world) or not fonts or not sr.IdString64 or not sr.Application.can_get then return false end
        for _,resource in ipairs({{'font',fonts.font},{'texture',fonts.atlas},{'material',fonts.material}}) do
            if not resource[2] then return false end
            local ok,loaded=pcall(sr.Application.can_get,resource[1],sr.IdString64.from_hex(resource[2]))
            if not ok or loaded~=true then return false end
        end
        return true
    end
    function self.valid(sr) return self.gui~=nil and self.sr==sr and self.ready(sr,self.world,self.fonts) end
    function self.close()
        -- PT-BR: O motor já destrói a GUI junto com o mundo; não reutiliza um ponteiro de mundo removido.
        -- EN: The engine destroys its GUI with the world; do not reuse a removed world pointer.
        if self.gui and exists(self.sr,self.world) then pcall(self.sr.World.destroy_gui, self.world, self.gui) end
        self.gui, self.world, self.parts, self.fonts = nil, nil, {}, nil
    end
    function self.bind(sr, world, fonts)
        if not self.ready(sr,world,fonts) then self.close();return false end
        if self.world ~= world or self.sr ~= sr or not self.fonts
            or self.fonts.font~=fonts.font or self.fonts.atlas~=fonts.atlas or self.fonts.material~=fonts.material then self.close() end
        if self.gui then return true end
        if not world or not sr or not sr.World or not sr.Gui then return false end
        self.sr, self.world = sr, world
        local ok, gui = pcall(sr.World.create_screen_gui, world, 'scale', 1, 1)
        if not ok or not gui then self.world = nil; return false end
        self.gui = gui
        self.fonts = {font=fonts.font,atlas=fonts.atlas,material=fonts.material}
        if fonts and fonts.font and fonts.material and sr.IdString64 and sr.Material then
            local prepared, why = pcall(function()
                local id = sr.IdString64.from_hex
                local ink = sr.Gui.material(gui, id(fonts.material))
                for _, key in ipairs({'8035c266','5e8455fe','309e7783','82b803a8'}) do
                    sr.Material.set_scalar(ink,id(key .. '00000000'),0)
                end
                sr.Material.set_vector2(ink,id('e13777ce00000000'),sr.Vector2(1,-1))
                sr.Material.set_vector4(ink,id('7701209e00000000'),sr.Color(0,0,0,0))
                if fonts.atlas then sr.Material.set_texture(ink,id('88bac99b00000000'),id(fonts.atlas)) end
            end)
            if not prepared then self.close(); note('Fonte do seletor indisponível: ' .. tostring(why)); return false end
        end
        return true
    end
    function self.sync(items)
        if not self.valid(self.sr) then self.close();return false end
        local sr, gui, present = self.sr, self.gui, {}
        local ok, why = pcall(function()
            -- PT-BR: IdString64 expira ao fim do frame; persiste só o hexadecimal e converte ao desenhar.
            -- EN: IdString64 expires at frame end; persist only hex strings and convert when drawing.
            local font=sr.IdString64.from_hex(self.fonts.font)
            local material=sr.IdString64.from_hex(self.fonts.material)
            for _, item in ipairs(items) do
                if present[item.id] then error('ID de desenho repetido') end
                present[item.id] = true
                local old = self.parts[item.id]
                if old and old.kind ~= item.kind then error('Tipo de desenho mudou para o mesmo ID') end
                local tint = sr.Color(item.color[1],item.color[2],item.color[3],item.color[4])
                local at = sr.Vector3(item.x or 0,item.y or 0,item.layer or 2)
                local created
                if item.kind == 'rect' then
                    local size = sr.Vector2(item.w,item.h)
                    if old then sr.Gui.update_rect(gui,old.handle,at,size,tint)
                    else created = sr.Gui.rect(gui,at,size,tint) end
                elseif item.kind == 'triangle' then
                    -- PT-BR: A camada vai também no Z dos vértices, como nos retângulos.
                    -- EN: The layer also goes into the vertices' Z, as with rectangles.
                    local z = item.layer or 2
                    local a, b, c = sr.Vector3(item.a[1],item.a[2],z),sr.Vector3(item.b[1],item.b[2],z),sr.Vector3(item.c[1],item.c[2],z)
                    if old then sr.Gui.update_triangle(gui,old.handle,a,b,c,item.layer or 2,tint)
                    else created = sr.Gui.triangle(gui,a,b,c,item.layer or 2,tint) end
                elseif item.kind == 'text' then
                    -- PT-BR: Recria o texto; update_text tem outra ordem de argumentos e não deve herdar a chamada de text.
                    -- EN: Recreate text; update_text has a different argument order and must not inherit the text call.
                    if old then
                        sr.Gui.destroy_text(gui,old.handle)
                        self.parts[item.id]=nil;old=nil
                    end
                    created = sr.Gui.text(gui,item.text,font,item.size,material,at,tint)
                else error('Desenho inválido') end
                if not old then
                    if created == nil then error('Motor não devolveu o objeto de desenho') end
                    self.parts[item.id] = {handle = created, kind = item.kind}
                end
            end
            for id, part in pairs(self.parts) do
                if not present[id] then
                    sr.Gui['destroy_' .. part.kind](gui,part.handle); self.parts[id] = nil
                end
            end
        end)
        if not ok then self.close(); note('Desenho suspenso: ' .. tostring(why)); return false end
        return true
    end
    return self
end
return M
