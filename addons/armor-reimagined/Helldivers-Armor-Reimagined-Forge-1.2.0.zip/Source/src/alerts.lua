local M={}
function M.new(api,note,presentation)
    local self,surface={},HAPSurface.new(note)
    local shown,expires,last_sound=nil,0,-8000
    local recent,order={},{}
    local notice,notice_code,notice_until=nil,nil,0
    function self.close() shown=nil;expires=0;surface.close() end
    -- PT-BR: Aviso de 15 s quando o mod se desliga (versão do jogo ou falha de segurança); não depende de missão.
    -- EN: 15 s notice when the mod turns itself off (game version or safety failure); no mission required.
    function self.notice(kind,code,now) notice=kind;notice_code=code;notice_until=(now or 0)+15000 end
    local function draw_notice(sr,now,language)
        if not notice or now>=notice_until then notice=nil;return false end
        if not sr or not sr.Gui or not sr.Application then return true end
        local fonts=presentation.alert_fonts()
        local world=sr.Application.main_world()
        if not fonts or not world or not surface.bind(sr,world,fonts) then return true end
        local width,height=sr.Gui.resolution()
        if type(width)~='number' or type(height)~='number' or width<=0 or height<=0 then return true end
        local scale=math.min(width/1920,height/1080)
        local x,y,w=(width-720*scale)/2,height-160*scale,720*scale
        local text=HAPI18n.get(language)
        local body=notice=='version' and text.notice_version or string.format(text.notice_refused,tostring(notice_code))
        surface.sync({
            {id='alert_bg',kind='rect',x=x,y=y,w=w,h=64*scale,color={235,12,14,16},layer=1100},
            {id='alert_title',kind='text',text=text.notice_title,x=x+12*scale,y=y+38*scale,size=17*scale,color={255,250,220,40},layer=1101},
            {id='alert_hint',kind='text',text=body,x=x+12*scale,y=y+14*scale,size=15*scale,color={255,235,235,235},layer=1101}
        })
        return true
    end
    function self.before_ui(sr)
        if surface.gui and not surface.valid(sr) then surface.close() end
    end
    function self.step(sr,now,wanted,language)
        if notice then
            local shown_notice=draw_notice(sr,now,language)
            if shown_notice then return end
            surface.close()
        end
        local equipped=api.equipped()
        local valid=wanted and equipped.valid==1
        -- PT-BR: Consome a fila mesmo desligado; golpes antigos não geram alertas ao reativar ou reaparecer.
        -- EN: Drain even when disabled; old hits must not alert after re-enabling or respawning.
        for _=1,16 do
            local attack=api.unknown_attack()
            if not attack then break end
            if valid and attack.victim==equipped.avatar and attack.kind==6 and attack.element==0
                and attack.cause~=0 and attack.damage>0 then
                local previous=recent[attack.cause]
                if (not previous or now-previous>=60000) and now-last_sound>=8000 then
                    if not previous then
                        order[#order+1]=attack.cause
                        if #order>64 then recent[table.remove(order,1)]=nil end
                    end
                    recent[attack.cause]=now;last_sound=now;shown=attack;expires=now+6000
                    local ok,result=pcall(api.alert_sound)
                    note(string.format('Aviso de ataque não identificado: evento=%u; avatar=%u; causa=0x%08x; dano=%u; som=%s. Anote o inimigo e o golpe; dano original.',
                        attack.sequence,attack.victim,attack.cause,attack.damage,tostring(ok and result==true)))
                end
            end
        end
        if not valid or not shown or shown.victim~=equipped.avatar or now>=expires then self.close();return end
        if not sr or not sr.Gui or not sr.Application then surface.close();return end
        local fonts=presentation.alert_fonts()
        local world=sr.Application.main_world()
        if not fonts or not surface.bind(sr,world,fonts) then surface.close();return end
        local width,height=sr.Gui.resolution()
        if type(width)~='number' or type(height)~='number' or width<=0 or height<=0 then surface.close();return end
        local scale=math.min(width/1920,height/1080)
        local x,y,w=(width-620*scale)/2,height-160*scale,620*scale
        local text=HAPI18n.get(language)
        surface.sync({
            {id='alert_bg',kind='rect',x=x,y=y,w=w,h=82*scale,color={235,12,14,16},layer=1100},
            {id='alert_title',kind='text',text=text.alert_title,x=x+12*scale,y=y+58*scale,size=17*scale,color={255,250,220,40},layer=1101},
            {id='alert_hint',kind='text',text=text.alert_hint,x=x+12*scale,y=y+34*scale,size=15*scale,color={255,235,235,235},layer=1101},
            {id='alert_detail',kind='text',text=string.format(text.alert_detail,shown.cause,shown.damage),x=x+12*scale,y=y+12*scale,size=14*scale,color={255,180,180,180},layer=1101}
        })
    end
    return self
end
return M
