# Validação da 0.16.2

## Motivo

Teste real da 0.16.1 (Devastador comum e de escudo, porrada até morrer): o descritor de vida passou a resolver o causador 678 como `B4ED319B39F5457B`, e o usuário confirmou que **foi um MG Raider com espada de energia no braço esquerdo** — identificação correta. Golpes: `0xab3862b0` 40–45 (sem redução) e `0x5c934d9a` 67→53 (reduzido, pesada reforçada). Mas a distância calculada foi 112–127 m, impossível para golpe próximo: uma das posições lidas está errada. O causador 681 (outro atacante, `0xab3862b0`) não resolveu.

## Alterações

- `alcance do golpe`: distância entre os dois pontos gravados no próprio golpe (+0x34/+0x40), sem depender de entidades.
- `Posições do impacto`: posições brutas do atacante, do personagem local e da hipótese por ID de rede, mais a distância do ponto do golpe até cada uma — mostra qual leitura está fora do lugar.
- Hipótese de ID de rede registrada lado a lado (marcas 8192/16384), para os causadores que não resolvem.
- Catálogo de nomes ampliado para 501 entidades (`raw-health.json`), gerado por `tools/generate_source_names.py`.
- Resumo por causa com alcance mín/médio/máx e tipo via rede.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas. Em partida: comparar `ponto do golpe até você` (esperado < 2 m) e `início do golpe até o atacante`; conferir alcance de golpes (~1–3 m) contra tiros.
