# Validação da 0.18.1

Pedido: leve padrão +10% de velocidade, leve reforçada +5%. Mesmo mecanismo do movimento da pesada (fator composto da instância local em registro+4, restauração antes de reaplicar, remoção só do nosso multiplicador se o terreno alterar depois). Média permanece original. Fatores aceitos pela escrita: 0,90/0,95/1,05/1,10. Painel do Arsenal mostra +10%/+5% em verde nos três idiomas.

Verificação: suítes nativa (100 alternâncias 1,10↔1,05 sem acumular, troca para média restaura 1,0) e LuaJIT/DLL/interface aprovadas. Em partida: conferir no log "Movimento da armadura" antes×1,10 e antes×1,05.
