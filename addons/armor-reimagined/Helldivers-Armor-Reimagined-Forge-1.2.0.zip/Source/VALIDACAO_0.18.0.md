# Validação da 0.18.0

## Pedido

Versão enxuta para caminhar até a 1.0: menu MODS somente com o idioma ("tira aquelas opções sem sentido"); diagnóstico pesado fora do uso normal.

## Alterações

- Menu: removidos mod ligado, aplicar proteção, ergonomia, descrições, natação e avisos. Tudo sempre ligado; desligar = desabilitar no Arsenal. Valores antigos salvos dessas opções são ignorados.
- Aviso sonoro de ataque desconhecido desligado.
- Diagnóstico detalhado (fila bruta de combate, linhas Origem/Posições/Resumo, leituras de pesquisa por ID de entidade, geração, posição direta, alcance) só com `RegionalArmorDiagnostics.txt` presente; verificação a cada 10 s; exportação nativa `ArmorBridgeDiagnostics`.
- Sem diagnóstico, cada golpe local faz só: mapa de rede → descritor de vida → posição do atacante e do personagem local (proteção) e ligação preparo→evento.
- Regras de dano idênticas à 0.17.2.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas: menu com uma única opção, valores antigos ignorados, fila bruta vazia sem diagnóstico, resolução enxuta (só posição local/ rede), gatilho por arquivo ausente na DLL real e ligado no teste do addon.
