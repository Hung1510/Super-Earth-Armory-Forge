#pragma once
#include <stdint.h>
#include <stddef.h>
#include "damage_source.h"
#include "projectile_replay.h"
enum {
    ARMOR_ORIGIN_DEALER_ENTITY=1,ARMOR_ORIGIN_OWNER_ENTITY=2,
    ARMOR_ORIGIN_DEALER_HEALTH=4,ARMOR_ORIGIN_OWNER_HEALTH=8,
    ARMOR_ORIGIN_DEALER_POSITION=16,ARMOR_ORIGIN_VICTIM_POSITION=32,
    ARMOR_ORIGIN_KEY=64,ARMOR_ORIGIN_CAUSE=128,ARMOR_ORIGIN_LINKED=256,ARMOR_ORIGIN_AMBIGUOUS=512,
    ARMOR_ORIGIN_DEALER_GENERATION=1024,ARMOR_ORIGIN_OWNER_GENERATION=2048,
    ARMOR_ORIGIN_REACH=4096,ARMOR_ORIGIN_NET_HEALTH=8192,ARMOR_ORIGIN_NET_POSITION=16384
};
typedef struct ArmorOrigin {
    uint32_t sequence,kind,victim,parent,producer,cause,flags,region;
    uint32_t dealer,owner,dealer_unit,victim_unit;
    uint64_t dealer_type,owner_type,dealer_health_type,owner_health_type;
    float dealer_position[3],victim_position[3],distance;
    uint32_t reserved;
    uint32_t net_entity,net_unit;
    uint64_t net_type;
    float net_position[3],net_distance,reach,hit_to_victim,hit_to_dealer,unused;
} ArmorOrigin;
typedef struct ArmorCauseStats {
    uint64_t dealer_type,damage_sum;
    double distance_sum;
    uint32_t kind,element,cause,producer,count,linked,known,reduced;
    uint32_t damage_min,damage_max,distance_count,regions;
    float distance_min,distance_max;
    double reach_sum;
    uint64_t net_type;
    float reach_min,reach_max;
    uint32_t reach_count,net_count;
} ArmorCauseStats;
int ArmorSourceHealth(uintptr_t game,ArmorSourceReader read,uint32_t entity,uint64_t *type,uint32_t *unit);
uint32_t ArmorEntityComplete(uintptr_t exe,ArmorSourceReader read,uint32_t id);
uint32_t ArmorEntityFromNetwork(uintptr_t game,ArmorSourceReader read,uint32_t network);
int ArmorHitReach(const unsigned char *hit,float *reach);
void ArmorHitGaps(const unsigned char *hit,ArmorOrigin *origin);
int ArmorSourceUnitPosition(uintptr_t exe,ArmorSourceReader read,uint32_t unit,float out[3]);
void ArmorOriginResolve(uintptr_t game,uintptr_t exe,ArmorSourceReader read,ArmorOrigin *origin,int full);
int ArmorOriginRemember(const ArmorReplayKey *key,const ArmorOrigin *origin,uint64_t now);
int ArmorOriginTake(const ArmorReplayKey *key,uint64_t now,ArmorOrigin *out);
void ArmorOriginClear(void);
uint32_t ArmorCauseRegionBit(uint32_t region);
int ArmorCauseRecord(const ArmorOrigin *origin,uint32_t element,uint32_t damage,uint32_t known,uint32_t reduced);
int ArmorCauseRead(uint32_t index,ArmorCauseStats *out);
uint32_t ArmorCauseVersion(void);
uint32_t ArmorCauseOverflow(void);
void ArmorCauseClear(void);
