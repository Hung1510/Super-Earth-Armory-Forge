#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int (*ArmorSourceReader)(uintptr_t,void *,size_t);
int ArmorSourceType(uintptr_t base,ArmorSourceReader read,uint32_t entity,uint64_t *type);
