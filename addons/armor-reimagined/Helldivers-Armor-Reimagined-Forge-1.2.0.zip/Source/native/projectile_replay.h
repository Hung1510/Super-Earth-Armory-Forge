#pragma once
#include <stdint.h>
typedef float (*ArmorRound)(float);
typedef struct ArmorReplayInput {
    float durable, base[2], extra[4], scale;
} ArmorReplayInput;
typedef struct ArmorReplayKey { uint32_t words[13]; } ArmorReplayKey;
typedef struct ArmorReplaySample {
    ArmorReplayKey key;
    uint32_t region, collider;
    uint32_t armor_id, weight, equipment_valid;
    uint32_t avatar_network, session_confirmed, epoch, heavy_av4, reinforced;
    float penetration[4], selected;
    uint32_t glancing;
} ArmorReplaySample;
int ArmorReplayCalculate(const ArmorReplayInput *input, ArmorRound round_value, float out[4]);
void ArmorReplayHitKey(const unsigned char *hit, ArmorReplayKey *key);
void ArmorReplayEventKey(const unsigned char *event, ArmorReplayKey *key);
int ArmorReplayRemember(const ArmorReplaySample *sample, uint64_t now);
int ArmorReplayMatch(const ArmorReplayKey *key, uint64_t now, ArmorReplaySample *out);
int ArmorReplayMatchMerged(const ArmorReplayKey *key, uint64_t now, ArmorReplaySample *out, float *penetration, unsigned char *glancing, unsigned capacity, unsigned *count);
void ArmorReplayClear(void);
int ArmorReplayRememberCollider(uintptr_t context,const unsigned char *hit,uint32_t collider,uint64_t now);
uint32_t ArmorReplayTakeCollider(uintptr_t context,const unsigned char *hit,uint64_t now);
