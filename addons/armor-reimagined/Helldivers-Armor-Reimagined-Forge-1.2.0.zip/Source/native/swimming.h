#pragma once
#include <stdint.h>
#include "local_runtime.h"
typedef struct ArmorSwimStats {
    uintptr_t field;
    uint32_t reason,weight,applied,restored,refused,active;
    float before,expected,observed;
    uint32_t locked;
} ArmorSwimStats;
int ArmorSwimStep(const ArmorOwnedRecord *record, float maximum, uint32_t weight, int eligible);
int ArmorSwimRestore(void);
void ArmorSwimReadStats(ArmorSwimStats *out);
