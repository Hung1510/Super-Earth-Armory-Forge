#include "private_session.h"
#include <windows.h>
#include <string.h>
typedef struct Session {
    uintptr_t context,lobby,handle;
    uint64_t local,host,session,stamp;
    uint32_t mode,allowed;
} Session;
static SRWLOCK cache_lock=SRWLOCK_INIT;
static Session cache;
static int snapshot(ArmorRuntimeRead read,uintptr_t game,Session *out) {
    Session s={0};uintptr_t state,engine;uint32_t transition,hosting;
    if (!game || !read(game+0x347cef0,&s.context,8) || s.context<65536
        || !read(game+0x3326340,&state,8) || state<65536 || !read(state+0xac21c,&s.mode,4)
        || s.mode!=4 || !read(s.context+0xb398,&s.local,8) || !s.local
        || !read(s.context+0xb3a8,&s.host,8) || !s.host
        || !read(s.context+0xb390,&s.session,8) || !s.session
        || !read(s.context+0x171c8,&s.allowed,4) || s.allowed
        || !read(s.context+0x159b0+28,&transition,4) || transition
        || (s.local==s.host && (!read(s.context+0x159b0+24,&hosting,4) || hosting!=1))
        || !read(s.context+0x1d470,&engine,8) || engine<65536
        || !read(engine+0x10,&s.lobby,8) || s.lobby<65536
        || !read(s.lobby+0x118,&s.allowed,4) || s.allowed!=3
        || !read(s.lobby+0x120,&s.handle,8) || !s.handle) return 0;
    s.allowed=0;*out=s;return 1;
}
static int same(const Session *a,const Session *b) {
    return a->context==b->context && a->local==b->local && a->host==b->host && a->session==b->session
        && a->lobby==b->lobby && a->handle==b->handle && a->mode==b->mode;
}
int ArmorSessionRefresh(ArmorRuntimeRead read,uintptr_t game) {
    Session s={0},after;
    if (snapshot(read,game,&s)) {
        // PT-BR: Público e SOS são permitidos; identidade e sessão estável continuam obrigatórias.
        // EN: Public and SOS are allowed; identity and a stable session remain mandatory.
        s.allowed=1;
        if (!snapshot(read,game,&after) || !same(&s,&after)) s.allowed=0;
    }
    s.stamp=GetTickCount64();
    AcquireSRWLockExclusive(&cache_lock);
    int changed=!same(&s,&cache) || s.allowed!=cache.allowed;
    cache=s;ReleaseSRWLockExclusive(&cache_lock);
    return changed;
}
uint64_t ArmorSessionCurrent(void) {
    // PT-BR: Identificador da missão confirmada mais recente; 0 fora de missão.
    // EN: Identifier of the latest confirmed mission; 0 outside a mission.
    if (!TryAcquireSRWLockShared(&cache_lock)) return 0;
    uint64_t id=cache.allowed ? cache.session : 0;
    ReleaseSRWLockShared(&cache_lock);return id;
}
int ArmorSessionMission(ArmorRuntimeRead read,uintptr_t game) {
    Session current,s;
    if (!snapshot(read,game,&current) || !TryAcquireSRWLockShared(&cache_lock)) return 0;
    s=cache;ReleaseSRWLockShared(&cache_lock);
    uint64_t now=GetTickCount64();
    return s.allowed && now>=s.stamp && now-s.stamp<=750 && same(&s,&current);
}
