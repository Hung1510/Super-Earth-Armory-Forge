#include "projectile_replay.h"
#include <windows.h>
#include <math.h>
#include <string.h>
#include "spin_lock.h"

int ArmorReplayCalculate(const ArmorReplayInput *input, ArmorRound round_value, float out[4]) {
    if (!input || !round_value || !out || !isfinite(input->durable) || input->durable < 0
        || input->durable > 1 || !isfinite(input->scale) || input->scale < 0 || input->scale > 100) return 0;
    for (unsigned i=0; i<2; ++i) if (!isfinite(input->base[i]) || fabsf(input->base[i]) > 100) return 0;
    // PT-BR: Preserva a ordem das operações float32 do construtor e do ajuste do projétil.
    // EN: Preserve the float32 operation order of the constructor and projectile adjustment.
    float first = (1.0f-input->durable)*input->base[0];
    float second = input->durable*input->base[1];
    float mixed = second+first, temporary[4];
    for (unsigned i=0; i<4; ++i) {
        if (!isfinite(input->extra[i]) || fabsf(input->extra[i]) > 100) return 0;
        float sum = mixed+input->extra[i];
        float scaled = (sum > 0 ? sum : 0)*input->scale;
        if (!isfinite(scaled) || scaled > 100) return 0;
        temporary[i] = round_value(scaled);
        if (!isfinite(temporary[i]) || temporary[i] < 0 || temporary[i] > 100) return 0;
    }
    memcpy(out, temporary, sizeof(temporary));
    return 1;
}
void ArmorReplayHitKey(const unsigned char *hit, ArmorReplayKey *key) {
    const unsigned offsets[13] = {0x20,4,0x24,0x84,0x104,0x110,0x114,0x34,0x38,0x3c,0x88,0x8c,0x90};
    for (unsigned i=0; i<13; ++i) memcpy(&key->words[i], hit+offsets[i], 4);
}
void ArmorReplayEventKey(const unsigned char *event, ArmorReplayKey *key) {
    const unsigned offsets[13] = {0,8,0xc,0x10,0x14,0x18,0x1c,0x50,0x54,0x58,0x44,0x48,0x4c};
    for (unsigned i=0; i<13; ++i) memcpy(&key->words[i], event+offsets[i], 4);
}
static struct { ArmorReplaySample sample; uint64_t time; int used; } pending[128];
static volatile LONG lock;
static unsigned next;
static struct {
    uintptr_t context;
    uint32_t victim, actor, position[3], collider,kind;
    uint64_t time;
    int used;
} volumes[128];
static unsigned volume_next;
static uint32_t volume_word(const unsigned char *hit,unsigned at) {
    uint32_t value;memcpy(&value,hit+at,4);return value;
}
int ArmorReplayRememberCollider(uintptr_t context,const unsigned char *hit,uint32_t collider,uint64_t now) {
    if (!context || !hit || !ArmorTake(&lock)) return 0;
    // PT-BR: Reutilização do contexto invalida a captura anterior, inclusive nomes desconhecidos.
    // EN: Context reuse invalidates the previous capture, including unknown names.
    for (unsigned i=0;i<128;i++) if (volumes[i].context==context) volumes[i].used=0;
    if ((volume_word(hit,0)==0 || volume_word(hit,0)==6) && collider && volume_word(hit,0x24)!=UINT32_MAX) {
        unsigned i=volume_next;volume_next=(volume_next+1)%128;
        volumes[i].context=context;volumes[i].victim=volume_word(hit,0x20);
        volumes[i].actor=volume_word(hit,0x24);
        volumes[i].kind=volume_word(hit,0);
        // PT-BR: A origem em +4 ainda não foi preenchida nesta etapa; a posição já está inicializada.
        // EN: The source at +4 has not been filled at this stage; the position is already initialized.
        memcpy(volumes[i].position,hit+0x34,sizeof(volumes[i].position));
        volumes[i].collider=collider;volumes[i].time=now;volumes[i].used=1;
    }
    InterlockedExchange(&lock,0);return 1;
}
uint32_t ArmorReplayTakeCollider(uintptr_t context,const unsigned char *hit,uint64_t now) {
    if (!context || !hit || !ArmorTake(&lock)) return 0;
    uint32_t collider=0;
    for (unsigned i=0;i<128;i++) if (volumes[i].used) {
        if (now<volumes[i].time || now-volumes[i].time>1000) volumes[i].used=0;
        else if (volumes[i].context==context) {
            if (volumes[i].kind==volume_word(hit,0) && volumes[i].victim==volume_word(hit,0x20)
                && volumes[i].actor==volume_word(hit,0x24)
                && !memcmp(volumes[i].position,hit+0x34,sizeof(volumes[i].position)))
                collider=volumes[i].collider;
            volumes[i].used=0;
        }
    }
    InterlockedExchange(&lock,0);return collider;
}
int ArmorReplayRemember(const ArmorReplaySample *sample, uint64_t now) {
    if (!sample || !ArmorTake(&lock)) return 0;
    pending[next].sample = *sample;
    pending[next].time = now;
    pending[next].used = 1;
    next = (next+1)%128;
    InterlockedExchange(&lock, 0);
    return 1;
}
int ArmorReplayMatch(const ArmorReplayKey *key, uint64_t now, ArmorReplaySample *out) {
    if (!key || !out || !ArmorTake(&lock)) return -1;
    unsigned matches = 0, selected = 0;
    for (unsigned i=0; i<128; ++i) if (pending[i].used) {
        if (now < pending[i].time || now-pending[i].time > 1000) pending[i].used = 0;
        else if (!memcmp(key, &pending[i].sample.key, sizeof(*key))) { ++matches; selected = i; }
    }
    // PT-BR: Uma chave ambígua é consumida sem associar AP ao evento errado.
    // EN: An ambiguous key is consumed without assigning AP to the wrong event.
    if (matches > 1) {
        for (unsigned i=0; i<128; ++i)
            if (pending[i].used && !memcmp(key, &pending[i].sample.key, sizeof(*key))) pending[i].used = 0;
    } else if (matches == 1) {
        *out = pending[selected].sample;
        pending[selected].used = 0;
    }
    InterlockedExchange(&lock, 0);
    return matches == 1 ? 1 : matches > 1 ? -2 : 0;
}
static int same_profile(const ArmorReplaySample *a,const ArmorReplaySample *b) {
    return a->region==b->region && a->collider==b->collider && a->armor_id==b->armor_id && a->weight==b->weight
        && a->equipment_valid==b->equipment_valid && a->avatar_network==b->avatar_network
        && a->session_confirmed==b->session_confirmed && a->epoch==b->epoch && a->heavy_av4==b->heavy_av4
        && a->reinforced==b->reinforced;
}
int ArmorReplayMatchMerged(const ArmorReplayKey *key, uint64_t now, ArmorReplaySample *out, float *penetration, unsigned char *glancing, unsigned capacity, unsigned *count) {
    if (!key || !out || !count || !penetration || !glancing || !capacity || !ArmorTake(&lock)) return -1;
    // PT-BR: Escopeta: o jogo soma os chumbos que acertam a mesma parte no mesmo quadro num evento só,
    // com vítima, elemento, volume, causador e dono iguais e posição média. Exige 2+ chumbos pendentes,
    // mesmo perfil de decisão e posição do evento dentro da caixa dos chumbos; caso contrário, nada é alterado.
    // EN: Shotgun: the game sums pellets hitting the same part in the same frame into one event, with equal
    // victim, element, volume, dealer and owner and an averaged position. Requires 2+ pending pellets,
    // the same decision profile and the event position inside the pellets' box; otherwise nothing changes.
    // PT-BR: A penetração de cada chumbo muda com o ângulo; ela volta por chumbo para a decisão somar.
    // EN: Each pellet's penetration changes with the angle; it is returned per pellet so the decision can sum.
    unsigned group[128],n=0,consistent=1;
    float low[3],high[3],at[3];
    memcpy(at,&key->words[7],sizeof(at));
    for (unsigned i=0;i<128;++i) if (pending[i].used) {
        if (now<pending[i].time || now-pending[i].time>1000) {pending[i].used=0;continue;}
        if (memcmp(key->words,pending[i].sample.key.words,7*sizeof(uint32_t))) continue;
        float p[3];memcpy(p,&pending[i].sample.key.words[7],sizeof(p));
        for (unsigned a=0;a<3;++a) {
            if (!n || p[a]<low[a]) low[a]=p[a];
            if (!n || p[a]>high[a]) high[a]=p[a];
        }
        if (n && !same_profile(&pending[group[0]].sample,&pending[i].sample)) consistent=0;
        group[n++]=i;
    }
    int inside=n>=2;
    for (unsigned a=0;a<3 && inside;++a)
        if (!isfinite(at[a]) || at[a]<low[a]-0.01f || at[a]>high[a]+0.01f) inside=0;
    if (!inside) {InterlockedExchange(&lock,0);*count=0;return 0;}
    if (n>capacity) consistent=0;
    if (consistent) {
        *out=pending[group[0]].sample;
        for (unsigned g=0;g<n;++g) {penetration[g]=pending[group[g]].sample.selected;glancing[g]=pending[group[g]].sample.glancing ? 1 : 0;}
    }
    for (unsigned g=0;g<n;++g) pending[group[g]].used=0;
    InterlockedExchange(&lock,0);
    *count=n;return consistent ? 1 : -2;
}
void ArmorReplayClear(void) {
    if (!ArmorTake(&lock)) return;
    memset(pending, 0, sizeof(pending));
    memset(volumes,0,sizeof(volumes));volume_next=0;
    next = 0;
    InterlockedExchange(&lock, 0);
}
