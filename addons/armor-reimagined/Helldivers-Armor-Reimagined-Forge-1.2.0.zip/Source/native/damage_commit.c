#include "damage_commit.h"
#include "melee.h"
#include <windows.h>
#include <string.h>
extern int ArmorExchangeDamage(void *, uint32_t, uint32_t);
static int commit(uintptr_t context, const unsigned char expected[0x70], uint32_t damage,uint32_t required_kind) {
    unsigned char current[0x70];
    uint32_t previous, kind;
    SIZE_T received;
    MEMORY_BASIC_INFORMATION memory;
    if (!expected || context<65536 || context>UINT64_C(0x800000000000)-sizeof(current) || (context+0x2c)%4) return 0;
    memcpy(&previous,expected+0x2c,4); memcpy(&kind,expected+4,4);
    if (kind!=required_kind || damage>=previous
        || VirtualQuery((void *)context,&memory,sizeof(memory))!=sizeof(memory)
        || memory.State!=MEM_COMMIT || memory.Protect!=PAGE_READWRITE
        || context+sizeof(current)>(uintptr_t)memory.BaseAddress+memory.RegionSize
        || !ReadProcessMemory(GetCurrentProcess(),(void *)context,current,sizeof(current),&received)
        || received!=sizeof(current) || memcmp(current,expected,sizeof(current))) return 0;
    // PT-BR: Apenas o dano muda; a troca exige que o valor original ainda esteja presente.
    // EN: Only damage changes; the exchange requires the original value to still be present.
    return ArmorExchangeDamage((void *)(context+0x2c),damage,previous)==1;
}
int ArmorDamageCommit(uintptr_t context,const unsigned char expected[0x70],uint32_t damage) {
    return commit(context,expected,damage,0);
}
int ArmorMeleeDamageCommit(uintptr_t context,const unsigned char expected[0x70],uint32_t damage,int proximity) {
    if (!expected) return 0;
    uint32_t element,cause,previous;
    memcpy(&element,expected+8,4);memcpy(&cause,expected+0x60,4);memcpy(&previous,expected+0x2c,4);
    if ((!ArmorMeleeKnown(6,element,cause) && !(proximity && !element))
        || (damage!=ArmorMeleeDamage(previous,65) && damage!=ArmorMeleeDamage(previous,70) && damage!=ArmorMeleeDamage(previous,75)
            && damage!=ArmorMeleeDamage(previous,80) && damage!=ArmorMeleeDamage(previous,85)
            && damage!=ArmorMeleeDamage(previous,90))) return 0;
    return commit(context,expected,damage,6);
}
