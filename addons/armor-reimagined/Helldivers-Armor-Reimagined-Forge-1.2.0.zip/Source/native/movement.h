#pragma once
#include "local_runtime.h"
typedef struct ArmorMovementStats {
    uintptr_t record;
    uint32_t reason,avatar,applied,restored,refused,active;
    float before,expected,observed;
    uint32_t reserved;
} ArmorMovementStats;
int ArmorMovementApply(const ArmorOwnedRecord *record);
int ArmorMovementAllowed(float factor);
int ArmorMovementApplyFactor(const ArmorOwnedRecord *record,float factor);
int ArmorMovementRestore(void);
int ArmorMovementSuspend(uint32_t reason);
int ArmorMovementValid(uint32_t avatar);
void ArmorMovementReadStats(ArmorMovementStats *out);
