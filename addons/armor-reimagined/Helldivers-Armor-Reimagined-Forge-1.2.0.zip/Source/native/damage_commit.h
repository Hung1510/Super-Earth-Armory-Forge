#pragma once
#include <stdint.h>
int ArmorDamageCommit(uintptr_t context, const unsigned char expected[0x70], uint32_t damage);
int ArmorMeleeDamageCommit(uintptr_t context,const unsigned char expected[0x70],uint32_t damage,int proximity);
