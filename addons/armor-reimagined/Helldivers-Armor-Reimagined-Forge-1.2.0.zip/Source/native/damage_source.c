#include "damage_source.h"
#include <string.h>
static uint32_t u32(const unsigned char *p,unsigned o) {uint32_t v;memcpy(&v,p+o,4);return v;}
int ArmorSourceType(uintptr_t base,ArmorSourceReader read,uint32_t entity,uint64_t *type) {
    if (!base || !read || !type || !entity || entity==UINT32_MAX) return 0;
    uintptr_t manager,buckets,after;
    unsigned char header[24],again[24],descriptor[12],check[12];
    if (!read(base+0x346bf98,&manager,8) || manager<65536 || manager>=UINT64_C(0x800000000000)
        || !read(manager+0xf1aeb0,header,sizeof(header))) return 0;
    memcpy(&buckets,header,8);
    uint32_t capacity=u32(header,8),empty=u32(header,12),multiplier=u32(header,16);
    if (buckets<65536 || buckets>=UINT64_C(0x800000000000) || !capacity
        || capacity>1048576 || (capacity&(capacity-1))) return 0;
    // PT-BR: Consulta limitada ao ID do evento; não varre o mundo nem reutiliza descritores destruídos.
    // EN: Bound lookup to the event ID; never scan the world or reuse destroyed descriptors.
    uint32_t start=entity*multiplier;
    for (uint32_t probe=0;probe<capacity && probe<64;probe++) {
        unsigned char entry[8];
        uintptr_t bucket=buckets+((start+probe)&(capacity-1))*8;
        if (!read(bucket,entry,8)) return 0;
        uint32_t key=u32(entry,0),index=u32(entry,4);
        if (key==entity) {
            if (index>=1048576) return 0;
            uintptr_t at=manager+0xf32f18+(uintptr_t)index*24;
            if (!read(at,descriptor,12) || u32(descriptor,8)!=entity
                || !read(at,check,12) || memcmp(check,descriptor,12)
                || !read(manager+0xf1aeb0,again,24) || memcmp(header,again,24)
                || !read(base+0x346bf98,&after,8) || after!=manager) return 0;
            uint64_t result;memcpy(&result,descriptor,8);
            if (!result) return 0;
            *type=result;return 1;
        }
        if (key==empty) return 0;
    }
    return 0;
}
