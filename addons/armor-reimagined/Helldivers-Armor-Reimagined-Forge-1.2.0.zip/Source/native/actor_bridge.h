#pragma once
#include <stdint.h>
#include <stddef.h>
#include "ergonomics.h"
#include "movement.h"
#include "damage_origin.h"
#ifdef ARMOR_BRIDGE_TEST
#define BRIDGE_API
#else
#define BRIDGE_API __declspec(dllexport)
#endif
typedef struct ArmorBridgeStats {
    uint32_t installed, enabled, status, slot_protection;
    uint32_t init_seen, apply_seen, captured, dropped, read_failed;
    uint32_t stage, victim, zone, source_kind, damage;
    uint32_t protection_active;
} ArmorBridgeStats;
typedef struct ArmorBridgeDetail {
    uint32_t late_installed, local_avatar, local_init_seen, local_apply_seen;
    uint32_t late_seen, local_late_seen, local_captured, local_read_failed;
    uint32_t region, source_kind, parent_return_rva, sample_avatar;
    float penetration[4], raw_damage, multiplier;
} ArmorBridgeDetail;
typedef struct ArmorBridgeSampling {
    uint32_t projectile_seen, other_seen, projectile_captured, other_captured;
    uint32_t quota_avatar, projectile_remaining, other_remaining;
} ArmorBridgeSampling;
typedef struct ArmorBridgePrediction {
    uint32_t rebuilt, rejected, matched, unmatched, ambiguous;
    uint32_t victim, region, damage;
    float penetration[4], selected;
} ArmorBridgePrediction;
typedef struct ArmorBridgeDecision {
    uint32_t evaluated, unavailable, blocked, reduced, original;
    uint32_t victim, region, armor_id, weight, damage, projected, rule;
    float penetration, factor;
    uint32_t collider, identified, fallback, heavy_av4;
} ArmorBridgeDecision;
typedef struct ArmorBridgeEffect {
    uint32_t enabled, applied, blocked, reduced, refused;
    uint32_t victim, region, before, after, reason;
} ArmorBridgeEffect;
typedef struct ArmorMeleeStats {
    uint32_t prepared,rejected,matched,ambiguous,unknown,applied,refused;
    uint32_t victim,cause,region,armor_id,weight,before,after,reason,keep_percent,collider,reinforced;
    uint32_t proximity;float distance;
    uint32_t by_attacker,lethal;
    uint32_t max_health,reserved;
} ArmorMeleeStats;
typedef struct ArmorUnknownAttack {uint32_t sequence,victim,cause,damage,kind,element;} ArmorUnknownAttack;
BRIDGE_API int ArmorBridgePopUnknown(ArmorUnknownAttack *out);
// PT-BR: Totais acumulados de proteção aplicada; a sequência muda a cada evento para o indicador na tela.
// EN: Accumulated totals of applied protection; the sequence changes on every event for the on-screen indicator.
typedef struct ArmorTotals {
    uint32_t sequence,shots_blocked,shots_reduced,shot_prevented,melee_reduced,melee_prevented;
    uint32_t last_kind,last_prevented,mission,last_region;uint64_t session;
    uint32_t last_collider,last_after;
} ArmorTotals;
BRIDGE_API void ArmorBridgeReadTotals(ArmorTotals *out);
// PT-BR: Relatório da armadura: golpes por região (cabeça, tronco, braços, pernas), por tipo de atacante e o último golpe.
// EN: Armor report: hits per region (head, torso, arms, legs), per attacker type and the last hit.
typedef struct ArmorRegionStats {uint32_t hits,blocked,reduced,full,taken,prevented;} ArmorRegionStats;
typedef struct ArmorAttackerStats {uint64_t type;uint32_t hits,taken,prevented,reserved;} ArmorAttackerStats;
typedef struct ArmorReport {
    ArmorRegionStats regions[4];
    ArmorAttackerStats attackers[16];
    uint32_t attacker_count,overflow;
    uint64_t last_type;
    uint32_t last_sequence,last_avatar,last_region,last_before,last_after,last_kind;
} ArmorReport;
BRIDGE_API void ArmorBridgeReadReport(ArmorReport *out);
BRIDGE_API void ArmorBridgeReadMelee(ArmorMeleeStats *out);
BRIDGE_API int ArmorBridgeProfileStep(uint32_t armor_id,int reinforced);
BRIDGE_API int ArmorBridgeArmorStep(uint32_t armor_id,int reinforced);
BRIDGE_API int ArmorBridgeInstall(void);
BRIDGE_API void ArmorBridgeEnable(int enabled);
BRIDGE_API void ArmorBridgeReadStats(ArmorBridgeStats *out);
BRIDGE_API int ArmorBridgeDetach(void);
BRIDGE_API void ArmorBridgeRefreshLocal(void);
BRIDGE_API void ArmorBridgeReadDetail(ArmorBridgeDetail *out);
BRIDGE_API void ArmorBridgeReadSampling(ArmorBridgeSampling *out);
BRIDGE_API void ArmorBridgeReadPrediction(ArmorBridgePrediction *out);
BRIDGE_API void ArmorBridgeReadDecision(ArmorBridgeDecision *out);
BRIDGE_API void ArmorBridgeProtect(int enabled);
BRIDGE_API void ArmorBridgeReadEffect(ArmorBridgeEffect *out);
BRIDGE_API int ArmorBridgeErgoRestore(void);
BRIDGE_API int ArmorBridgeErgoStep(int wanted);
BRIDGE_API void ArmorBridgeReadErgo(ArmorErgoStats *out);
BRIDGE_API int ArmorBridgeHeavyStep(int wanted);
BRIDGE_API int ArmorBridgeHeavyArmorStep(uint32_t armor_id);
BRIDGE_API void ArmorBridgeReadMovement(ArmorMovementStats *out);
typedef struct ArmorEquippedStats {uint32_t avatar,armor_id,weight,valid;} ArmorEquippedStats;
BRIDGE_API void ArmorBridgeReadEquipped(ArmorEquippedStats *out);
typedef struct ArmorCombatSample {
    uint32_t stage,kind,victim,parent;
    unsigned char data[0x118], extra[20];
    uint32_t extra_valid,producer,dealer,owner;
    uint64_t dealer_type,owner_type;
    ArmorOrigin origin;
} ArmorCombatSample;
typedef struct ArmorOriginStats {uint32_t built,linked,ambiguous,unlinked,link_busy,recorded,overflow,version;} ArmorOriginStats;
BRIDGE_API int ArmorBridgePopCombat(ArmorCombatSample *out);
BRIDGE_API int ArmorBridgeReadCause(uint32_t index,ArmorCauseStats *out);
BRIDGE_API void ArmorBridgeReadOrigin(ArmorOriginStats *out);
BRIDGE_API void ArmorBridgeDiagnostics(int value);
BRIDGE_API void ArmorBridgeAngledPlates(int value);
BRIDGE_API void ArmorBridgeArmGaps(int value);
BRIDGE_API uint32_t ArmorBridgeFireNative(void);
// PT-BR: Pesquisa de fogo (só leitura): último episódio de queimadura encerrado (1,5 s sem fogo).
// EN: Fire research (read-only): last finished burn episode (1.5 s without fire).
typedef struct ArmorFireStats {uint32_t sequence,ticks,direct,ground,burning,duration_ms,armor_id,weight;float damage,first_damage;
    uint32_t ignition,avatar,health_start[7],health_end[7];} ArmorFireStats;
BRIDGE_API void ArmorBridgeReadFire(ArmorFireStats *out);
// PT-BR: Pesquisa de derrubada e tranco (só leitura): status ativos no personagem local e modificadores do passivo.
// EN: Knockdown and flinch research (read-only): active statuses on the local character and the passive's modifiers.
typedef struct ArmorStatusEntry {uint32_t id,on;float value,clock,ends;} ArmorStatusEntry;
typedef struct ArmorStatusDump {uint32_t valid,owner,count,reserved;ArmorStatusEntry entry[16];} ArmorStatusDump;
typedef struct ArmorPassiveModifier {uint32_t stat,op;float value;uint32_t reserved;} ArmorPassiveModifier;
typedef struct ArmorPassiveTable {uint32_t id,name,count,reserved;ArmorPassiveModifier modifier[8];} ArmorPassiveTable;
typedef struct ArmorPassiveDump {uint32_t valid,owner,key,tables;ArmorPassiveTable table[2];} ArmorPassiveDump;
BRIDGE_API void ArmorBridgeReadStatus(ArmorStatusDump *out);
BRIDGE_API void ArmorBridgeReadPassives(ArmorPassiveDump *out);
BRIDGE_API void ArmorBridgeResearchState(uint32_t out[9]);
// PT-BR: Registro de cada impacto local (só com diagnóstico): tipo 1 = tiro decidido, 2 = corpo a corpo, 3 = fogo direto nativo.
// flags: bit0 raspão, bit1 placas inclinadas usadas, bits 8-15 chumbos, 16-23 sorteios de fresta, 24-31 frestas que passaram.
// EN: Record of every local hit (diagnostics only): kind 1 = decided shot, 2 = melee, 3 = native direct fire.
// flags: bit0 glancing, bit1 angled plates used, bits 8-15 pellets, 16-23 gap rolls, 24-31 gaps that passed.
typedef struct ArmorHitLog {
    uint32_t sequence,kind,element,cause,region,collider,weight,reinforced,before,after,reason,flags;
    float ap,distance;uint64_t attacker;
} ArmorHitLog;
BRIDGE_API int ArmorBridgePopHit(ArmorHitLog *out);
BRIDGE_API uint32_t ArmorBridgeRefusedProtection(void);
BRIDGE_API uint32_t ArmorBridgeRefusedState(void);
// PT-BR: Pesquisa da 1.2 (só com diagnóstico): blocos de configuração do dano (arma/golpe) para achar a força de cambaleio,
// tecla de marcação e troca temporária de um modificador do passivo vestido (restaurada ao desligar).
// EN: 1.2 research (diagnostics only): damage settings blocks (weapon/strike) to find the stagger force, a marker key and
// a temporary override of one modifier of the worn passive (restored when turned off).
typedef struct ArmorSettingsDump {
    uint32_t sequence,kind,region,damage;
    unsigned char base[96],extra[96],projectile[128];
} ArmorSettingsDump;
BRIDGE_API int ArmorBridgePopSettings(ArmorSettingsDump *out);
BRIDGE_API int ArmorBridgeKeyDown(int virtual_key);
BRIDGE_API int ArmorBridgePassiveOverride(uint32_t stat,float value,int enable);
BRIDGE_API uint32_t ArmorBridgeReadGaps(void);
BRIDGE_API int ArmorBridgeReadCharacterRecord(uint32_t out[13]);
void ArmorActorHook(void);
void ArmorLateHook(void);
void ArmorBridgeObserve(uintptr_t site, uintptr_t context, uint32_t zone);
void ArmorBridgeObserveLate(uintptr_t context, uintptr_t parent_return_address);
extern void *ArmorActorOriginal;
extern uintptr_t ArmorBridgeInitSite, ArmorBridgeApplySite;
extern void *ArmorLateOriginal;
extern uintptr_t ArmorBridgeLateSite;
#ifdef ARMOR_BRIDGE_TEST
int ArmorBridgeTestInstall(void **slot, uintptr_t init_site, uintptr_t apply_site);
int ArmorBridgeTestExchange(void **slot, void *replacement, void *expected);
int ArmorBridgeTestLateInstall(void **slot, uintptr_t site);
void ArmorBridgeTestSetLocal(uint32_t entity);
void ArmorBridgeTestReplay(void *round_value, void *select_value);
void ArmorBridgeTestPredict(const unsigned char *hit, uintptr_t context, uintptr_t parent);
void ArmorBridgeTestEquipment(int (*reader)(uintptr_t, void *, size_t));
void ArmorBridgeTestIdentity(uint32_t network, int session_confirmed);
void ArmorBridgeTestCategoryCache(uint64_t ms);
void ArmorBridgeTestMaxHealth(uint32_t value);
void ArmorBridgeTestNow(uint64_t ms);
void ArmorBridgeTestHurt(uint64_t ms);
#endif
