#include "armor_equipment.h"
#include <string.h>

static uint32_t u32(const unsigned char *data, size_t offset) {
    uint32_t value; memcpy(&value, data+offset, 4); return value;
}
static uintptr_t pointer(const unsigned char *data, size_t offset) {
    uintptr_t value; memcpy(&value, data+offset, 8); return value;
}
static int ptr(ArmorEquipmentReader read, uintptr_t at, uintptr_t *value) {
    // PT-BR: Registros serializados válidos podem começar em múltiplos de quatro bytes.
    // EN: Valid serialized records can start at four-byte boundaries.
    return read(at, value, 8) && *value >= 65536 && *value < UINT64_C(0x800000000000) && !(*value%4);
}
static int capture(uintptr_t base, ArmorEquipmentReader read, ArmorEquipmentCache *cache, ArmorEquipment *out) {
    uintptr_t profile, user, players, catalog;
    unsigned char header[12], gear[12], peer[8], candidate[8];
    uint32_t count;
    if (!ptr(read,base+0x347cdd8,&profile) || !read(profile+0x150,gear,12)
        || !ptr(read,base+0x347cef0,&user) || !read(user+0xb398,peer,8)
        || !memcmp(peer,"\0\0\0\0\0\0\0\0",8)
        || !ptr(read,base+0x347ce50,&players) || !read(players+0x2d200,&count,4)
        || !count || count>32 || !ptr(read,base+0x33264f8,&catalog) || !read(catalog,header,12)) return 0;
    uint32_t id=u32(gear,8), total=u32(header,8);
    uintptr_t array=pointer(header,0), selected=0;
    if (!id || id==UINT32_MAX || !total || total>2048 || array<65536 || array%4) return 0;
    for (unsigned i=0;i<count;++i) {
        uintptr_t row=players+i*0x1690;
        if (!read(row,candidate,8)) return 0;
        if (!memcmp(candidate,peer,8)) { if (selected) return 0; selected=row+0x38+0x12c; }
    }
    uint32_t selected_id;
    if (!selected || !read(selected,&selected_id,4) || selected_id!=id) return 0;
    uintptr_t kit=0;
    // PT-BR: Reutiliza só a localização; categoria e seleção são relidas em cada consulta.
    // EN: Reuse only the location; category and selection are reread on every query.
    if (cache->id==id && cache->catalog==catalog && cache->array==array && cache->count==total) kit=cache->kit;
    else {
        for (uint32_t i=0;i<total;++i) {
            uintptr_t entry;
            uint32_t entry_id;
            if (!ptr(read,array+i*8,&entry) || !read(entry,&entry_id,4)) return 0;
            if (entry_id==id) { if (kit) return 0; kit=entry; }
        }
    }
    unsigned char descriptor[64], bodies_data[8*24];
    if (!kit || !read(kit,descriptor,64) || u32(descriptor,0)!=id || u32(descriptor,40)!=0) return 0;
    uintptr_t bodies=pointer(descriptor,48), nbody=pointer(descriptor,56);
    if (!nbody || nbody>8 || !read(bodies,bodies_data,nbody*24)) return 0;
    uint32_t weight=UINT32_MAX, armor_pieces=0, weights[3]={0};
    for (uintptr_t b=0;b<nbody;++b) {
        uintptr_t pieces=pointer(bodies_data,b*24+8), npiece=pointer(bodies_data,b*24+16);
        if (!npiece || npiece>64) return 0;
        for (uintptr_t i=0;i<npiece;++i) {
            unsigned char piece[20], after[20];
            if (!read(pieces+i*96,piece,20)) return 0;
            if (u32(piece,12)==0) {
                uint32_t value=u32(piece,16);
                if (value>2) return 0;
                ++weights[value]; ++armor_pieces;
            }
            if (!read(pieces+i*96,after,20) || memcmp(after,piece,20)) return 0;
        }
    }
    // PT-BR: Conjuntos válidos podem misturar pesos; só uma maioria estrita define a categoria.
    // EN: Valid kits can mix piece weights; only a strict majority defines the category.
    for (uint32_t value=0;value<3;++value) {
        if (weights[value]>armor_pieces/2) weight=value;
    }
    if (weight==UINT32_MAX) return 0;
    unsigned char after_descriptor[64], after_bodies[8*24], after_peer[8], after_header[12];
    uintptr_t after_profile, after_user, after_players, after_catalog;
    uint32_t after_count, after_id;
    if (!armor_pieces || !ptr(read,base+0x347cdd8,&after_profile) || after_profile!=profile
        || !read(profile+0x158,&after_id,4) || after_id!=id
        || !ptr(read,base+0x347cef0,&after_user) || after_user!=user
        || !read(user+0xb398,after_peer,8) || memcmp(after_peer,peer,8)
        || !ptr(read,base+0x347ce50,&after_players) || after_players!=players
        || !read(players+0x2d200,&after_count,4) || after_count!=count
        || !read(selected-0x38-0x12c,after_peer,8) || memcmp(after_peer,peer,8)
        || !read(selected,&after_id,4) || after_id!=id
        || !ptr(read,base+0x33264f8,&after_catalog) || after_catalog!=catalog
        || !read(catalog,after_header,12) || memcmp(after_header,header,12)
        || !read(kit,after_descriptor,64) || memcmp(after_descriptor,descriptor,64)
        || !read(bodies,after_bodies,nbody*24) || memcmp(after_bodies,bodies_data,nbody*24)) return 0;
    cache->id=id; cache->catalog=catalog; cache->array=array; cache->count=total; cache->kit=kit;
    out->id=id; out->weight=weight;
    return 1;
}
int ArmorEquipmentRead(uintptr_t base, ArmorEquipmentReader read, ArmorEquipmentCache *cache, ArmorEquipment *out) {
    if (!read || !cache || !out || !base) return 0;
    memset(out,0,sizeof(*out)); out->weight=UINT32_MAX;
    if (capture(base,read,cache,out)) return 1;
    memset(cache,0,sizeof(*cache)); return 0;
}
