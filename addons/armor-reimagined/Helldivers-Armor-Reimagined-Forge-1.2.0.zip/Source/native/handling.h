#pragma once
#include <stdint.h>
typedef struct ArmorHandlingRow {uint32_t entity,unit;float base,current,response_a,response_b;} ArmorHandlingRow;
typedef struct ArmorHandlingStats {
    uintptr_t source;
    uint64_t resource;
    float source_value;
    uint32_t count,reason;
    ArmorHandlingRow rows[8];
} ArmorHandlingStats;
_Static_assert(sizeof(ArmorHandlingRow)==24,"ArmorHandlingRow ABI");
_Static_assert(sizeof(ArmorHandlingStats)==224,"ArmorHandlingStats ABI");
