#include "ergonomics.h"
#include <string.h>
#include <math.h>
static ArmorOwnedRecord owned;
static uint32_t original[4],written[4],pending;
static const uint32_t offsets[4]={0x360,0x3a8,0x340,0x344};
static ArmorErgoStats stats={.weight=UINT32_MAX};
static float number(uint32_t bits) {float v;memcpy(&v,&bits,4);return v;}
static uint32_t bits(float value) {uint32_t v;memcpy(&v,&value,4);return v;}
static float normalized(float value) {return fminf(100,fmaxf(0,value))*0.01f;}
static int read_values(const ArmorOwnedRecord *r,uint32_t out[4]) {
    if (!ArmorOwnedValidate(ArmorRuntimeReadSelf,r)) return 0;
    for (unsigned i=0;i<4;i++) if (!ArmorRuntimeReadSelf(r->record+offsets[i],out+i,4)) return 0;
    return ArmorOwnedValidate(ArmorRuntimeReadSelf,r);
}
void ArmorErgoReadStats(ArmorErgoStats *out) {if (out) {*out=stats;out->pending=!!pending;}}
int ArmorErgoReject(uint32_t reason) {
    stats.reason=reason;stats.refused++;stats.record=0;stats.weight=UINT32_MAX;
    stats.before=stats.expected=stats.observed=0;return 0;
}
int ArmorErgoRestore(void) {
    uint32_t mask=pending,current[4];pending=0;
    if (!mask) return 1;
    ArmorOwnedRecord relocated;
    if (!ArmorOwnedRefresh(ArmorRuntimeReadSelf,&owned,&relocated)
        || !read_values(&relocated,current)) {stats.restore_refused++;return 0;}
    owned=relocated;
    int ok=1;
    // PT-BR: Só desfaz campos ainda nossos na mesma instância; preserva recalculações do jogo e outros mods.
    // EN: Undo only still-owned fields in the same instance; preserve game recalculations and other mods.
    for (unsigned i=0;i<4;i++) if (mask&(1u<<i)) {
        if (current[i]==original[i]) continue;
        if (current[i]!=written[i] || !ArmorOwnedExchange(&owned,offsets[i],original[i],written[i])) ok=0;
    }
    if (ok) stats.restores++;else stats.restore_refused++;
    return ok;
}
float ArmorErgoFactor(uint32_t weight,int reinforced) {
    if (weight==0) return reinforced ? 1.10f : 1.15f;
    // PT-BR: Média reforçada -10% (antebraço AV3); pesada -20% nos dois perfis (braço AV3 até a mão), 12/10/2026.
    // EN: Reinforced medium -10% (forearm AV3); heavy -20% on both profiles (arm AV3 to the hand), 2026-10-12.
    if (weight==1) return reinforced ? .90f : 1;
    if (weight==2) return .80f;
    return 1;
}
int ArmorErgoApply(const ArmorOwnedRecord *r,float source,uint32_t weight) {
    return ArmorErgoApplyProfile(r,source,weight,0);
}
int ArmorErgoApplyProfile(const ArmorOwnedRecord *r,float source,uint32_t weight,int reinforced) {
    uint32_t current[4],observed[4];
    if (pending) return ArmorErgoReject(ARMOR_ERGO_PENDING);
    if (!r || r->stride!=0x3f0 || weight>2 || !read_values(r,current)) return ArmorErgoReject(ARMOR_ERGO_BAD_RECORD);
    float calculated=number(current[0]),value=number(current[1]),e=normalized(value);
    float a=1+19*e*e,b=1+0.5f*e;
    if (!isfinite(source) || source<=0 || source>1000 || !isfinite(calculated) || calculated<0 || calculated>1000
        || !isfinite(value) || value<0 || value>1000 || !isfinite(number(current[2])) || !isfinite(number(current[3]))
        || fabsf(number(current[2])-a)>0.0002f || fabsf(number(current[3])-b)>0.00002f)
        return ArmorErgoReject(ARMOR_ERGO_BAD_VALUE);
    float factor=ArmorErgoFactor(weight,reinforced);
    float adjusted=value*factor,ratio=normalized(adjusted);
    stats.record=r->record;stats.weight=weight;stats.reason=0;
    stats.before=value;stats.expected=adjusted;stats.observed=value;
    if (factor==1) {stats.neutral++;return 1;}
    owned=*r;memcpy(original,current,sizeof(original));
    written[0]=bits(calculated*factor);written[1]=bits(adjusted);
    // PT-BR: Recalcula os coeficientes consumidos pela mira; o catálogo da arma permanece original.
    // EN: Recompute the coefficients consumed by aiming; leave the weapon catalog unchanged.
    written[2]=bits(1+19*ratio*ratio);written[3]=bits(1+0.5f*ratio);
    for (unsigned i=0;i<4;i++) {
        if (written[i]==original[i]) continue;
        if (!ArmorOwnedExchange(r,offsets[i],written[i],original[i])) {
            ArmorErgoRestore();return ArmorErgoReject(ARMOR_ERGO_EXCHANGE_FAILED);
        }
        pending|=1u<<i;
    }
    stats.writes++;
    if (!read_values(r,observed) || memcmp(observed,written,sizeof(written))) {
        ArmorErgoRestore();return ArmorErgoReject(ARMOR_ERGO_READBACK_FAILED);
    }
    stats.observed=number(observed[1]);stats.verified++;return 1;
}
