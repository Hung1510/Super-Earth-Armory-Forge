#pragma once
#include "projectile_replay.h"
#include "damage_origin.h"
#define ARMOR_MELEE_PROXIMITY_LIMIT 3.0f
#define ARMOR_MELEE_IDENTIFIED_LIMIT 6.0f
enum {ARMOR_MELEE_BY_DISTANCE=1,ARMOR_MELEE_BY_ATTACKER=2};
typedef struct ArmorMeleeSample {
    ArmorReplaySample hit;
    uint32_t cause,proximity;
    float distance;
} ArmorMeleeSample;
int ArmorMeleeKnown(uint32_t kind,uint32_t element,uint32_t cause);
int ArmorMeleeExcluded(uint64_t type);
int ArmorFireNative(uint32_t element,uint64_t type);
int ArmorMeleeIdentified(uint64_t type,uint32_t cause);
int ArmorMeleeProximity(const ArmorOrigin *origin,uint32_t cause,float *distance);
int ArmorMeleeRoute(uint32_t parent,uint32_t producer);
uint32_t ArmorMeleeKeepPercent(uint32_t weight,uint32_t region,uint32_t collider,int reinforced);
uint32_t ArmorMeleeDamage(uint32_t damage,uint32_t keep_percent);
int ArmorMeleeRemember(const ArmorMeleeSample *sample,uint64_t now);
int ArmorMeleeMatch(const ArmorReplayKey *key,uint32_t cause,uint64_t now,ArmorMeleeSample *out);
void ArmorMeleeClear(void);
