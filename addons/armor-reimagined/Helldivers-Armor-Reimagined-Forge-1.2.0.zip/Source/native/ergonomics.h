#pragma once
#include <stdint.h>
#include "local_runtime.h"
typedef struct ArmorErgoStats {
    uintptr_t record;
    uint32_t weight,reason,writes,verified,neutral,restores,restore_refused,refused;
    float before,expected,observed;
    uint32_t pending;
    uint32_t protection_windows,protection_failed,locked;
} ArmorErgoStats;
enum ArmorErgoReason {
    ARMOR_ERGO_INACTIVE=1, ARMOR_ERGO_NO_AVATAR, ARMOR_ERGO_NOT_MISSION,
    ARMOR_ERGO_NO_EQUIPMENT, ARMOR_ERGO_IDENTITY_CHANGED, ARMOR_ERGO_BAD_RECORD,
    ARMOR_ERGO_BAD_VALUE, ARMOR_ERGO_PENDING, ARMOR_ERGO_EXCHANGE_FAILED,
    ARMOR_ERGO_READBACK_FAILED, ARMOR_ERGO_PROTECTION_FAILED
};
int ArmorErgoApply(const ArmorOwnedRecord *record, float source, uint32_t weight);
int ArmorErgoApplyProfile(const ArmorOwnedRecord *record,float source,uint32_t weight,int reinforced);
float ArmorErgoFactor(uint32_t weight,int reinforced);
int ArmorErgoRestore(void);
int ArmorErgoReject(uint32_t reason);
void ArmorErgoReadStats(ArmorErgoStats *out);
