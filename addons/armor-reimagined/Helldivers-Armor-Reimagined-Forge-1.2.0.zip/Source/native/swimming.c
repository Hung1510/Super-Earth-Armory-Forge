#include "swimming.h"
#include <string.h>
#include <math.h>
static ArmorSwimStats stats={.weight=UINT32_MAX};
int ArmorSwimRestore(void) {
    // PT-BR: Para a reposição; o temporizador nativo continua a partir do fôlego restante, sem bônus residual.
    // EN: Stop refilling; the native timer continues from the remaining breath without a residual bonus.
    if (stats.active) stats.restored++;
    stats.active=0;stats.field=0;return 1;
}
int ArmorSwimStep(const ArmorOwnedRecord *r,float maximum,uint32_t weight,int eligible) {
    stats.weight=weight;
    if (!eligible || weight!=0) {ArmorSwimRestore();stats.reason=1;return 1;}
    unsigned char data[28];uint32_t current,expected,observed;float value;
    if (!r || r->stride!=28 || !isfinite(maximum) || maximum<=0 || maximum>60
        || !ArmorOwnedValidate(ArmorRuntimeReadSelf,r) || !ArmorRuntimeReadSelf(r->record,data,28)) {
        ArmorSwimRestore();stats.reason=2;stats.refused++;return 0;
    }
    memcpy(&current,data+20,4);memcpy(&value,&current,4);memcpy(&expected,&maximum,4);
    if (!isfinite(value) || value<=0 || value>maximum+0.01f || data[0]>1) {
        ArmorSwimRestore();stats.reason=3;stats.refused++;return 0;
    }
    stats.field=r->record+20;stats.before=value;stats.expected=maximum;stats.observed=value;
    if (!data[0]) {ArmorSwimRestore();stats.reason=6;return 1;}
    if (current!=expected && !ArmorOwnedExchange(r,20,expected,current)) {
        ArmorSwimRestore();stats.reason=5;stats.refused++;return 0;
    }
    if (!ArmorOwnedValidate(ArmorRuntimeReadSelf,r) || !ArmorRuntimeReadSelf(r->record+20,&observed,4) || observed!=expected) {
        ArmorSwimRestore();stats.reason=5;stats.refused++;return 0;
    }
    if (current!=expected) stats.applied++;
    stats.active=1;stats.reason=0;stats.observed=maximum;return 1;
}
void ArmorSwimReadStats(ArmorSwimStats *out) {if (out) *out=stats;}
