#include "local_runtime.h"
#include <windows.h>
#include <string.h>
#include <math.h>
extern int ArmorExchangeDamage(void *,uint32_t,uint32_t);
extern int ArmorSafeCopy(void *destination,const void *source,size_t size);
int ArmorRuntimeReadSelf(uintptr_t at,void *out,size_t size) {
    return out && at>=65536 && at<UINT64_C(0x800000000000)-size && size && size<=4096
        && ArmorSafeCopy(out,(const void *)at,size);
}
static int ptr(ArmorRuntimeRead read,uintptr_t at,uintptr_t *out) {
    return read(at,out,8) && *out>=65536 && *out<UINT64_C(0x800000000000);
}
static int lookup(ArmorRuntimeRead read,uintptr_t at,uint32_t key,uint32_t *index) {
    struct {uintptr_t buckets;uint32_t capacity,empty,multiplier;} h;
    if (!read(at,&h,20) || !h.capacity || h.capacity>1048576 || (h.capacity&(h.capacity-1))) return 0;
    for (uint32_t i=0;i<h.capacity && i<4096;i++) {
        uint32_t row[2];
        if (!read(h.buckets+((key*h.multiplier+i)&(h.capacity-1))*8,row,8)) return 0;
        if (row[0]==key) {*index=row[1];return row[1]!=UINT32_MAX;}
        if (row[0]==h.empty) return 0;
    }
    return 0;
}
static uint32_t word(const unsigned char *p,unsigned off) {uint32_t v;memcpy(&v,p+off,4);return v;}
int ArmorOwnedValidate(ArmorRuntimeRead read,const ArmorOwnedRecord *r) {
    uintptr_t manager,descriptors,records,descriptor;uint32_t count;unsigned char data[24];
    return read && r && r->index<4096 && r->stride>=28 && r->stride<=4096
        && ptr(read,r->global,&manager) && manager==r->manager
        && read(manager+r->count_offset,&count,4) && count>r->index && count<=4096
        && ptr(read,manager+r->descriptors_offset,&descriptors) && descriptors==r->descriptors
        && ptr(read,manager+r->records_offset,&records) && records==r->records
        && r->record==records+(uintptr_t)r->index*r->stride
        && ptr(read,descriptors+(uintptr_t)r->index*8,&descriptor) && descriptor==r->descriptor
        && read(descriptor,data,24) && !memcmp(data,r->identity,24) && (word(data,20)&1);
}
int ArmorOwnedRefresh(ArmorRuntimeRead read,const ArmorOwnedRecord *old,ArmorOwnedRecord *out) {
    if (!read || !old || !out || !(word(old->identity,20)&1)) return 0;
    if (ArmorOwnedValidate(read,old)) {*out=*old;return 1;}
    ArmorOwnedRecord r=*old;uint32_t count,found=UINT32_MAX;
    if (!ptr(read,r.global,&r.manager) || !read(r.manager+r.count_offset,&count,4) || !count || count>256
        || !ptr(read,r.manager+r.descriptors_offset,&r.descriptors)
        || !ptr(read,r.manager+r.records_offset,&r.records)) return 0;
    // PT-BR: A compactação move a arma com o ajuste aplicado; segue a mesma identidade completa, nunca o endereço antigo.
    // EN: Compaction moves the weapon with the adjustment applied; follow its full identity, never the old address.
    for (uint32_t i=0;i<count;i++) {
        uintptr_t descriptor;unsigned char data[24];
        if (!ptr(read,r.descriptors+i*8,&descriptor) || !read(descriptor,data,24)) return 0;
        if (memcmp(data,old->identity,24)) continue;
        if (found!=UINT32_MAX) return 0;
        found=i;r.descriptor=descriptor;
    }
    if (found==UINT32_MAX) return 0;
    r.index=found;r.record=r.records+(uintptr_t)found*r.stride;
    if (!ArmorOwnedValidate(read,&r)) return 0;
    *out=r;return 1;
}
int ArmorOwnedExchange(const ArmorOwnedRecord *r,uint32_t off,uint32_t value,uint32_t expected) {
    MEMORY_BASIC_INFORMATION page;
    if (!r || off>r->stride-4 || off%4 || !ArmorOwnedValidate(ArmorRuntimeReadSelf,r)) return 0;
    uintptr_t at=r->record+off;
    // PT-BR: Instâncias locais graváveis; nunca abre páginas do catálogo compartilhado.
    // EN: Writable local instances only; never open shared catalog pages.
    if (VirtualQuery((void *)at,&page,sizeof(page))!=sizeof(page) || page.State!=MEM_COMMIT
        || page.Type!=MEM_PRIVATE || page.Protect!=PAGE_READWRITE
        || at+4>(uintptr_t)page.BaseAddress+page.RegionSize) return 0;
    return ArmorExchangeDamage((void *)at,value,expected)==1;
}
static int record(ArmorRuntimeRead read,uintptr_t game,uint32_t entity,uint32_t global,
                  uint32_t countoff,uint32_t descoff,uint32_t recoff,uint32_t stride,
                  ArmorOwnedRecord *out) {
    ArmorOwnedRecord r={.global=game+global,.count_offset=countoff,.descriptors_offset=descoff,
                        .records_offset=recoff,.stride=stride};
    uint32_t count,found=UINT32_MAX;
    if (!ptr(read,r.global,&r.manager) || !read(r.manager+countoff,&count,4) || !count || count>256
        || !ptr(read,r.manager+descoff,&r.descriptors) || !ptr(read,r.manager+recoff,&r.records)) return 0;
    for (uint32_t i=0;i<count;i++) {
        uintptr_t descriptor;unsigned char d[24];
        if (!ptr(read,r.descriptors+i*8,&descriptor) || !read(descriptor,d,24)) return 0;
        if (word(d,8)!=entity) continue;
        if (found!=UINT32_MAX || !(word(d,20)&1) || !word(d,12)) return 0;
        found=i;r.descriptor=descriptor;memcpy(r.identity,d,24);
    }
    if (found==UINT32_MAX) return 0;
    r.index=found;r.record=r.records+(uintptr_t)found*stride;
    if (!ArmorOwnedValidate(read,&r)) return 0;
    *out=r;return 1;
}
static int source(ArmorRuntimeRead read,uintptr_t game,uint64_t resource,uint32_t tableoff,
                  uint32_t slots,uint32_t stride,uint32_t field,float *out) {
    uintptr_t entities,table;uint32_t found=UINT32_MAX;
    if (!ptr(read,game+0x346bf98,&entities) || !ptr(read,entities+tableoff,&table)) return 0;
    unsigned char rows[4096],selected[16];uint32_t selected_slot=0;
    for (uint32_t begin=0;begin<slots;begin+=256) {
        uint32_t count=slots-begin<256 ? slots-begin : 256;
        if (!read(table+begin*16,rows,count*16)) return 0;
        for (uint32_t i=0;i<count;i++) {
            unsigned char *row=rows+i*16;uint64_t key;memcpy(&key,row,8);
            if (key!=resource) continue;
            uint32_t index=word(row,8);
            if (found!=UINT32_MAX || index>=slots) return 0;
            found=index;selected_slot=begin+i;memcpy(selected,row,16);
        }
    }
    uintptr_t after;
    return found!=UINT32_MAX && read(table+slots*16+(uintptr_t)found*stride+field,out,4)
        && isfinite(*out) && *out>0 && ptr(read,entities+tableoff,&after) && after==table
        && read(table+selected_slot*16,rows,16) && !memcmp(rows,selected,16);
}
int ArmorLocalPrimary(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out,float *base) {
    uintptr_t inventory,wielder,records,slots;uint32_t ii,wi,fields[12],held;
    if (!read || !game || avatar==UINT32_MAX || !out || !base
        || !ptr(read,game+0x3326738,&inventory) || !lookup(read,inventory+0x28,avatar,&ii) || ii>=4096
        || !ptr(read,inventory+0x50,&records) || !read(records+(uintptr_t)ii*0x30,fields,48)
        || fields[7]!=1 || !fields[0] || fields[0]==fields[1]
        || !ptr(read,game+0x3326420,&wielder) || !lookup(read,wielder+0x30,avatar,&wi) || wi>=4096
        || !ptr(read,wielder+0x60,&slots) || !read(slots+(uintptr_t)wi*0x1d0,&held,4)
        || held!=fields[0] || !record(read,game,held,0x3326ce0,0x20,0x48,0x58,0x3f0,out)) return 0;
    uint64_t resource;memcpy(&resource,out->identity,8);
    if (!source(read,game,resource,0xf12bd8,730,0x4d0,356,base) || *base>1000) return 0;
    uint32_t after[12],after_held,after_ii,after_wi;uintptr_t after_inventory,after_wielder,after_records,after_slots;
    return ptr(read,game+0x3326738,&after_inventory) && after_inventory==inventory
        && ptr(read,game+0x3326420,&after_wielder) && after_wielder==wielder
        && lookup(read,inventory+0x28,avatar,&after_ii) && after_ii==ii
        && lookup(read,wielder+0x30,avatar,&after_wi) && after_wi==wi
        && ptr(read,inventory+0x50,&after_records) && after_records==records
        && ptr(read,wielder+0x60,&after_slots) && after_slots==slots
        && read(records+(uintptr_t)ii*0x30,after,48) && !memcmp(after,fields,48)
        && read(slots+(uintptr_t)wi*0x1d0,&after_held,4) && after_held==held && ArmorOwnedValidate(read,out);
}
int ArmorLocalAir(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out,float *maximum) {
    if (!read || !game || avatar==UINT32_MAX || !out || !maximum
        || !record(read,game,avatar,0x3326a80,0x14,0x38,0x40,0x1c,out)) return 0;
    uint64_t resource;memcpy(&resource,out->identity,8);
    return resource==UINT64_C(0x4d1c334d294dfa97)
        && source(read,game,resource,0xf12e20,122,64,12,maximum) && *maximum<=60
        && ArmorOwnedValidate(read,out);
}
int ArmorLocalMovement(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out) {
#ifndef ARMOR_BRIDGE_TEST
    static const unsigned char getter[]={0x48,0x6b,0xc2,0x34,0xf3,0x0f,0x10,0x44,0x08,0x04,
        0xf3,0x0f,0x59,0x04,0x01,0xf3,0x0f,0x59,0x44,0x08,0x08,0xf3,0x0f,0x59,0x44,
        0x08,0x0c,0xf3,0x0f,0x59,0x44,0x08,0x10,0xc3};
    unsigned char code[sizeof(getter)];
    if (!read || !game || !read(game+0x9cccc4,code,sizeof(code)) || memcmp(code,getter,sizeof(code))) return 0;
#endif
    if (!read || !game || avatar==UINT32_MAX || !out
        || !record(read,game,avatar,0x3326cf8,0x14,0x38,0x48,0x34,out)) return 0;
    uint64_t resource;memcpy(&resource,out->identity,8);
    return resource==UINT64_C(0x4d1c334d294dfa97) && ArmorOwnedValidate(read,out);
}
