#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int (*ArmorRuntimeRead)(uintptr_t,void *,size_t);
typedef struct ArmorOwnedRecord {
    uintptr_t global,manager,descriptors,descriptor,records,record;
    uint32_t count_offset,descriptors_offset,records_offset,index,stride;
    unsigned char identity[24];
} ArmorOwnedRecord;
int ArmorOwnedValidate(ArmorRuntimeRead read,const ArmorOwnedRecord *ref);
int ArmorOwnedRefresh(ArmorRuntimeRead read,const ArmorOwnedRecord *ref,ArmorOwnedRecord *out);
int ArmorOwnedExchange(const ArmorOwnedRecord *ref,uint32_t offset,uint32_t replacement,uint32_t expected);
int ArmorLocalPrimary(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out,float *source);
int ArmorLocalAir(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out,float *maximum);
int ArmorLocalMovement(ArmorRuntimeRead read,uintptr_t game,uint32_t avatar,ArmorOwnedRecord *out);
int ArmorRuntimeReadSelf(uintptr_t at,void *out,size_t size);
