.text
.intel_syntax noprefix
.globl ArmorActorHook
.seh_proc ArmorActorHook
ArmorActorHook:
    mov rax, [rsp]
    cmp rax, [rip + ArmorBridgeInitSite]
    je .Lobserve
    cmp rax, [rip + ArmorBridgeApplySite]
    je .Lobserve
    jmp [rip + ArmorActorOriginal]
.Lobserve:
    sub rsp, 0x68
    .seh_stackalloc 0x68
    .seh_endprologue
    mov [rsp + 0x28], rax
    mov [rsp + 0x30], r14
    call [rip + ArmorActorOriginal]
    mov [rsp + 0x38], rax
    movdqu [rsp + 0x40], xmm0
    call [rip + __imp_GetLastError]
    mov [rsp + 0x50], eax
    mov rcx, [rsp + 0x28]
    mov rdx, [rsp + 0x30]
    mov r8d, [rsp + 0x38]
    call ArmorBridgeObserve
    mov ecx, [rsp + 0x50]
    call [rip + __imp_SetLastError]
    movdqu xmm0, [rsp + 0x40]
    mov rax, [rsp + 0x38]
    add rsp, 0x68
    ret
.seh_endproc

.globl ArmorLobbyPropertyCall
.seh_proc ArmorLobbyPropertyCall
ArmorLobbyPropertyCall:
    sub rsp, 0x28
    .seh_stackalloc 0x28
    .seh_endprologue
    mov rax, rcx
    mov rcx, rdx
    mov rdx, r8
    mov r8, r9
# PT-BR: Protege só a leitura síncrona de metadados; um handle removido suspende a aplicação.
# EN: Guard only the synchronous metadata read; a removed handle suspends application.
.Llobby_begin:
    call rax
    nop
.Llobby_end:
    add rsp, 0x28
    ret
.Llobby_refused:
    mov eax, 0x80004005
    add rsp, 0x28
    ret
    .seh_handler __C_specific_handler, @except
    .seh_handlerdata
    .long 1
    .rva .Llobby_begin, .Llobby_end
    .long 1
    .rva .Llobby_refused
    .text
.seh_endproc

.globl ArmorExchangeDamage
.seh_proc ArmorExchangeDamage
ArmorExchangeDamage:
    sub rsp, 0x28
    .seh_stackalloc 0x28
    .seh_endprologue
.Ldamage_begin:
    mov eax, r8d
    lock cmpxchg [rcx], edx
    sete al
    movzx eax, al
.Ldamage_end:
    add rsp, 0x28
    ret
.Ldamage_refused:
    xor eax, eax
    add rsp, 0x28
    ret
    .seh_handler __C_specific_handler, @except
    .seh_handlerdata
    .long 1
    .rva .Ldamage_begin, .Ldamage_end
    .long 1
    .rva .Ldamage_refused
    .text
.seh_endproc

.globl ArmorLateHook
.seh_proc ArmorLateHook
ArmorLateHook:
    mov rax, [rsp]
    cmp rax, [rip + ArmorBridgeLateSite]
    je .Llate_observe
    jmp [rip + ArmorLateOriginal]
.Llate_observe:
    sub rsp, 0x68
    .seh_stackalloc 0x68
    .seh_endprologue
    mov [rsp + 0x30], r14
    lea rax, [rsp + 0xd8]
    mov [rsp + 0x28], rax
    call [rip + ArmorLateOriginal]
    mov [rsp + 0x38], rax
    movdqu [rsp + 0x40], xmm0
    call [rip + __imp_GetLastError]
    mov [rsp + 0x50], eax
    mov rcx, [rsp + 0x30]
    mov rdx, [rsp + 0x28]
    call ArmorBridgeObserveLate
    mov ecx, [rsp + 0x50]
    call [rip + __imp_SetLastError]
    movdqu xmm0, [rsp + 0x40]
    mov rax, [rsp + 0x38]
    add rsp, 0x68
    ret
.seh_endproc

.globl ArmorExchangeSlot
# PT-BR: O intervalo SEH cobre a troca atômica, inclusive falhas de acesso síncronas.
# EN: The SEH range covers the atomic exchange, including synchronous access faults.
.seh_proc ArmorExchangeSlot
ArmorExchangeSlot:
    sub rsp, 0x28
    .seh_stackalloc 0x28
    .seh_endprologue
.Lexchange_begin:
    mov rax, r8
    lock cmpxchg [rcx], rdx
    sete al
    movzx eax, al
.Lexchange_end:
    add rsp, 0x28
    ret
.Lexchange_refused:
    mov eax, -1
    add rsp, 0x28
    ret
    .seh_handler __C_specific_handler, @except
    .seh_handlerdata
    .long 1
    .rva .Lexchange_begin, .Lexchange_end
    .long 1
    .rva .Lexchange_refused
    .text
.seh_endproc

.globl ArmorSafeCopy
# PT-BR: Cópia direta protegida por SEH: substitui ReadProcessMemory no próprio processo; falha de acesso devolve 0.
# EN: SEH-guarded direct copy: replaces same-process ReadProcessMemory; an access fault returns 0.
.seh_proc ArmorSafeCopy
ArmorSafeCopy:
    push rsi
    .seh_pushreg rsi
    push rdi
    .seh_pushreg rdi
    sub rsp, 0x28
    .seh_stackalloc 0x28
    .seh_endprologue
    mov rdi, rcx
    mov rsi, rdx
    mov rcx, r8
.Lcopy_begin:
    rep movsb
    nop
.Lcopy_end:
    mov eax, 1
    add rsp, 0x28
    pop rdi
    pop rsi
    ret
.Lcopy_refused:
    xor eax, eax
    add rsp, 0x28
    pop rdi
    pop rsi
    ret
    .seh_handler __C_specific_handler, @except
    .seh_handlerdata
    .long 1
    .rva .Lcopy_begin, .Lcopy_end
    .long 1
    .rva .Lcopy_refused
    .text
.seh_endproc
