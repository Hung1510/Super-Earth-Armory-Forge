#include "movement.h"
#include <windows.h>
#include <string.h>
#include <math.h>
#include "spin_lock.h"
static ArmorOwnedRecord owned;
static ArmorMovementStats stats={.reason=1};
static volatile LONG lock;
static uint32_t original,written,pending;
static float applied_factor=.90f;
static float number(uint32_t v) {float f;memcpy(&f,&v,4);return f;}
static uint32_t bits(float f) {uint32_t v;memcpy(&v,&f,4);return v;}
static int read_factor(const ArmorOwnedRecord *r,uint32_t *out) {
    return r && r->stride==0x34 && ArmorOwnedValidate(ArmorRuntimeReadSelf,r)
        && ArmorRuntimeReadSelf(r->record+4,out,4)
        && isfinite(number(*out)) && number(*out)>=0 && number(*out)<=16
        && ArmorOwnedValidate(ArmorRuntimeReadSelf,r);
}
static int restore(void) {
    if (!pending) return 1;
    ArmorOwnedRecord r;uint32_t current;
    if (!ArmorOwnedRefresh(ArmorRuntimeReadSelf,&owned,&r) || !read_factor(&r,&current)) {
        pending=0;stats.active=0;stats.refused++;stats.reason=2;return 0;
    }
    // PT-BR: Este campo é um produto de modificadores nativos. Remove só nosso fator, preservando terreno e efeitos aplicados depois.
    // EN: This field is a product of native modifiers. Remove only our factor, preserving terrain and effects applied afterward.
    uint32_t replacement=current==written ? original : bits(number(current)/applied_factor);
    if (!isfinite(number(replacement)) || number(replacement)>16
        || !ArmorOwnedExchange(&r,4,replacement,current)) {stats.reason=3;stats.refused++;return 0;}
    pending=0;stats.active=0;stats.restored++;return 1;
}
int ArmorMovementRestore(void) {
    if (!ArmorTake(&lock)) return 0;
    int result=restore();InterlockedExchange(&lock,0);return result;
}
int ArmorMovementSuspend(uint32_t reason) {
    if (!ArmorTake(&lock)) return 0;
    int result=restore();if (result) stats.reason=reason;
    InterlockedExchange(&lock,0);return result;
}
int ArmorMovementApply(const ArmorOwnedRecord *r) {
    return ArmorMovementApplyFactor(r,.90f);
}
int ArmorMovementAllowed(float factor) {
    static const float allowed[]={.90f,.95f,1.05f,1.10f,1.05f*.75f,1.10f*.75f,.85f};
    for (unsigned i=0;i<sizeof(allowed)/sizeof(allowed[0]);i++) if (factor==allowed[i]) return 1;
    return 0;
}
int ArmorMovementApplyFactor(const ArmorOwnedRecord *r,float factor) {
    // PT-BR: Fatores permitidos: pesada 0,90/0,95; leve 1,05/1,10; e esses valores com a lentidão ao levar golpe
    // (leve x0,75, média 0,85). Qualquer outro valor é recusado.
    // EN: Allowed factors: heavy 0.90/0.95; light 1.05/1.10; and those with the slow-on-hit applied
    // (light x0.75, medium 0.85). Any other value is refused.
    if (!ArmorMovementAllowed(factor)) return 0;
    if (!ArmorTake(&lock)) return 0;
    uint32_t value;int result=0;
    if (!restore()) goto done;
    if (!read_factor(r,&value)) {stats.reason=2;stats.refused++;goto done;}
    owned=*r;original=value;written=bits(number(value)*factor);applied_factor=factor;
    stats.record=r->record;memcpy(&stats.avatar,r->identity+8,4);
    stats.before=number(value);stats.expected=number(written);stats.observed=number(value);
    if (!ArmorOwnedExchange(r,4,written,value)) {stats.reason=3;stats.refused++;goto done;}
    pending=1;stats.applied++;
    uint32_t observed;
    if (!read_factor(r,&observed) || observed!=written) {restore();stats.reason=4;stats.refused++;goto done;}
    stats.observed=number(observed);stats.active=1;stats.reason=0;result=1;
done:
    InterlockedExchange(&lock,0);return result;
}
int ArmorMovementValid(uint32_t avatar) {
    if (!ArmorTake(&lock)) return 0;
    ArmorOwnedRecord r;uint32_t current;
    int result=pending && stats.active && stats.avatar==avatar
        && ArmorOwnedRefresh(ArmorRuntimeReadSelf,&owned,&r) && read_factor(&r,&current);
    InterlockedExchange(&lock,0);return result;
}
void ArmorMovementReadStats(ArmorMovementStats *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));out->reason=1;
    if (!ArmorTake(&lock)) return;
    *out=stats;out->active=!!pending && stats.active;
    InterlockedExchange(&lock,0);
}
