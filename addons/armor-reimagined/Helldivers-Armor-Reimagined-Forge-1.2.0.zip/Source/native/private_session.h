#pragma once
#include "local_runtime.h"
int ArmorSessionRefresh(ArmorRuntimeRead read,uintptr_t game);
int ArmorSessionMission(ArmorRuntimeRead read,uintptr_t game);
uint64_t ArmorSessionCurrent(void);
