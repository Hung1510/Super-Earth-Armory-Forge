#include "melee.h"
#include <windows.h>
#include <string.h>
#include "spin_lock.h"
int ArmorMeleeKnown(uint32_t kind,uint32_t element,uint32_t cause) {
    if (kind!=6 || element!=0) return 0;
    // PT-BR: IDs observados no teste exclusivamente corpo a corpo; Ability sozinho não identifica um golpe.
    // EN: IDs observed in the melee-only test; Ability alone does not identify a melee strike.
    return cause==0x11c4b1a5 || cause==0xf8ed1323 || cause==0xae3392c1 || cause==0xcae3c500
        || cause==0xe0b04680 || cause==0x71739f3f || cause==0x51ba8f74 || cause==0x5c934d9a;
}
int ArmorMeleeExcluded(uint64_t type) {
    // PT-BR: Pedido do usuário: Charger, Bile Titan e Impaler (inclusive tentáculo) mantêm dano nativo.
    // EN: User request: Charger, Bile Titan and Impaler (tentacle included) keep native damage.
    static const uint64_t excluded[]={
        UINT64_C(0x1A7FCDFF98C664B0),UINT64_C(0x0AB7B92B131C228C),UINT64_C(0x6B202392F4AB605E),
        UINT64_C(0x3AFF5FD7D5450B99),UINT64_C(0xA05BD1EC67B3AC4C),UINT64_C(0x9E2E17F2CCCCAFDD),
        UINT64_C(0xEF04CB84D097A497),UINT64_C(0xDCF8E74212FBEE3B),UINT64_C(0x672F7DA17F3BA34A)};
    for (unsigned i=0;i<sizeof(excluded)/sizeof(excluded[0]);i++) if (excluded[i]==type) return 1;
    return 0;
}
int ArmorFireNative(uint32_t element,uint64_t type) {
    // PT-BR: Fogo direto sempre com dano nativo do jogo: elemento fogo (1) ou atacante com lança-chamas (o jato também
    // gera impactos de projétil sem elemento). A redução de fogo fica só com os passivos do próprio jogo.
    // EN: Direct fire always keeps the game's native damage: fire element (1) or a flamethrower attacker (the stream
    // also produces projectile hits with no element). Fire reduction is left to the game's own passives.
    static const uint64_t flamers[]={
        UINT64_C(0x6DAB2EADF5D8B692),  // Hulk Firebomber
        UINT64_C(0x1897BDD32105D2DC),  // Hulk Scorcher MK2
        UINT64_C(0x82A87AD8D595B2BA)}; // Pyro Trooper
    if (element==1) return 1;
    for (unsigned i=0;i<sizeof(flamers)/sizeof(flamers[0]);i++) if (flamers[i]==type) return 1;
    return 0;
}
int ArmorMeleeIdentified(uint64_t type,uint32_t cause) {
    // PT-BR: Pares atacante+causa confirmados em partida (0.16.2/0.17.0, 10/10/2026), resolvidos pelo ID de rede.
    // EN: Attacker+cause pairs confirmed in play (0.16.2/0.17.0, 2026-10-10), resolved through the network ID.
    static const struct {uint64_t type;uint32_t cause;} pairs[]={
        {UINT64_C(0xC626D2BB495A202D),0xab3862b0},{UINT64_C(0xC626D2BB495A202D),0x5c934d9a},
        {UINT64_C(0xAE63E525853D7044),0xab3862b0},{UINT64_C(0x9647B00CC3A9D36F),0xab3862b0},
        {UINT64_C(0x09FE0BE51A23396C),0x51ba8f74},{UINT64_C(0xDA40BB347C7447F2),0},
        {UINT64_C(0x67DC32DCA4F02D33),0},{UINT64_C(0xA6A68D8AF177F3A1),0x71739f3f},
        {UINT64_C(0xA6A68D8AF177F3A1),0x5c934d9a},{UINT64_C(0x0002BA767DF856F3),0xe0b04680},
        {UINT64_C(0xF8131632AA867107),0},{UINT64_C(0xCCAE5264ACD591B7),0xf25abcdd},
        {UINT64_C(0xF540CA9D9D4A422E),0x6d29c458},{UINT64_C(0x137988CEA16458F7),0},
        // PT-BR: Alpha Commander (golpe 0xc34aac90 a 4,35 m, 10/10/2026); o Charger usa a mesma causa mas segue excluído pelo tipo.
        // EN: Alpha Commander (strike 0xc34aac90 at 4.35 m, 2026-10-10); the Charger shares the cause but stays excluded by type.
        {UINT64_C(0xF79CD8BB654397DF),0xc34aac90},
        // PT-BR: Iluminados: Crusher (4,79 m) e Wretch (3,14 m), golpe sem causa listada, dono igual ao causador (10/10/2026).
        // EN: Illuminate: Crusher (4.79 m) and Wretch (3.14 m), strike with no listed cause, owner equal to dealer (2026-10-10).
        {UINT64_C(0x905809A4C28D8A45),0},{UINT64_C(0xCC188F0C80505C6C),0}};
    for (unsigned i=0;i<sizeof(pairs)/sizeof(pairs[0]);i++) if (pairs[i].type==type && pairs[i].cause==cause) return 1;
    return 0;
}
int ArmorMeleeProximity(const ArmorOrigin *o,uint32_t cause,float *distance) {
    const uint32_t need=ARMOR_ORIGIN_NET_HEALTH|ARMOR_ORIGIN_NET_POSITION|ARMOR_ORIGIN_VICTIM_POSITION;
    // PT-BR: Atacante resolvido pelo ID de rede, a no máximo 3 m do personagem local e fora da exclusão.
    // EN: Attacker resolved through its network ID, within 3 m of the local character and not excluded.
    // PT-BR: Golpe de perto tem causador igual ao dono; respingo de ácido vem da bolha (causador diferente) e fica nativo.
    // EN: A close strike has dealer equal to owner; acid splash comes from the glob (different dealer) and stays native.
    if (!o || !distance || (o->flags&need)!=need || !o->net_type || !(o->net_distance>=0)
        || o->dealer!=o->owner || ArmorMeleeExcluded(o->net_type)) return 0;
    // PT-BR: Par confirmado aceita até 6 m (corpos grandes); atacante não catalogado só até 3 m.
    // EN: A confirmed pair accepts up to 6 m (large bodies); an uncatalogued attacker only up to 3 m.
    int identified=ArmorMeleeIdentified(o->net_type,cause);
    if (o->net_distance>(identified ? ARMOR_MELEE_IDENTIFIED_LIMIT : ARMOR_MELEE_PROXIMITY_LIMIT)) return 0;
    *distance=o->net_distance;return identified ? ARMOR_MELEE_BY_ATTACKER : ARMOR_MELEE_BY_DISTANCE;
}
int ArmorMeleeRoute(uint32_t parent,uint32_t producer) {
    return parent==0x12a2cf7 && (producer==0x7d247e || producer==0x7d2e3c);
}
uint32_t ArmorMeleeKeepPercent(uint32_t weight,uint32_t region,uint32_t collider,int reinforced) {
    if (weight>2) return 100;
    // PT-BR: Todos os capacetes contam como proteção média: cabeça mantém 80% do golpe em qualquer armadura.
    // EN: Every helmet counts as medium protection: the head keeps 80% of the strike with any armor.
    if (region==0x8c5570c9) return 80;
    // PT-BR: O corpo a corpo usa redução percentual regional; não reaplica a matemática de AP dos tiros.
    // EN: Melee uses regional percentage reduction; it does not reapply projectile AP math.
    if (region==0xaa1db0b0) {
        if (weight==0) return 85;
        if (weight==1) return collider==0x37ef0820 ? (reinforced ? 75 : 80) : (reinforced ? 80 : 85);
        return reinforced ? 65 : 75;
    }
    if (region==0x1880288e || region==0xb6f2baf5 || region==0x64a3fa1d || region==0x87b05ff4) {
        if (weight==0) return reinforced ? 90 : 100;
        if (weight==1) return reinforced ? 80 : 85;
        return reinforced ? 75 : 80;
    }
    return 100;
}
uint32_t ArmorMeleeDamage(uint32_t damage,uint32_t keep_percent) {
    return keep_percent>100 ? damage : (uint32_t)((uint64_t)damage*keep_percent/100);
}
static struct {ArmorMeleeSample sample;uint64_t time;int used;} pending[128];
static volatile LONG lock;
static unsigned next;
int ArmorMeleeRemember(const ArmorMeleeSample *sample,uint64_t now) {
    if (!sample || (!ArmorMeleeKnown(6,sample->hit.key.words[1],sample->cause)
            && !(sample->proximity && sample->hit.key.words[1]==0))
        || !ArmorTake(&lock)) return 0;
    pending[next].sample=*sample;pending[next].time=now;pending[next].used=1;next=(next+1)%128;
    InterlockedExchange(&lock,0);return 1;
}
int ArmorMeleeMatch(const ArmorReplayKey *key,uint32_t cause,uint64_t now,ArmorMeleeSample *out) {
    if (!key || !out || !ArmorTake(&lock)) return -1;
    unsigned matches=0,selected=0;
    for (unsigned i=0;i<128;i++) if (pending[i].used) {
        if (now<pending[i].time || now-pending[i].time>1000) pending[i].used=0;
        else if (pending[i].sample.cause==cause && !memcmp(key,&pending[i].sample.hit.key,sizeof(*key))) {
            ++matches;selected=i;
        }
    }
    // PT-BR: Consome correspondências ambíguas sem reduzir um evento que não pôde ser identificado.
    // EN: Consume ambiguous matches without reducing an event that could not be identified.
    if (matches>1) {
        for (unsigned i=0;i<128;i++) if (pending[i].used && pending[i].sample.cause==cause
            && !memcmp(key,&pending[i].sample.hit.key,sizeof(*key))) pending[i].used=0;
    } else if (matches==1) {*out=pending[selected].sample;pending[selected].used=0;}
    InterlockedExchange(&lock,0);return matches==1 ? 1 : matches>1 ? -2 : 0;
}
void ArmorMeleeClear(void) {
    if (!ArmorTake(&lock)) return;
    memset(pending,0,sizeof(pending));next=0;InterlockedExchange(&lock,0);
}
