#pragma once
#include <windows.h>
// Bounded spin lock: 0 = free, 1 = taken. Release with InterlockedExchange(&lock,0).
// Returns 1 when taken; gives up (0) after a short spin so a game thread is never blocked for long.
static inline int ArmorTake(volatile LONG *lock) {
    for (unsigned i = 0; i < 4096; ++i) {
        if (InterlockedCompareExchange(lock, 1, 0) == 0) return 1;
        YieldProcessor();
    }
    return 0;
}
