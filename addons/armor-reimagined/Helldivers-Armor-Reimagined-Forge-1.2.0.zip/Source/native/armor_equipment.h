#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int (*ArmorEquipmentReader)(uintptr_t, void *, size_t);
typedef struct ArmorEquipmentCache {
    uintptr_t catalog, array, kit;
    uint32_t count, id;
} ArmorEquipmentCache;
typedef struct ArmorEquipment {
    uint32_t id, weight;
} ArmorEquipment;
int ArmorEquipmentRead(uintptr_t base, ArmorEquipmentReader read,
                       ArmorEquipmentCache *cache, ArmorEquipment *out);
