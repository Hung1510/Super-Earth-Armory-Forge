#include "damage_origin.h"
#include <windows.h>
#include <string.h>
#include <math.h>
#include "spin_lock.h"
static uint32_t u32(const unsigned char *p,unsigned o) {uint32_t v;memcpy(&v,p+o,4);return v;}
static int pointer(ArmorSourceReader read,uintptr_t at,uintptr_t *out) {
    return read(at,out,8) && *out>=65536 && *out<UINT64_C(0x800000000000);
}
int ArmorSourceHealth(uintptr_t game,ArmorSourceReader read,uint32_t entity,uint64_t *type,uint32_t *unit) {
    if (!game || !read || !type || !unit || !entity || entity==UINT32_MAX) return 0;
    uintptr_t manager,buckets,descriptors,descriptor,after;
    unsigned char header[20],again[20],data[24],check[24];
    uint32_t live;
    // PT-BR: Mesmo gerenciador de vida já usado para o avatar local; o tipo do descritor é a chave do catálogo.
    // EN: Same health manager already used for the local avatar; the descriptor type is the catalog key.
    if (!pointer(read,game+0x3326688,&manager) || !read(manager+0x1020,&live,4) || !live || live>4096
        || !read(manager+0x1030,header,sizeof(header))) return 0;
    memcpy(&buckets,header,8);
    uint32_t capacity=u32(header,8),empty=u32(header,12),multiplier=u32(header,16);
    if (buckets<65536 || buckets>=UINT64_C(0x800000000000) || !capacity || capacity>65536
        || (capacity&(capacity-1))) return 0;
    uint32_t start=entity*multiplier;
    for (uint32_t probe=0;probe<capacity && probe<1024;probe++) {
        unsigned char entry[8];
        if (!read(buckets+((start+probe)&(capacity-1))*8,entry,8)) return 0;
        uint32_t key=u32(entry,0),index=u32(entry,4);
        if (key==entity) {
            if (index>=live || !pointer(read,manager+0x1048,&descriptors)
                || !pointer(read,descriptors+(uintptr_t)index*8,&descriptor)
                || !read(descriptor,data,sizeof(data)) || u32(data,8)!=entity
                || !read(descriptor,check,sizeof(check)) || memcmp(check,data,sizeof(data))
                || !read(manager+0x1030,again,sizeof(again)) || memcmp(again,header,sizeof(header))
                || !pointer(read,game+0x3326688,&after) || after!=manager) return 0;
            uint64_t result;memcpy(&result,data,8);
            if (!result) return 0;
            *type=result;*unit=u32(data,12);return 1;
        }
        if (key==empty) return 0;
    }
    return 0;
}
int ArmorSourceUnitPosition(uintptr_t exe,ArmorSourceReader read,uint32_t unit,float out[3]) {
    static const unsigned char accessor[]={0x48,0x8d,0x41,0x60,0xc3};
    if (!exe || !read || !out || !unit || unit==UINT32_MAX) return 0;
    uint32_t index=unit&0x3fffff,count,id;
    unsigned char generation;
    uintptr_t registry,generations,objects,object,vtable,method,poses;
    unsigned char code[sizeof(accessor)],after[sizeof(accessor)];
    // PT-BR: Registro de unidades do executável; geração de 8 bits recusa IDs reciclados.
    // EN: Executable unit registry; the 8-bit generation refuses recycled IDs.
    if (!pointer(read,exe+0x1a100f0,&registry) || !read(registry+0x98,&count,4) || index>=count
        || !pointer(read,registry+0xa0,&generations) || !read(generations+index,&generation,1)
        || generation!=(unsigned char)(unit>>22) || !pointer(read,registry+0x88,&objects)
        || !pointer(read,objects+(uintptr_t)index*8,&object) || !read(object+8,&id,4) || id!=unit
        || !pointer(read,object,&vtable) || !read(vtable+0xe8,&method,8) || method!=exe+0x2bd870
        || !read(method,code,sizeof(code)) || memcmp(code,accessor,sizeof(code))
        || !pointer(read,object+0x60+0x28,&poses)) return 0;
    float position[3];
    if (!read(poses+0x30,position,sizeof(position))) return 0;
    for (unsigned i=0;i<3;i++) if (!isfinite(position[i]) || fabsf(position[i])>100000) return 0;
    if (!read(method,after,sizeof(after)) || memcmp(after,accessor,sizeof(after))
        || !read(generations+index,&generation,1) || generation!=(unsigned char)(unit>>22)) return 0;
    memcpy(out,position,sizeof(position));return 1;
}
uint32_t ArmorEntityComplete(uintptr_t exe,ArmorSourceReader read,uint32_t id) {
    uintptr_t manager,generations;uint32_t size;unsigned char generation;
    if (!exe || !read || !id || id>=0x400000) return id;
    // PT-BR: Gerenciador de entidades do executável: geração de 8 bits por índice, incrementada ao destruir.
    // EN: Executable entity manager: 8-bit generation per index, incremented on destruction.
    if (!pointer(read,exe+0x1b135b8,&manager) || !read(manager+0x80,&size,4) || id>=size
        || !pointer(read,manager+0x88,&generations) || !read(generations+id,&generation,1)) return id;
    return id|((uint32_t)generation<<22);
}
uint32_t ArmorEntityFromNetwork(uintptr_t game,ArmorSourceReader read,uint32_t network) {
    uintptr_t manager,buckets;unsigned char header[20];uint32_t entity;
    if (!game || !read || !network || network==0x7fff || network==UINT32_MAX) return 0;
    // PT-BR: Mapa ID de rede -> entidade, o mesmo usado para o avatar local (+0xf22ec8, entidade em +0xf32f20).
    // EN: Network ID -> entity map, the same used for the local avatar (+0xf22ec8, entity at +0xf32f20).
    if (!pointer(read,game+0x346bf98,&manager) || !read(manager+0xf22ec8,header,sizeof(header))) return 0;
    memcpy(&buckets,header,8);
    uint32_t capacity=u32(header,8),empty=u32(header,12),multiplier=u32(header,16),start=network*multiplier;
    if (buckets<65536 || buckets>=UINT64_C(0x800000000000) || !capacity || capacity>1048576 || (capacity&(capacity-1))) return 0;
    for (uint32_t probe=0;probe<capacity && probe<1024;probe++) {
        unsigned char entry[8];
        if (!read(buckets+((start+probe)&(capacity-1))*8,entry,8)) return 0;
        uint32_t key=u32(entry,0),index=u32(entry,4);
        if (key==network) {
            if (index>=1048576 || !read(manager+0xf32f20+(uintptr_t)index*24,&entity,4)) return 0;
            return entity;
        }
        if (key==empty) return 0;
    }
    return 0;
}
int ArmorHitReach(const unsigned char *hit,float *reach) {
    float a[3],b[3];
    if (!hit || !reach) return 0;
    // PT-BR: Dois pontos gravados no próprio golpe (+0x34 e +0x40); ~1 m nas capturas reais de corpo a corpo.
    // EN: Two points recorded in the hit itself (+0x34 and +0x40); ~1 m in real melee captures.
    memcpy(a,hit+0x34,12);memcpy(b,hit+0x40,12);
    for (unsigned i=0;i<3;i++) if (!isfinite(a[i]) || !isfinite(b[i]) || fabsf(a[i])>100000 || fabsf(b[i])>100000) return 0;
    float x=a[0]-b[0],y=a[1]-b[1],z=a[2]-b[2];
    *reach=sqrtf(x*x+y*y+z*z);
    return 1;
}
void ArmorOriginResolve(uintptr_t game,uintptr_t exe,ArmorSourceReader read,ArmorOrigin *o,int full) {
    if (!o) return;
    // PT-BR: O ID do causador é um ID de rede (confirmado em partida); este é o caminho usado pela proteção.
    // EN: The dealer ID is a network ID (confirmed in play); this is the path used by protection.
    o->net_entity=ArmorEntityFromNetwork(game,read,o->dealer);
    int named=o->net_entity && ArmorSourceHealth(game,read,o->net_entity,&o->net_type,&o->net_unit);
    // PT-BR: Num tiro o causador é a bala (sem vida/nome); o atirador é o dono. Tenta o dono quando o causador não resolve.
    // A regra de proximidade do corpo a corpo continua exigindo causador igual ao dono, então não muda.
    // EN: On a shot the dealer is the bullet (no health/name); the shooter is the owner. Try the owner when the dealer fails.
    // The melee proximity rule still requires dealer equal to owner, so it does not change.
    if (!named && o->owner!=o->dealer) {
        o->net_entity=ArmorEntityFromNetwork(game,read,o->owner);
        named=o->net_entity && ArmorSourceHealth(game,read,o->net_entity,&o->net_type,&o->net_unit);
    }
    if (named) {
        o->flags|=ARMOR_ORIGIN_NET_HEALTH;
        if (ArmorSourceUnitPosition(exe,read,o->net_unit,o->net_position)) o->flags|=ARMOR_ORIGIN_NET_POSITION;
    }
    uint64_t victim_type;
    if (ArmorSourceHealth(game,read,o->victim,&victim_type,&o->victim_unit)
        && ArmorSourceUnitPosition(exe,read,o->victim_unit,o->victim_position)) o->flags|=ARMOR_ORIGIN_VICTIM_POSITION;
    if (o->flags&ARMOR_ORIGIN_NET_POSITION && o->flags&ARMOR_ORIGIN_VICTIM_POSITION) {
        float x=o->net_position[0]-o->victim_position[0],y=o->net_position[1]-o->victim_position[1];
        float z=o->net_position[2]-o->victim_position[2];
        o->net_distance=sqrtf(x*x+y*y+z*z);
    }
    // PT-BR: Leituras de pesquisa (ID de entidade, geração, posição direta) só com diagnóstico ligado.
    // EN: Research reads (entity ID, generation, direct position) only with diagnostics enabled.
    if (!full) return;
    uint32_t ignored;
    // PT-BR: O evento pode trazer só o índice (22 bits); completa com a geração atual do motor e tenta de novo.
    // EN: The event may carry only the 22-bit index; complete it with the engine's current generation and retry.
    uint32_t dealer=o->dealer,owner=o->owner;
    if (!ArmorSourceHealth(game,read,dealer,&o->dealer_health_type,&o->dealer_unit)) {
        uint32_t full=ArmorEntityComplete(exe,read,dealer);
        if (full!=dealer && ArmorSourceHealth(game,read,full,&o->dealer_health_type,&o->dealer_unit)) {
            dealer=full;o->flags|=ARMOR_ORIGIN_DEALER_GENERATION|ARMOR_ORIGIN_DEALER_HEALTH;
        }
    } else o->flags|=ARMOR_ORIGIN_DEALER_HEALTH;
    o->reserved=dealer;
    if (ArmorSourceType(game,read,dealer,&o->dealer_type)) o->flags|=ARMOR_ORIGIN_DEALER_ENTITY;
    if (o->owner==o->dealer) {
        o->owner_type=o->dealer_type;o->owner_health_type=o->dealer_health_type;
        o->flags|=(o->flags&ARMOR_ORIGIN_DEALER_ENTITY ? ARMOR_ORIGIN_OWNER_ENTITY : 0)
            |(o->flags&ARMOR_ORIGIN_DEALER_HEALTH ? ARMOR_ORIGIN_OWNER_HEALTH : 0)
            |(o->flags&ARMOR_ORIGIN_DEALER_GENERATION ? ARMOR_ORIGIN_OWNER_GENERATION : 0);
    } else {
        if (!ArmorSourceHealth(game,read,owner,&o->owner_health_type,&ignored)) {
            uint32_t full=ArmorEntityComplete(exe,read,owner);
            if (full!=owner && ArmorSourceHealth(game,read,full,&o->owner_health_type,&ignored)) {
                owner=full;o->flags|=ARMOR_ORIGIN_OWNER_GENERATION|ARMOR_ORIGIN_OWNER_HEALTH;
            }
        } else o->flags|=ARMOR_ORIGIN_OWNER_HEALTH;
        if (ArmorSourceType(game,read,owner,&o->owner_type)) o->flags|=ARMOR_ORIGIN_OWNER_ENTITY;
    }
    if (o->flags&ARMOR_ORIGIN_DEALER_HEALTH
        && ArmorSourceUnitPosition(exe,read,o->dealer_unit,o->dealer_position)) o->flags|=ARMOR_ORIGIN_DEALER_POSITION;
    if ((o->flags&(ARMOR_ORIGIN_DEALER_POSITION|ARMOR_ORIGIN_VICTIM_POSITION))
        ==(ARMOR_ORIGIN_DEALER_POSITION|ARMOR_ORIGIN_VICTIM_POSITION)) {
        float x=o->dealer_position[0]-o->victim_position[0],y=o->dealer_position[1]-o->victim_position[1];
        float z=o->dealer_position[2]-o->victim_position[2];
        o->distance=sqrtf(x*x+y*y+z*z);
    }
}
static struct {ArmorReplayKey key;ArmorOrigin origin;uint64_t time;int used;} links[64];
static volatile LONG link_lock;
static unsigned link_next;
int ArmorOriginRemember(const ArmorReplayKey *key,const ArmorOrigin *origin,uint64_t now) {
    if (!key || !origin || !ArmorTake(&link_lock)) return 0;
    links[link_next].key=*key;links[link_next].origin=*origin;links[link_next].time=now;links[link_next].used=1;
    link_next=(link_next+1)%64;InterlockedExchange(&link_lock,0);return 1;
}
int ArmorOriginTake(const ArmorReplayKey *key,uint64_t now,ArmorOrigin *out) {
    if (!key || !out || !ArmorTake(&link_lock)) return -1;
    unsigned matches=0,selected=0;
    for (unsigned i=0;i<64;i++) if (links[i].used) {
        if (now<links[i].time || now-links[i].time>1000) links[i].used=0;
        else if (!memcmp(key,&links[i].key,sizeof(*key))) {++matches;selected=i;}
    }
    // PT-BR: Ligação só com uma correspondência exata; ambiguidade é consumida e informada, nunca escolhida.
    // EN: Link only on a single exact match; ambiguity is consumed and reported, never guessed.
    if (matches==1) {*out=links[selected].origin;links[selected].used=0;}
    else if (matches>1) for (unsigned i=0;i<64;i++)
        if (links[i].used && !memcmp(key,&links[i].key,sizeof(*key))) links[i].used=0;
    InterlockedExchange(&link_lock,0);
    return matches==1 ? 1 : matches>1 ? -2 : 0;
}
void ArmorOriginClear(void) {
    if (!ArmorTake(&link_lock)) return;
    memset(links,0,sizeof(links));link_next=0;InterlockedExchange(&link_lock,0);
}
uint32_t ArmorCauseRegionBit(uint32_t region) {
    static const uint32_t regions[]={0xaa1db0b0,0x8c5570c9,0x1880288e,0xb6f2baf5,0x64a3fa1d,0x87b05ff4};
    if (!region) return 0;
    for (unsigned i=0;i<6;i++) if (regions[i]==region) return 1u<<i;
    return 64;
}
static ArmorCauseStats causes[128];
static volatile LONG cause_lock,cause_version,cause_overflow;
static unsigned cause_count;
int ArmorCauseRecord(const ArmorOrigin *o,uint32_t element,uint32_t damage,uint32_t known,uint32_t reduced) {
    if (!o || !ArmorTake(&cause_lock)) return 0;
    uint64_t type=o->flags&ARMOR_ORIGIN_DEALER_HEALTH ? o->dealer_health_type
        : o->flags&ARMOR_ORIGIN_OWNER_HEALTH ? o->owner_health_type : 0;
    ArmorCauseStats *row=NULL;
    for (unsigned i=0;i<cause_count;i++) {
        ArmorCauseStats *c=&causes[i];
        if (c->kind==o->kind && c->element==element && c->cause==o->cause && c->producer==o->producer && c->dealer_type==type) {row=c;break;}
    }
    if (!row) {
        if (cause_count==128) {InterlockedIncrement(&cause_overflow);InterlockedExchange(&cause_lock,0);return 0;}
        row=&causes[cause_count++];memset(row,0,sizeof(*row));
        row->kind=o->kind;row->element=element;row->cause=o->cause;row->producer=o->producer;row->dealer_type=type;
        row->damage_min=UINT32_MAX;
    }
    ++row->count;row->damage_sum+=damage;
    if (damage<row->damage_min) row->damage_min=damage;
    if (damage>row->damage_max) row->damage_max=damage;
    if (o->flags&ARMOR_ORIGIN_LINKED) ++row->linked;
    if (known) ++row->known;
    if (reduced) ++row->reduced;
    row->regions|=ArmorCauseRegionBit(o->region);
    if (o->flags&ARMOR_ORIGIN_DEALER_POSITION && o->flags&ARMOR_ORIGIN_VICTIM_POSITION) {
        if (!row->distance_count || o->distance<row->distance_min) row->distance_min=o->distance;
        if (!row->distance_count || o->distance>row->distance_max) row->distance_max=o->distance;
        row->distance_sum+=o->distance;++row->distance_count;
    }
    if (o->flags&ARMOR_ORIGIN_REACH) {
        if (!row->reach_count || o->reach<row->reach_min) row->reach_min=o->reach;
        if (!row->reach_count || o->reach>row->reach_max) row->reach_max=o->reach;
        row->reach_sum+=o->reach;++row->reach_count;
    }
    if (o->flags&ARMOR_ORIGIN_NET_HEALTH) {
        if (!row->net_count) row->net_type=o->net_type;
        ++row->net_count;
    }
    InterlockedIncrement(&cause_version);InterlockedExchange(&cause_lock,0);return 1;
}
int ArmorCauseRead(uint32_t index,ArmorCauseStats *out) {
    if (!out || !ArmorTake(&cause_lock)) return 0;
    int found=index<cause_count;
    if (found) *out=causes[index];
    InterlockedExchange(&cause_lock,0);return found;
}
uint32_t ArmorCauseVersion(void) {return (uint32_t)InterlockedCompareExchange(&cause_version,0,0);}
uint32_t ArmorCauseOverflow(void) {return (uint32_t)InterlockedCompareExchange(&cause_overflow,0,0);}
void ArmorCauseClear(void) {
    if (!ArmorTake(&cause_lock)) return;
    memset(causes,0,sizeof(causes));cause_count=0;InterlockedIncrement(&cause_version);
    InterlockedExchange(&cause_lock,0);
}
void ArmorHitGaps(const unsigned char *hit,ArmorOrigin *o) {
    float a[3],b[3];
    if (!hit || !o) return;
    // PT-BR: Distância dos pontos do golpe até as posições lidas; revela qual posição está fora do lugar.
    // EN: Distance from the hit points to the read positions; reveals which position is off.
    memcpy(a,hit+0x34,12);memcpy(b,hit+0x40,12);
    for (unsigned i=0;i<3;i++) if (!isfinite(a[i]) || !isfinite(b[i])) return;
    if (o->flags&ARMOR_ORIGIN_VICTIM_POSITION) {
        float x=b[0]-o->victim_position[0],y=b[1]-o->victim_position[1],z=b[2]-o->victim_position[2];
        o->hit_to_victim=sqrtf(x*x+y*y+z*z);
    }
    if (o->flags&ARMOR_ORIGIN_DEALER_POSITION) {
        float x=a[0]-o->dealer_position[0],y=a[1]-o->dealer_position[1],z=a[2]-o->dealer_position[2];
        o->hit_to_dealer=sqrtf(x*x+y*y+z*z);
    }
}
