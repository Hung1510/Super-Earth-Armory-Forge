# Validação da 0.17.0

## Base em partida (0.16.2, 10/10/2026, Autômatos)

O ID do causador no evento é um **ID de rede**: resolvido pelo mapa de rede (`+0xf22ec8` → entidade `+0xf32f20`) todos os golpes físicos deram o inimigo relatado a 1,0–2,0 m — Marauder (`0xe0b04680`, soco dos comuns), Berserker (`0x71739f3f`), Rocket Devastator (`0xab3862b0`), Scout Strider (causa zero). Lido como ID de entidade dava inimigos errados a centenas de metros (ex.: Fabricator MK4 a 428 m; metralhadora fixa via rede a 24 m). Posição do personagem local confirmada (ponto do golpe a ~1,2 m). O "alcance do golpe" (+0x34/+0x40) mede 0–0,7 m e é 0 em tiros: não serve como critério.

## Regra nova

Além das 8 causas listadas, golpe físico (tipo 6, elemento 0, construtor `0x12a2cf7` e produtor `0x7d247e`/`0x7d2e3c`) recebe a redução regional quando o atacante via ID de rede tem descritor de vida, posição legível e está a ≤ 3 m. Excluídos: Charger, Rupture/Spore Charger, Charger Behemoth (MK1/MK2), Bile Titan (2), Impaler e tentáculo do Impaler. Mesma ligação única de 13 palavras, identidade/equipamento/época e escrita de 4 bytes; a escrita aceita causa fora da lista somente com proximidade e elemento 0.

## Verificação

Suítes nativa e LuaJIT/DLL aprovadas: proximidade no limite (3,00 aceito, 3,01 recusado), NaN, posição/vida ausentes, tipos excluídos, memória de golpe com/sem proximidade, escrita recusada sem proximidade ou com elemento não físico. Capturas reais sem dados de rede continuam sem redução para causas fora da lista.

## Em partida

Conferir `reduções por distância` no log com soco do Devastador/escudada/espada do MG Raider e golpes de Iluminados; confirmar que plasma do Overseer e tiros continuam originais.
