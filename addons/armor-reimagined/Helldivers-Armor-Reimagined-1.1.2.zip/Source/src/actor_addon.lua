-- HD2-Addon: mods/lobao/armor_probe
if rawget(_G,'LobaoArmorBridgeInstalled') then return end
local loader = rawget(_G,'CowboyBingusModLoader')
local log
if loader and type(loader.open_log) == 'function' then
    pcall(function() log = loader.open_log('HelldiversArmorBridge.log') end)
end
-- PT-BR: Cada linha vai para o buffer; o disco é gravado uma vez por quadro (flush_log), não a cada linha. Com o
-- diagnóstico ligado o fim da missão gera dezenas de linhas no mesmo quadro, e gravar uma a uma travava o quadro.
-- EN: Each line goes to the buffer; the disk is written once per frame (flush_log), not on every line. With diagnostics
-- on, the end of a mission writes dozens of lines in one frame, and writing them one by one stalled the frame.
local log_dirty=false
local function note(s)
    if log then pcall(function() log:write(os.date('[%H:%M:%S] ')..s..'\n') end);log_dirty=true end
end
local function flush_log()
    if log and log_dirty then log_dirty=false;pcall(function() log:flush() end) end
end
if rawget(_G,'LobaoArmorMvpInstalled') or rawget(_G,'LobaoArmorProbeInstalled') then
    note('Versão anterior carregada; reinicie com somente o pacote 1.1.2.')
    return
end
local previous = rawget(_G,'update')
local previous_shutdown=rawget(_G,'shutdown')
if type(previous) ~= 'function' then note('Callback de atualização ausente'); return end
local ok, api = pcall(HAPBridge.new,HAP_NATIVE_BYTES,'actor')
if not ok then note('Carregamento recusado: '..tostring(api)); return end
_G.LobaoArmorBridgeInstalled = api
local language_option = 'lobao.armor_probe.language'
local feedback_option = 'lobao.armor_probe.feedback'
local wanted_feedback,last_feedback=true,nil
local angled_option = 'lobao.armor_probe.angled_plates'
local wanted_angled,last_angled=false,nil
local gaps_option = 'lobao.armor_probe.arm_gaps'
local wanted_gaps,last_gaps=true,nil
local profiles=HAPProfiles.new(api,note)
local presentation=HAPPresentation.new(api,note,profiles)
local alerts=HAPAlerts.new(api,note,presentation)
local feedback=HAPFeedback.new(api,note,presentation)
local wanted_alerts=false
local now_feedback_ok=true
local last_screen=nil
local last_record=nil
local last_fire=0
local last_burn=0
-- PT-BR: Estado da pesquisa em uma tabela só (limite de 60 upvalues do LuaJIT).
-- EN: Research state in a single table (LuaJIT 60-upvalue limit).
local research={status='',flush=flush_log}
-- PT-BR: Explicação de cada código de instalação: o que foi checado, causa provável e o que fazer. Vai para o log para que
-- um relato de jogador já traga a pista. Proteções de página no formato do Windows (VirtualQuery).
-- EN: Explanation of each install code: what was checked, likely cause and what to do. Goes to the log so a player's report
-- already carries the clue. Page protections in Windows format (VirtualQuery).
local PAGE_NAMES={[0x01]='sem acesso',[0x02]='somente leitura',[0x04]='leitura e escrita',[0x08]='cópia-ao-escrever',
    [0x10]='execução',[0x20]='execução e leitura',[0x40]='execução, leitura e escrita',[0x80]='execução e cópia-ao-escrever'}
local INSTALL_CODES={
    [21]={'a versão do executável ou do game.dll não é a esperada','o jogo foi atualizado','aguardar a atualização do mod'},
    [22]={'o trecho do jogo onde o dano é calculado mudou','o jogo foi atualizado','aguardar a atualização do mod'},
    [23]={'não foi possível ler a tabela de funções do dano','o jogo foi atualizado ou a memória está protegida por outro programa','mandar o log'},
    [24]={'a função de dano não aponta para o código do jogo','outro mod ou programa (overlay, injetor) já desviou essa função, ou o jogo foi atualizado','testar só com o Bingus Shared Loader e mandar o log'},
    [25]={'o Windows não deixou fixar a DLL do mod na memória','bloqueio do sistema ou antivírus','mandar o log'},
    [41]={'o ponteiro do gancho de tiros está vazio, desalinhado ou ilegível','o jogo ainda não terminou de iniciar ou foi atualizado','reiniciar o jogo; se repetir, mandar o log'},
    [42]={'a página de memória do gancho de tiros não está numa proteção gravável aceita','o Windows ou outro programa deixou a página com outra proteção','mandar a linha com a proteção para o autor'},
    [43]={'o ponteiro do gancho de tiros já foi trocado por outro mod','outro mod faz gancho na mesma função','testar sem os outros mods e mandar a lista'},
    [44]={'a troca do ponteiro de tiros falhou porque o valor mudou no mesmo instante','outro mod ou thread mexeu ao mesmo tempo','reiniciar o jogo'},
    [45]={'o Windows recusou escrever no ponteiro de tiros','página protegida ou antivírus','mandar o log'},
    [46]={'o trecho do gancho de tiros mudou','o jogo foi atualizado','aguardar a atualização do mod'},
    [47]={'a tabela do gancho de tiros não aponta para o código do jogo','outro mod ou overlay já desviou essa função, ou o jogo foi atualizado','testar só com o Bingus Shared Loader e mandar o log'},
    [51]={'trechos do cálculo de penetração mudaram','o jogo foi atualizado','aguardar a atualização do mod'},
    [52]={'o trecho que lê o equipamento mudou','o jogo foi atualizado','aguardar a atualização do mod'},
    [61]={'trechos de movimento, ergonomia ou vida mudaram','o jogo foi atualizado','aguardar a atualização do mod'},
    [11]={'o ponteiro do gancho de dano está vazio ou desalinhado','o jogo ainda não terminou de iniciar ou foi atualizado','reiniciar o jogo; se repetir, mandar o log'},
    [12]={'o Windows não informou a página do gancho de dano','bloqueio do sistema','mandar o log'},
    [13]={'a página de memória do gancho de dano não está numa proteção gravável aceita','o Windows ou outro programa deixou a página com outra proteção','mandar a linha com a proteção para o autor'},
    [14]={'o ponteiro do gancho de dano já foi trocado por outro mod','outro mod faz gancho na mesma função','testar sem os outros mods e mandar a lista'}}
function research.describe_install(code,protect,state)
    local info=INSTALL_CODES[code]
    local page=''
    if protect and protect~=0 then
        local base=PAGE_NAMES[protect%256] or 'desconhecida'
        local extras={}
        if math.floor(protect/256)%2==1 then extras[#extras+1]='guarda' end
        if math.floor(protect/512)%2==1 then extras[#extras+1]='sem cache' end
        page=string.format(' Página encontrada: proteção=0x%x (%s%s); estado=0x%x (%s).',protect,base,
            #extras>0 and ', '..table.concat(extras,', ') or '',state or 0,state==0x1000 and 'ativa' or state==0x2000 and 'reservada' or 'livre/desconhecido')
    end
    if not info then return string.format('Instalação recusada; código %s. Código sem descrição; mandar o log.%s',tostring(code),page) end
    return string.format('Instalação recusada; código %d. O que foi checado: %s. Causa provável: %s. O que fazer: %s.%s',
        code,info[1],info[2],info[3],page)
end
-- PT-BR: Erro inesperado: mensagem + pilha de chamadas resumida (até 8 linhas), só com arquivo e linha, sem as pastas.
-- EN: Unexpected error: message + short call stack (up to 8 lines), with file and line only, no folders.
function research.trace(message)
    local text=tostring(message)
    if text:find('^Instalação recusada') then return text end
    local stack=debug and debug.traceback and debug.traceback('',2) or ''
    local lines={}
    for line in stack:gmatch('[^\n]+') do
        line=line:gsub('^%s+','')
        if line~='' and line~='stack traceback:' and #lines<8 then lines[#lines+1]=line end
    end
    local full=text..(#lines>0 and ' | pilha: '..table.concat(lines,' <- ') or '')
    full=full:gsub('%[string "[^"]*"%]','armor_probe')
    return (full:gsub('[%w_%-%.]*[/\\]([%w_%-]+%.lua:%d+:?)','%1'))
end
local status_names={[2]='Bleed',[5]='Fire',[6]='Fire_Panic',[8]='Slowed',[9]='Rooted',[35]='Electric',
    [37]='Stun Small',[38]='Stun Medium',[39]='Stun Large',[40]='Stun Massive',[41]='Stun Illuminate',[42]='Gas',[43]='Gas',
    [44]='Gas_Confusion',[45]='Gas_Confusion',[67]='FlamerSlowed'}
-- PT-BR: Com o diagnóstico ligado, a cada quadro: um registro por impacto (tiro, corpo a corpo, fogo direto) com atacante,
-- parte, AP, dano antes/depois e sorteio de fresta, e a troca de status do personagem (sem esperar 1 s).
-- EN: With diagnostics on, every frame: one record per hit (shot, melee, direct fire) with attacker, part, AP, damage
-- before/after and gap roll, and character status changes (without waiting 1 s).
function research.frame()
    -- PT-BR: Blocos de configuração do dano (arma/golpe), para achar a força de cambaleio (stagger).
    -- EN: Damage settings blocks (weapon/strike), to find the stagger force.
    if api.pop_settings then
        for _=1,16 do
            local d=api.pop_settings()
            if not d then break end
            note(string.format('Configuração do dano #%u: tipo=%u; região=0x%08x; base=%s; extra=%s; projétil=%s',
                d.sequence,d.kind,d.region,d.base,d.extra,d.projectile))
        end
    end
    -- PT-BR: F8 marca o momento (cair/levantar/rajada) e grava o registro do personagem 3 s antes e 3 s depois.
    -- EN: F8 marks the moment (fall/get up/volley) and logs the character record 3 s before and 3 s after.
    local clock=os.clock()
    if api.character_record then
        local record=api.character_record()
        if record then
            research.ring=research.ring or {}
            local ring=research.ring
            ring[#ring+1]={clock,record}
            if #ring>240 then table.remove(ring,1) end
            if research.after_until and clock<=research.after_until then
                research.after_count=(research.after_count or 0)+1
                if research.after_count%3==0 then note(string.format('Depois da marca +%.2f s: %s',clock-research.mark_at,record)) end
            end
        end
    end
    if api.key_down then
        local down=api.key_down(0x77)
        if down and not research.f8 then
            research.marks=(research.marks or 0)+1
            research.mark_at=clock
            note(string.format('MARCA F8 #%u',research.marks))
            local ring=research.ring or {}
            for i,row in ipairs(ring) do
                if clock-row[1]<=3 and i%3==0 then note(string.format('Antes da marca -%.2f s: %s',clock-row[1],row[2])) end
            end
            research.after_until,research.after_count=clock+3,0
        end
        research.f8=down
    end
    -- PT-BR: Teste do tranco: com RegionalArmorFlinchA.txt ou B.txt, troca um modificador do passivo vestido (devolvido ao apagar).
    -- EN: Flinch test: with RegionalArmorFlinchA.txt or B.txt, overrides one modifier of the worn passive (restored when deleted).
    if api.flinch_test and api.passive_override and clock>=(research.flinch_at or 0) then
        research.flinch_at=clock+1
        local mode=api.flinch_test()
        local stat,value=nil,nil
        if mode=='A' then stat,value=0x73734d67,1 elseif mode=='B' then stat,value=0xafae3b47,0 end
        local result=stat and api.passive_override(stat,value,true) or (research.flinch_mode and api.passive_override(0,0,false)) or nil
        local key=tostring(mode)..':'..tostring(result)
        if key~=research.flinch_key then
            research.flinch_key=key;research.flinch_mode=mode
            note(string.format('Teste do tranco: modo=%s; código=%s; valor=%s; resultado=%s (1 = aplicado/devolvido, 0 = passivo sem esse código, -1 = recusado).',
                tostring(mode or 'desligado'),stat and string.format('0x%08x',stat) or '-',tostring(value or '-'),tostring(result)))
        end
    end
    if api.pop_hit then
        local names,weights,kinds=HAP_SOURCE_NAMES or {},{[0]='leve',[1]='média',[2]='pesada'},{'tiro','corpo a corpo','fogo direto (nativo)'}
        for _=1,64 do
            local h=api.pop_hit()
            if not h then break end
            local part=HAPI18n.get(2).flash_parts[HAPFeedback.part(h.region,h.collider)] or '?'
            local pellets,rolls,passes=math.floor(h.flags/256)%256,math.floor(h.flags/65536)%256,math.floor(h.flags/16777216)%256
            local result=h.after==0 and h.before>0 and 'bloqueado' or h.after<h.before and 'reduzido' or 'inteiro'
            note(string.format('Impacto #%u: %s; atacante=%s (%s); distância=%.1f m; parte=%s; região=0x%08x; volume=0x%08x; '
                ..'AP=%.4g; dano %u -> %u (%s); armadura=%s%s; elemento=%u; causa=0x%08x; raspão=%s; placas inclinadas=%s; '
                ..'chumbos=%u; sorteios de fresta=%u; frestas que passaram=%u; motivo=%u.',
                h.sequence,kinds[h.kind] or '?',names[h.attacker] or 'não identificado',h.attacker,h.distance or 0,part,h.region,h.collider,
                h.ap,h.before,h.after,result,weights[h.weight] or '?',h.reinforced~=0 and ' reforçada' or '',h.element,h.cause,
                h.flags%2==1 and 'sim' or 'não',math.floor(h.flags/2)%2==1 and 'sim' or 'não',pellets,rolls,passes,h.reason))
        end
    end
    if api.statuses then
        local list=api.statuses()
        if list then
            local ids,detail={},{}
            for _,s in ipairs(list) do
                ids[#ids+1]=s.id..(s.on and '+' or '-')
                detail[#detail+1]=string.format('%u(%s)%s v=%.3g t=%.3g fim=%.3g',s.id,status_names[s.id] or '?',
                    s.on and ' ativo' or ' acumulando',s.value,s.clock,s.ends)
            end
            local key=table.concat(ids,',')
            if key~=research.status then
                research.status=key
                note(string.format('Status do personagem: %s',#detail>0 and table.concat(detail,'; ') or 'nenhum'))
            end
        end
    end
end
local wanted_diagnostics,diagnostics_checked_at=false,-1
local host, desired, active, installed, failed = nil,true,false,false,false
local retry_menu, retry_install, report_at, last_init, last_apply = 0,0,0,-1,-1
local refresh_at, last_local, last_local_apply, last_late, last_avatar = 0,-1,-1,-1,-1
local last_prediction = ''
local last_decision = ''
local wanted_protection, applying, last_effect = true,false,''
local last_melee=''
local wanted_ergonomics=true
local wanted_descriptions,last_descriptions=true,nil
local language,last_language=1,nil
local last_ergonomics=''
local last_ergo_read=''
local wanted_swimming,last_swim,last_handling=true,'',''
local wanted_heavy,last_movement=false,''
local next_ui_retry=0
local cause_report_at,last_cause_version,last_origin_stats,cause_logged=0,-1,'',{}
local summary_at=0
local function has_flag(flags,mask) return math.floor((flags or 0)/mask)%2==1 end
local function metres(value,valid)
    return valid and type(value)=='number' and value==value and string.format('%.2f m',value) or 'indisponível'
end
local function selected_language()
    local current=rawget(_G,'ModOptionsMenu')
    if type(current)=='table' and current.api==1 and type(current.get)=='function' then
        return HAPI18n.index(current.get(language_option))
    end
    return 1
end
local function menu_text(key,dynamic)
    if not dynamic then return HAPI18n.get(1)[key] end
    -- PT-BR: O Bingus atualiza textos funcionais ao reabrir o menu; a categoria mantém sua identidade.
    -- EN: Bingus refreshes function-backed text when reopening the menu; category identity is preserved.
    return function() return HAPI18n.get(selected_language())[key] end
end
local function menu(now)
    local current = rawget(_G,'ModOptionsMenu')
    if type(current) ~= 'table' or current.api ~= 1 or type(current.get) ~= 'function'
        or type(current.register_option) ~= 'function' then return end
    if current ~= host and now >= retry_menu then
        retry_menu = now+1000
        local dynamic=type(current.version)=='number' and current.version>=2
        local mod='Armor Reimagined'
        local registered=current.register_option(language_option,{type='choice',mod=mod,
            label=menu_text('language_label',dynamic),default=1,choices=HAPI18n.choices,
            description=menu_text('language_description',dynamic)})
        -- PT-BR: Idioma e aviso na tela são configuráveis; proteção, ergonomia, natação e descrições ficam sempre ligadas.
        -- EN: Language and on-screen feedback are configurable; protection, ergonomics, swimming and descriptions are always on.
        local feedback_registered=current.register_option(feedback_option,{type='toggle',mod=mod,
            label=menu_text('feedback_label',dynamic),default=true,
            description=menu_text('feedback_description',dynamic)})
        -- PT-BR: Placas inclinadas (raspão +1 AV na média/pesada): opcional e desligado por padrão.
        -- EN: Angled plates (glancing hit +1 AV on medium/heavy): optional and off by default.
        local angled_registered=current.register_option(angled_option,{type='toggle',mod=mod,
            label=menu_text('angled_label',dynamic),default=false,
            description=menu_text('angled_description',dynamic)})
        -- PT-BR: Frestas nas juntas (pesada): bloqueio no braço ou na perna tem 20% de chance de passar inteiro; ligado por padrão.
        -- EN: Arm gaps: a block on the arm lets 20% through; on by default.
        local gaps_registered=current.register_option(gaps_option,{type='toggle',mod=mod,
            label=menu_text('gaps_label',dynamic),default=true,
            description=menu_text('gaps_description',dynamic)})
        if registered and feedback_registered and angled_registered and gaps_registered then host = current end
    end
    if current == host then
        language=selected_language()
        wanted_feedback=current.get(feedback_option)~=false
        wanted_angled=current.get(angled_option)==true
        wanted_gaps=current.get(gaps_option)~=false
        if last_gaps~=wanted_gaps then
            if api.arm_gaps then api.arm_gaps(wanted_gaps) end
            presentation.gaps=wanted_gaps
            note('Frestas nos braços: '..(wanted_gaps and 'ligadas' or 'desligadas'))
            last_gaps=wanted_gaps
        end
        if last_angled~=wanted_angled then
            if api.angled_plates then api.angled_plates(wanted_angled) end
            presentation.angled=wanted_angled
            note('Placas inclinadas: '..(wanted_angled and 'ligadas' or 'desligadas'))
            last_angled=wanted_angled
        end
        if last_feedback~=wanted_feedback then
            note('Aviso de proteção na tela: '..(wanted_feedback and 'ligado' or 'desligado'))
            last_feedback=wanted_feedback
        end
        if last_language~=language then
            note('Idioma da interface: '..HAPI18n.choices[language])
            last_language=language
        end
        if last_descriptions~=wanted_descriptions then
            note('Descrições no Arsenal: '..(wanted_descriptions and 'ligadas' or 'desligadas'))
            last_descriptions=wanted_descriptions
        end
    end
end
  update = function(...)
    research.t0=os.clock()
    local safe_ui,ui_guard_error=pcall(presentation.before_ui,rawget(_G,'stingray'),active)
    if not safe_ui then pcall(presentation.close);note('Descrição suspensa antes da atualização: '..tostring(ui_guard_error)) end
    local safe_alerts,alerts_error=pcall(alerts.before_ui,rawget(_G,'stingray'))
    if not safe_alerts then pcall(alerts.close);note('Aviso suspenso: '..tostring(alerts_error)) end
    local safe_feedback,feedback_error=pcall(feedback.before_ui,rawget(_G,'stingray'))
    if not safe_feedback then pcall(feedback.close);note('Indicador suspenso: '..tostring(feedback_error)) end
    local restored,restore_error=pcall(presentation.ergo_before)
    if not restored then wanted_ergonomics=false;note('Ergonomia suspensa: '..tostring(restore_error)) end
    if not failed then
        local worked, why = xpcall(function()
            local now = api.now()
            menu(now)
            if not installed and now >= retry_install then
                retry_install = now+5000
                local result = api.install()
                if result == -1 then note('Módulo ainda ausente; aguardando 5 segundos.')
                elseif result == 1 then
                    installed = true
                    local s = api.stats()
                    note(string.format('Adaptador instalado por ponteiro de dados; página=0x%x. '
                        ..'Blindagem aplicada=0; aguardando impactos para validar integração.',s.slot_protection))
                else
                    -- PT-BR: Códigos de impressão digital/trechos conferidos indicam outra versão do jogo.
                    -- EN: Fingerprint/pinned-code failures indicate a different game version.
                    local version_codes={[21]=true,[22]=true,[46]=true,[51]=true,[52]=true,[61]=true}
                    pcall(alerts.notice,version_codes[result] and 'version' or 'refused',result,now)
                    -- PT-BR: Recusa por página de memória: registra a proteção e o estado encontrados (para diagnóstico remoto).
                    -- EN: Refusal because of a memory page: logs the protection and state found (for remote diagnosis).
                    local protect,state=nil,nil
                    if api.refused_page then protect,state=api.refused_page() end
                    error(research.describe_install(result,protect,state),0)
                end
            end
            if installed and desired ~= active then
                api.enable(desired)
                active = desired
                note(active and 'Integração ligada.' or 'Integração desligada.')
            end
            local next_protection=active and wanted_protection
            if installed and next_protection~=applying then
                api.protect(next_protection); applying=next_protection
                note(applying and 'Proteção experimental ligada para missão confirmada; aguarde contadores de escrita.'
                    or 'Proteção desligada; somente observação quando o mod estiver ativo.')
            end
            if installed and active and now >= refresh_at then
                refresh_at = now+250
                api.refresh_local()
            end
            if installed and now >= report_at then
                report_at = now+1000
                if now>=diagnostics_checked_at then
                    diagnostics_checked_at=now+10000
                    -- PT-BR: Diagnóstico detalhado só quando o arquivo RegionalArmorDiagnostics.txt existir.
                    -- EN: Detailed diagnostics only when the RegionalArmorDiagnostics.txt file exists.
                    local requested=api.diagnostics_requested and api.diagnostics_requested() or false
                    if requested~=wanted_diagnostics then
                        wanted_diagnostics=requested
                        if api.diagnostics then api.diagnostics(requested) end
                        note(requested and 'Diagnóstico detalhado ligado: RegionalArmorDiagnostics.txt encontrado.'
                            or 'Diagnóstico detalhado desligado.')
                    end
                end
                local s = api.stats()
                if wanted_diagnostics and (s.init_seen ~= last_init or s.apply_seen ~= last_apply) then
                    note(string.format('Inicialização=%d; pré-aplicação=%d; capturas=%d; descartadas=%d; '
                        ..'falhas de leitura=%d; última etapa=%d; alvo=%u; objeto atingido=0x%08x; '
                        ..'tipo=%u; dano calculado=%u; efeito habilitado=%d.',
                        s.init_seen,s.apply_seen,s.captured,s.dropped,s.read_failed,s.stage,s.victim,s.zone,
                        s.source_kind,s.damage,s.protection_active))
                    last_init,last_apply = s.init_seen,s.apply_seen
                end
                local d = api.detail()
                local p = api.prediction()
                local decision = api.decision()
                local effect=api.effect()
                local melee=api.melee_stats()
                local melee_key=table.concat({melee.prepared,melee.rejected,melee.applied,melee.refused,melee.unknown},':')
                -- PT-BR: Fora do diagnóstico, resumo de corpo a corpo/tiros no máximo a cada 5 s.
                -- EN: Outside diagnostics, melee/projectile summaries at most every 5 s.
                local summary_due=wanted_diagnostics or now>=summary_at
                if summary_due and melee_key~=last_melee then
                    note(string.format('Corpo a corpo regional: preparados=%u; preparos recusados=%u; associados=%u; '
                        ..'ambíguos=%u; habilidades não identificadas=%u; reduções aplicadas=%u; recusas=%u; '
                        ..'avatar=%u; causa=0x%08x; região=0x%08x; armadura=0x%08x; categoria=%u; '
                        ..'dano antes=%u; dano depois=%u; motivo=%u; dano mantido=%u%%; volume=0x%08x; reforçada=%u; reduções fora da lista=%u (por inimigo+golpe=%u); golpes letais preservados=%u; vida máxima lida=%u; distância do atacante=%s. '
                        ..'Percentual regional do perfil equipado; golpes físicos listados, pares inimigo+golpe confirmados até 6 m ou outro atacante até 3 m (exceto Charger, Bile Titan, Impaler e respingos de ácido); cabeça -20%%.',
                        melee.prepared,melee.rejected,melee.matched,melee.ambiguous,melee.unknown,melee.applied,melee.refused,
                        melee.victim,melee.cause,melee.region,melee.armor_id,melee.weight,melee.before,melee.after,melee.reason,melee.keep_percent,
                        melee.collider,melee.reinforced,melee.proximity or 0,melee.by_attacker or 0,melee.lethal or 0,melee.max_health or 0,metres(melee.distance,(melee.distance or 0)>0)))
                    last_melee=melee_key;summary_at=now+5000
                end
                if presentation.ergo_status~=last_ergonomics then
                    note('Ergonomia: '..tostring(presentation.ergo_status))
                    last_ergonomics=presentation.ergo_status
                end
                local ergo=presentation.ergo_sample
                if ergo and ergo.reason==0 then
                    local key=table.concat({ergo.record,ergo.weight,ergo.before,ergo.expected,ergo.observed},':')
                    if key~=last_ergo_read then
                        local weights={[0]='leve',[1]='média',[2]='pesada'}
                        note(string.format('Ergonomia numérica: arma=%s; categoria=%s; base=%.6g; '
                            ..'previsto=%.6g; relido=%.6g; escritas=%u; verificadas=%u; '
                            ..'restaurações=%u; conflitos de restauração=%u; '
                            ..'janelas de escrita=%u; falhas de permissão=%u. '
                            ..'Aplicação na principal do jogador local e nos dois coeficientes da mira.',
                            ergo.weapon,weights[ergo.weight] or 'desconhecida',ergo.before,ergo.expected,ergo.observed,
                            ergo.writes,ergo.verified,ergo.restores,ergo.restore_refused,
                            ergo.protection_windows,ergo.protection_failed))
                        last_ergo_read=key
                    end
                else last_ergo_read='' end
                local handling=api.handling(ergo and ergo.record)
                local instances={}
                if handling.reason==0 then
                    for _,row in ipairs(handling.rows) do
                        instances[#instances+1]=string.format('entidade=%u, calculada=%.6g, atual=%.6g, resposta A=%.6g, resposta B=%.6g',
                            row.entity,row.base,row.current,row.response_a,row.response_b)
                    end
                end
                local handling_key=table.concat(instances,'; ')
                if handling_key~='' and handling_key~=last_handling then
                    note('Ergonomia na arma principal segurada pelo jogador local: '..handling_key
                        ..'. Instância identificada pelo inventário, arma segurada e propriedade local.')
                end
                last_handling=handling_key
                local swim=api.swim_stats()
                local movement=api.movement_stats()
                if api.fire_native then
                    local fire=api.fire_native()
                    if fire~=last_fire then
                        last_fire=fire
                        note(string.format('Fogo direto com dano nativo do jogo=%u (lança-chamas e elemento fogo nunca passam pela blindagem).',fire))
                    end
                end
                if wanted_diagnostics and api.fire then
                    local burn=api.fire()
                    if burn.sequence~=last_burn then
                        last_burn=burn.sequence
                        local ignition=({'jato/impacto direto','fogo no chão','já queimando'})[burn.ignition] or '?'
                        note(string.format('Queimadura: duração=%.1f s; toques=%u (direto=%u, chão=%u, queimando=%u); '
                            ..'valor bruto total=%.1f (antes do passivo); primeiro toque=%.1f; início=%s; armadura=0x%08x; '
                            ..'categoria=%u; vida no início=[%s]; vida no fim=[%s]. Pesquisa somente; dano de fogo sempre nativo.',
                            burn.duration_ms/1000,burn.ticks,burn.direct,burn.ground,burn.burning,burn.damage,
                            burn.first_damage,ignition,burn.armor_id,burn.weight,burn.health_start,burn.health_end))
                    end
                end
                -- PT-BR: Compatibilidade: registra se o Realistic Resistances está carregado (ele mexe nos status de fogo, gás e
                -- arco e no modificador de arco dos passivos; o Armor Reimagined não escreve em nada disso).
                -- EN: Compatibility: logs whether Realistic Resistances is loaded (it changes the fire, gas and arc statuses and
                -- the passives' arc modifier; Armor Reimagined writes to none of those).
                local rr=rawget(_G,'RealisticResistances')
                local rr_now=type(rr)=='table' and tostring(rr.status or 'carregado') or 'ausente'
                if rr_now~=research.rr then
                    research.rr=rr_now
                    note('Realistic Resistances: '..rr_now..'. Armor Reimagined não escreve em status, passivos nem dano de fogo/gás/arco.')
                end
                -- PT-BR: A pesquisa roda protegida: um erro nela nunca desliga o resto do mod.
                -- EN: Research runs protected: an error in it never turns off the rest of the mod.
                -- PT-BR: Pesquisa só com o diagnóstico detalhado ligado (sem leituras extras nem log para quem joga).
                -- EN: Research only with detailed diagnostics on (no extra reads or log lines for players).
                local research_ok,research_error=not wanted_diagnostics,nil
                if wanted_diagnostics then research_ok,research_error=pcall(function()
                if api.research_state then
                    local state=api.research_state()
                    if state~=research.state then
                        research.state=state
                        note('Pesquisa de derrubada/tranco: '..state..'.')
                    end
                end
                if api.passives then
                    local passives=api.passives()
                    if passives and passives~=research.passives then
                        research.passives=passives
                        local equipped_now=api.equipped()
                        note(string.format('Passivo da armadura: armadura=0x%08x; categoria=%u; %s',
                            equipped_now.armor_id or 0,equipped_now.weight or 0,passives))
                    end
                end
                end) end
                if not research_ok and research.error~=tostring(research_error) then
                    research.error=tostring(research_error)
                    note('Pesquisa de derrubada/tranco com erro (o resto do mod segue ligado): '..research.error)
                end
                if wanted_diagnostics and api.character_record then
                    local record=api.character_record()
                    if record and record~=last_record then
                        last_record=record
                        local equipped_now=api.equipped()
                        note(string.format('Registro do personagem: armadura=0x%08x; categoria=%u; %s',
                            equipped_now.armor_id or 0,equipped_now.weight or 0,record))
                    end
                end
                local movement_key=table.concat({tostring(wanted_heavy),movement.active,movement.reason,movement.record,
                    movement.before,movement.expected,movement.observed},':')
                if movement_key~=last_movement then
                    note(string.format('Movimento da armadura: reforçada=%s; penalidade ativa=%u; motivo=%u; avatar=%u; '
                        ..'movimento antes=%.6g; previsto=%.6g; relido=%.6g; aplicações=%u; restaurações=%u; recusas=%u. '
                        ..'Leve +10%%/+5%%; pesada -5%%/-10%%. AV4 exige penalidade local confirmada; sem confirmação conserva AV3.',
                        tostring(wanted_heavy),movement.active,movement.reason,movement.avatar,movement.before,
                        movement.expected,movement.observed,movement.applied,movement.restored,movement.refused))
                    last_movement=movement_key
                end
                local swim_key=table.concat({swim.reason,swim.weight,swim.active,swim.refused},':')
                if swim_key~=last_swim then
                    note(string.format('Natação experimental: ativa=%u; categoria=%u; motivo=%u; '
                        ..'fôlego antes=%.6g; previsto=%.6g; relido=%.6g; aplicações=%u; reposições suspensas=%u; recusas=%u. '
                        ..'O movimento continua original; a travessia ainda precisa de teste em água.',
                        swim.active,swim.weight,swim.reason,swim.before,swim.expected,swim.observed,
                        swim.applied,swim.restored,swim.refused))
                    last_swim=swim_key
                end
                for i=1,8 do
                    local combat=api.combat()
                    if not combat then break end
                    note(string.format('Diagnóstico de combate: etapa=%u; tipo=%u; avatar=%u; chamador=0x%08x; '
                        ..'parâmetros posteriores presentes=%u; dados=%s; parâmetros=%s. '
                        ..'Registro de leitura antes dos efeitos; não confirma AP final. Efeitos visuais permanecem originais.',
                        combat.stage,combat.kind,combat.victim,combat.parent,combat.extra_valid,combat.data,combat.extra))
                    local source_names = HAP_SOURCE_NAMES or {}
                    local o=combat.origin or {}
                    local flags=o.flags or 0
                    local dealer_health=has_flag(flags,4) and o.dealer_health_type or nil
                    local owner_health=has_flag(flags,8) and o.owner_health_type or nil
                    note(string.format('Origem do impacto: etapa=%u; tipo=%u; avatar=%u; sequência=%u; ligado=%u; ambíguo=%u; '
                        ..'causa=0x%08x; produtor=0x%08x; região=0x%08x; causador=%u; tipo causador=%s; nome causador=%s; '
                        ..'dono=%u; tipo dono=%s; nome dono=%s; tipo mapa causador=%s; unidade causador=%u; id completo causador=%u; distância=%s; alcance do golpe=%s; via rede: entidade=%u, tipo=%s, nome=%s, distância=%s; marcas=0x%04x. '
                        ..'Tipo pelo descritor de vida no impacto; ligação somente pela chave exata de 13 palavras; nome ausente não é inferido.',
                        combat.stage,combat.kind,combat.victim,o.sequence or 0,has_flag(flags,256) and 1 or 0,has_flag(flags,512) and 1 or 0,
                        o.cause or 0,combat.producer or 0,o.region or 0,combat.dealer or 0,dealer_health or 'não resolvido',
                        dealer_health and source_names[dealer_health] or 'não identificado',combat.owner or 0,owner_health or 'não resolvido',
                        owner_health and source_names[owner_health] or 'não identificado',combat.dealer_type or '0000000000000000',
                        o.dealer_unit or 0,o.dealer_full or 0,metres(o.distance,has_flag(flags,16) and has_flag(flags,32)),
                        metres(o.reach,has_flag(flags,4096)),o.net_entity or 0,has_flag(flags,8192) and o.net_type or 'não resolvido',
                        has_flag(flags,8192) and source_names[o.net_type] or 'não identificado',metres(o.net_distance,has_flag(flags,16384) and has_flag(flags,32)),flags))
                    if combat.stage==1 then
                        local function point(p,valid)
                            return valid and p and string.format('(%.2f, %.2f, %.2f)',p[1],p[2],p[3]) or 'indisponível'
                        end
                        note(string.format('Posições do impacto: sequência=%u; atacante=%s; você=%s; via rede=%s; '
                            ..'ponto do golpe até você=%s; início do golpe até o atacante=%s. Diagnóstico de leitura de posição.',
                            o.sequence or 0,point(o.dealer_position,has_flag(flags,16)),point(o.victim_position,has_flag(flags,32)),
                            point(o.net_position,has_flag(flags,16384)),metres(o.hit_to_victim,has_flag(flags,32)),
                            metres(o.hit_to_dealer,has_flag(flags,16))))
                    end
                end
                if wanted_diagnostics and now>=cause_report_at and api.origin_stats then
                    cause_report_at=now+10000
                    local origin=api.origin_stats()
                    local origin_key=table.concat({origin.built,origin.linked,origin.ambiguous,origin.unlinked,
                        origin.link_busy,origin.recorded,origin.overflow},':')
                    if origin_key~=last_origin_stats then
                        note(string.format('Coleta de origem: impactos montados=%u; eventos ligados=%u; ambíguos=%u; sem ligação=%u; '
                            ..'ligações descartadas por concorrência=%u; eventos resumidos=%u; causas além do limite de 128=%u.',
                            origin.built,origin.linked,origin.ambiguous,origin.unlinked,origin.link_busy,origin.recorded,origin.overflow))
                        last_origin_stats=origin_key
                    end
                    if origin.version~=last_cause_version then
                        last_cause_version=origin.version
                        local source_names=HAP_SOURCE_NAMES or {}
                        for index=0,127 do
                            local row=api.cause(index)
                            if not row then break end
                            if cause_logged[index]~=row.count then
                                cause_logged[index]=row.count
                                local resolved=row.dealer_type~='0000000000000000'
                                local distance=row.distance_count>0
                                note(string.format('Resumo de causa: tipo=%u; elemento=%u; causa=0x%08x; produtor=0x%08x; '
                                    ..'tipo causador=%s; nome causador=%s; eventos=%u; ligados=%u; na lista corpo a corpo=%u; reduzidos=%u; '
                                    ..'dano mín=%u; médio=%.1f; máx=%u; distância mín=%s; média=%s; máx=%s; amostras de distância=%u; regiões=0x%02x; alcance mín=%s; médio=%s; máx=%s; tipo via rede=%s; nome via rede=%s; eventos via rede=%u. '
                                    ..'Agregado de todos os eventos locais, independente das cotas; não autoriza redução.',
                                    row.kind,row.element,row.cause,row.producer,resolved and row.dealer_type or 'não resolvido',
                                    resolved and source_names[row.dealer_type] or 'não identificado',row.count,row.linked,row.known,row.reduced,
                                    row.damage_min,row.count>0 and row.damage_sum/row.count or 0,row.damage_max,
                                    metres(row.distance_min,distance),metres(distance and row.distance_sum/row.distance_count or 0,distance),
                                    metres(row.distance_max,distance),row.distance_count,row.regions,
                                    metres(row.reach_min,(row.reach_count or 0)>0),metres((row.reach_count or 0)>0 and row.reach_sum/row.reach_count or 0,(row.reach_count or 0)>0),
                                    metres(row.reach_max,(row.reach_count or 0)>0),(row.net_count or 0)>0 and row.net_type or 'não resolvido',
                                    (row.net_count or 0)>0 and source_names[row.net_type] or 'não identificado',row.net_count or 0))
                            end
                        end
                    end
                end
                local effect_key=table.concat({effect.enabled,effect.applied,effect.refused},':')
                if summary_due and effect_key~=last_effect then
                    note(string.format('Efeito habilitado=%u; eventos alterados=%u; bloqueios aplicados=%u; '
                        ..'reduções aplicadas=%u; recusas de aplicação=%u; avatar=%u; região=0x%08x; '
                        ..'dano antes=%u; dano depois=%u; motivo da última recusa=%u; '
                        ..'registro de escrita no dano à vida.',
                        effect.enabled,effect.applied,effect.blocked,effect.reduced,effect.refused,
                        effect.victim,effect.region,effect.before,effect.after,effect.reason))
                    last_effect=effect_key;summary_at=now+5000
                end
                local decision_key = table.concat({decision.evaluated,decision.unavailable},':')
                if wanted_diagnostics and decision_key ~= last_decision then
                    local weights = {[0]='leve',[1]='média',[2]='pesada'}
                    local action = decision.rule == 4294967295 and 'inconclusiva'
                        or decision.factor == 0 and 'bloquear'
                        or decision.factor < 1 and 'reduzir' or 'manter'
                    note(string.format('Decisões avaliadas=%u; inconclusivas=%u; bloqueios previstos=%u; '
                        ..'reduções previstas=%u; originais previstas=%u; avatar=%u; armadura=0x%08x; '
                        ..'categoria=%s; região=0x%08x; AP reconstruída=%.4g; decisão=%s; '
                        ..'dano original=%u; dano projetado=%u; fator=%.4g; volume=0x%08x; parte=%s; '
                        ..'volumes identificados=%u; alternativas regionais=%u; peitoral pesado AV4=%u.',
                        decision.evaluated,decision.unavailable,decision.blocked,decision.reduced,decision.original,
                        decision.victim,decision.armor_id,weights[decision.weight] or 'desconhecida',decision.region,
                        decision.penetration,action,decision.damage,decision.projected,decision.factor,
                        decision.collider or 0,HAPI18n.get(2).flash_parts[HAPFeedback.part(decision.region,decision.collider)] or '?',
                        decision.identified or 0,decision.fallback or 0,decision.heavy_av4 or 0))
                    last_decision = decision_key
                end
                local current_prediction = table.concat({p.rebuilt,p.rejected,p.matched,p.unmatched,p.ambiguous},':')
                if wanted_diagnostics and current_prediction ~= last_prediction then
                    note(string.format('Reconstruções=%u; recusadas=%u; eventos associados=%u; sem correspondência=%u; '
                        ..'ambíguos=%u; alvo associado=%u; região associada=0x%08x; dano original associado=%u; '
                        ..'AP reconstruída=[%.4g,%.4g,%.4g,%.4g]; AP selecionada na cópia=%.4g; '
                        ..'AP final não capturada diretamente.',
                        p.rebuilt,p.rejected,p.matched,p.unmatched,p.ambiguous,p.victim,p.region,p.damage,
                        p.penetration[1],p.penetration[2],p.penetration[3],p.penetration[4],p.selected))
                    last_prediction = current_prediction
                end
                if wanted_diagnostics and (d.local_init_seen ~= last_local or d.local_apply_seen ~= last_local_apply
                    or d.local_late_seen ~= last_late or d.local_avatar ~= last_avatar) then
                    local q = api.sampling()
                    note(string.format('Cotas do avatar=%u; tiros observados=%u; outros observados=%u; '
                        ..'tiros capturados=%u; outros capturados=%u; tiros restantes=%u; outros restantes=%u.',
                        q.quota_avatar,q.projectile_seen,q.other_seen,q.projectile_captured,q.other_captured,
                        q.projectile_remaining,q.other_remaining))
                    note(string.format('Avatar local=%u; inicialização local=%u; pré-aplicação local=%u; '
                        ..'preparação tardia=%u; tardia local=%u; amostras locais=%u; falhas locais=%u; '
                        ..'avatar da amostra=%u; região de dano=0x%08x; tipo=%u; chamador=0x%08x; '
                        ..'AP na preparação=[%.4g,%.4g,%.4g,%.4g]; dano bruto=%.4g; multiplicador=%.4g; '
                        ..'penetração final ainda não confirmada.',
                        d.local_avatar,d.local_init_seen,d.local_apply_seen,d.late_seen,d.local_late_seen,
                        d.local_captured,d.local_read_failed,d.sample_avatar,d.region,d.source_kind,d.parent_return_rva,
                        d.penetration[1],d.penetration[2],d.penetration[3],d.penetration[4],d.raw_damage,d.multiplier))
                    last_local,last_local_apply,last_late,last_avatar = d.local_init_seen,d.local_apply_seen,d.local_late_seen,d.local_avatar
                end
            end
        end,research.trace)
        if not worked then
            failed = true
            pcall(api.enable,false)
            pcall(api.detach)
            pcall(presentation.close)
            -- PT-BR: O log mantém só arquivo e linha (armor_probe.lua:1816), sem as pastas do caminho (mods/lobao/).
            -- A recusa de instalação já vem sem posição; o código dela diz o motivo.
            -- EN: The log keeps only file and line (armor_probe.lua:1816), without the path folders (mods/lobao/).
            -- A refused installation already comes without a position; its code tells the reason.
            note('Experimento desligado: '..(tostring(why):gsub('^[^\n]-([%w_%-]+%.lua:%d+:)','%1')))
            if not tostring(why):find('Instalação recusada',1,true) then pcall(alerts.notice,'refused','lua',api.now()) end
        end
    end
    local function finish(...)
        local finish_t0=os.clock()
        if installed and not failed and wanted_diagnostics then
            local ok_frame,frame_error=pcall(research.frame)
            if not ok_frame and research.error~=tostring(frame_error) then
                research.error=tostring(frame_error)
                note('Registro por impacto com erro (o resto do mod segue ligado): '..research.error)
            end
        end
        if installed and not failed then
            local now=api.now()
            if now>=next_ui_retry then
                local ok_ui,ui_error=pcall(presentation.step,rawget(_G,'stingray'),now,active,applying,wanted_ergonomics,language,wanted_swimming,wanted_descriptions)
                if not ok_ui then
                    next_ui_retry=now+5000;pcall(presentation.close);note('Descrição suspensa: '..tostring(ui_error))
                end
            end
        end
        if installed and not failed and now_feedback_ok then
            local fed,feed_error=pcall(function()
                local now=api.now()
                local totals=api.totals()
                local screen=presentation.screen and presentation.screen()
                local armor_report=api.report and api.report() or nil
                local equipped_now=api.equipped()
                feedback.update(now,totals,screen,armor_report,equipped_now.valid==1 and equipped_now.avatar or nil)
                if wanted_diagnostics then
                    local key=tostring(screen)..':'..tostring(totals.mission)
                    if key~=last_screen then
                        last_screen=key
                        note(string.format('Tela do jogo: código=%s; missão=%u.',tostring(screen),totals.mission))
                    end
                end
                if wanted_feedback then feedback.draw(rawget(_G,'stingray'),now,language) else feedback.close() end
            end)
            if not fed then now_feedback_ok=false;pcall(feedback.close);note('Indicador suspenso: '..tostring(feed_error)) end
        end
        local alert_ok,alert_error=pcall(alerts.step,rawget(_G,'stingray'),api.now(),active and applying and wanted_alerts,language)
        if not alert_ok then pcall(alerts.close);note('Aviso suspenso: '..tostring(alert_error)) end
        -- PT-BR: Quadro lento do próprio mod (50 ms ou mais): registra quanto foi antes e depois dos outros mods.
        -- EN: Slow frame of the mod itself (50 ms or more): logs how much was before and after the other mods.
        local after_ms=(os.clock()-finish_t0)*1000
        local own_ms=(research.before_ms or 0)+after_ms
        if own_ms>=50 then
            note(string.format('Quadro lento do mod: %.0f ms (antes dos outros mods %.0f ms; depois %.0f ms); diagnóstico=%s; memória Lua=%.0f KB.',
                own_ms,research.before_ms or 0,after_ms,tostring(wanted_diagnostics),collectgarbage('count')))
        end
        research.before_ms=0
        research.flush()
        return ...
    end
    if installed and not failed then
        -- PT-BR: Ajusta só a instância local antes da atualização nativa; nenhuma tabela compartilhada é escrita.
        -- EN: Adjust only the local instance before native update; no shared table is written.
        local ok_profile,profile_error=pcall(function()
            local equipped=api.equipped()
            api.armor_step(active and equipped.valid==1 and equipped.armor_id or 0,
                equipped.valid==1 and profiles.get(equipped.armor_id))
            wanted_heavy=equipped.valid==1 and equipped.weight~=1 and profiles.get(equipped.armor_id)
        end)
        if not ok_profile then
            pcall(api.profile_step,0,false);pcall(api.heavy_step,false);wanted_heavy=false
            note('Perfil equipado suspenso: '..tostring(profile_error))
        end
        local ok_ergo,why=pcall(presentation.ergo_after,active and wanted_ergonomics)
        if not ok_ergo then pcall(api.ergo_restore);wanted_ergonomics=false;note('Ergonomia suspensa: '..tostring(why)) end
        local ok_swim,swim_error=pcall(presentation.swim_after,active and wanted_swimming)
        if not ok_swim then pcall(api.swim_step,false);wanted_swimming=false;note('Natação suspensa: '..tostring(swim_error)) end
    end
    -- PT-BR: Tempo do próprio mod antes de chamar os outros mods (o tempo deles não entra na conta).
    -- EN: The mod's own time before calling the other mods (their time is not counted).
    research.before_ms=(os.clock()-(research.t0 or os.clock()))*1000
    return finish(previous(...))
end
shutdown=function(...)
    flush_log()
    pcall(alerts.close)
    pcall(feedback.close)
    pcall(presentation.stop)
    pcall(api.enable,false)
    pcall(api.detach)
    if previous_shutdown then return previous_shutdown(...) end
end
note('Armor Reimagined 1.1.2 carregado. Blindagem regional por categoria (leve/média/pesada, padrão/reforçada), corpo a corpo por inimigo e distância, golpe letal mantido, velocidade e ergonomia por classe. Somente o personagem local; jogue em lobby privado ou com amigos. Diagnóstico detalhado: criar RegionalArmorDiagnostics.txt.')
