#include <windows.h>
#undef NDEBUG
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "actor_bridge.h"
#include "armor_rules.h"
#include "runtime_fixture.h"

extern uint32_t ArmorTestInitCall(uint32_t actor, void *context, void **slot);
extern uint32_t ArmorTestApplyCall(uint32_t actor, void *context, void **slot);
extern void ArmorTestInitReturn(void), ArmorTestApplyReturn(void);
extern uintptr_t ArmorTestLateCall(uintptr_t arg, void *context, void **slot);
extern void ArmorTestLateReturn(void);
static volatile LONG original_calls;
static void **slot;
static unsigned char hit[0x40], event[0x70];
static unsigned char late_hit[0x118];
static void **getter_slot;
static uintptr_t getter(uintptr_t arg) {
    SetLastError(5151);
    return arg ^ UINT64_C(0x987654321234abcd);
}
static uint32_t actor_name(uint32_t actor) {
    InterlockedIncrement(&original_calls);
    SetLastError(4242);
    return actor ^ UINT32_C(0xa5a5a5a5);
}
static void put(unsigned char *data, size_t offset, uint32_t value) { memcpy(data + offset, &value, 4); }
static DWORD WINAPI worker(void *unused) {
    (void)unused;
    for (unsigned i = 0; i < 10000; ++i) {
        assert(ArmorTestInitCall(i, hit, slot) == (i ^ UINT32_C(0xa5a5a5a5)));
        assert(GetLastError() == 4242);
        assert(ArmorTestApplyCall(i, event, slot) == (i ^ UINT32_C(0xa5a5a5a5)));
        assert(GetLastError() == 4242);
    }
    return 0;
}
static DWORD WINAPI late_worker(void *unused) {
    (void)unused;
    for (unsigned i = 0; i < 10000; ++i) {
        assert(ArmorTestLateCall(i, late_hit, getter_slot) == (i ^ UINT64_C(0x987654321234abcd)));
        assert(GetLastError() == 5151);
    }
    return 0;
}
static void late_tests(void) {
    getter_slot = VirtualAlloc(NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    assert(getter_slot);
    *getter_slot = (void *)getter;
    DWORD old;
    assert(VirtualProtect(getter_slot, 4096, PAGE_READONLY, &old));
    assert(ArmorBridgeTestLateInstall(getter_slot, (uintptr_t)ArmorTestLateReturn) == 42);
    assert(*getter_slot == (void *)getter);
    // PT-BR: Página deixada como PAGE_EXECUTE_READWRITE por outro mod também é aceita (relato do código 42).
    // EN: A page left as PAGE_EXECUTE_READWRITE by another mod is also accepted (code 42 report).
    assert(VirtualProtect(getter_slot, 4096, PAGE_EXECUTE_READWRITE, &old));
    assert(ArmorBridgeTestLateInstall(getter_slot, (uintptr_t)ArmorTestLateReturn) == 1);
    assert(*getter_slot == (void *)ArmorLateHook);
    ArmorBridgeRefreshLocal();
    ArmorBridgeDetail d;
    ArmorBridgeReadDetail(&d);
    assert(d.local_avatar == UINT32_MAX);
    ArmorBridgeTestSetLocal(71);
    put(late_hit, 0x20, 70);
    assert(ArmorTestLateCall(123, late_hit, getter_slot) == (123 ^ UINT64_C(0x987654321234abcd)));
    ArmorBridgeReadDetail(&d);
    assert(d.late_installed && d.late_seen == 1 && !d.local_late_seen && !d.local_captured);
    put(late_hit, 0x20, 71); put(late_hit, 0x7c, 2854072496u);
    put(late_hit, 0, 2);
    for (unsigned i=0; i<70; ++i) {
        assert(ArmorTestLateCall(i, late_hit, getter_slot) == (i ^ UINT64_C(0x987654321234abcd)));
    }
    ArmorBridgeSampling q;
    ArmorBridgeReadSampling(&q);
    assert(q.other_seen == 70 && q.other_captured == 64 && q.other_remaining == 0);
    assert(q.projectile_seen == 0 && q.projectile_remaining == 64 && q.quota_avatar == 71);
    put(late_hit, 0, 0);
    const float ap[4] = {2, 1.5f, 1, 0.5f}, damage = 30, multiplier = 0.75f;
    memcpy(late_hit+0x9c, ap, sizeof(ap)); memcpy(late_hit+0x98, &damage, 4); memcpy(late_hit+0x94, &multiplier, 4);
    unsigned char before[sizeof(late_hit)];
    memcpy(before, late_hit, sizeof(before));
    assert(ArmorTestLateCall(123, late_hit, getter_slot) == (123 ^ UINT64_C(0x987654321234abcd)));
    assert(GetLastError() == 5151);
    ArmorBridgeReadDetail(&d);
    assert(d.local_late_seen == 71 && d.local_captured == 65 && d.region == 2854072496u && d.sample_avatar == 71);
    assert(!memcmp(d.penetration, ap, sizeof(ap)) && d.raw_damage == 30 && d.multiplier == 0.75f);
    assert(ArmorTestLateCall(123, (void *)1, getter_slot) == (123 ^ UINT64_C(0x987654321234abcd)));
    assert(GetLastError() == 5151);
    ArmorBridgeEnable(0);
    assert(ArmorTestLateCall(123, late_hit, getter_slot) == (123 ^ UINT64_C(0x987654321234abcd)));
    ArmorBridgeReadDetail(&d);
    assert(d.late_seen == 73);
    ArmorBridgeEnable(1);
    // PT-BR: As amostras locais continuam disponíveis após esgotar as amostras globais.
    // EN: Local samples remain available after the global sample quota is exhausted.
    assert(ArmorTestInitCall(7, hit, slot) == (7 ^ UINT32_C(0xa5a5a5a5)));
    assert(ArmorTestApplyCall(7, event, slot) == (7 ^ UINT32_C(0xa5a5a5a5)));
    ArmorBridgeReadDetail(&d);
    assert(d.local_init_seen == 1 && d.local_apply_seen == 1);
    HANDLE threads[4];
    for (unsigned i=0; i<4; ++i) { threads[i] = CreateThread(NULL, 0, late_worker, NULL, 0, NULL); assert(threads[i]); }
    assert(WaitForMultipleObjects(4, threads, TRUE, INFINITE) == WAIT_OBJECT_0);
    for (unsigned i=0; i<4; ++i) CloseHandle(threads[i]);
    ArmorBridgeReadDetail(&d);
    assert(d.local_late_seen == 40071 && d.local_captured <= 128 && !d.local_read_failed);
    ArmorBridgeReadSampling(&q);
    assert(q.projectile_seen == 40001 && q.projectile_captured == 64 && q.projectile_remaining == 0);
    assert(!memcmp(late_hit, before, sizeof(before)));
    ArmorBridgeTestSetLocal(99);
    ArmorBridgeReadDetail(&d);
    assert(d.local_avatar == 99 && d.sample_avatar == 71);
    put(late_hit, 0x20, 99);
    assert(ArmorTestLateCall(123, late_hit, getter_slot) == (123 ^ UINT64_C(0x987654321234abcd)));
    ArmorBridgeReadDetail(&d);
    assert(d.sample_avatar == 99 && d.local_captured == 129);
    ArmorBridgeReadSampling(&q);
    assert(q.quota_avatar == 99 && q.projectile_remaining == 63 && q.other_remaining == 64);
    uintptr_t (*direct)(uintptr_t) = (uintptr_t (*)(uintptr_t))*getter_slot;
    assert(direct(123) == (123 ^ UINT64_C(0x987654321234abcd)));
    assert(ArmorBridgeDetach() == 1 && *getter_slot == (void *)getter && *slot == (void *)actor_name);
}
static void rules(void) {
    const uint32_t zones[6] = {2354409673u,2854072496u,411052174u,3069360885u,1688467997u,2276483060u};
    for (uint32_t weight = 0; weight < 3; ++weight) for (unsigned z = 0; z < 6; ++z) {
        int av = z == 0 ? 3 : weight == 2 ? 3 : z >= 2 && weight == 0 ? 1 : 2;
        for (unsigned ap = 0; ap < 9; ++ap) {
            float factor;
            int active = ArmorRuleEvaluate(weight, zones[z], (float)ap, &factor);
            float expected = (int)ap < av ? 0 : (int)ap == av ? 0.65f : 1;
            assert(active == 1 && factor == expected);
        }
    }
    float f;
    assert(ArmorRuleEvaluate(2, zones[1], 2.99f, &f) == 1 && f == 0);
    assert(ArmorRuleEvaluate(2, zones[1], 3.5f, &f) == 1 && f == 0.65f);
    assert(ArmorRuleEvaluate(2, zones[1], 4, &f) == 1 && f == 1);
    assert(ArmorRuleEvaluate(3, zones[0], 3, &f) == -1 && f == 1);
    assert(ArmorRuleEvaluate(1, zones[0], NAN, &f) == -1 && f == 1);
    assert(ArmorRuleEvaluate(1, zones[0], INFINITY, &f) == -1 && f == 1);
    assert(ArmorRuleEvaluate(1, zones[0], -1, &f) == -1 && f == 1);
    assert(ArmorRuleEvaluate(1, UINT32_MAX, 0, &f) == 0 && f == 1);
    assert(ArmorColliderRegion(0x37ef0820)==zones[1]);
    assert(!ArmorColliderRegion(0) && !ArmorColliderRegion(UINT32_MAX));
    for (unsigned weight=0;weight<3;weight++) for (unsigned ap=0;ap<9;ap++) {
        int av=weight==0 ? 2 : 3;
        assert(ArmorRuleEvaluateCollider(weight,zones[1],0x37ef0820,(float)ap,&f)==1);
        assert(f==((int)ap<av ? 0 : (int)ap==av ? 0.65f : 1));
        assert(ArmorRuleEvaluateCollider(weight,zones[1],0x668f6a68,(float)ap,&f)==1);
        av=weight==2 ? 3 : 2;
        assert(f==((int)ap<av ? 0 : (int)ap==av ? 0.65f : 1));
    }
    // PT-BR: Média: canela (l_knee/r_knee) e ombro (clavicle/shoulder) têm AV3; coxa, pé, cotovelo e mão ficam AV2.
    // Volume de outra região não conta; leve e pesada não mudam.
    // EN: Medium: shin (l_knee/r_knee) and shoulder (clavicle/shoulder) are AV3; thigh, foot, elbow and hand stay AV2.
    // A volume from another region does not count; light and heavy do not change.
    const struct {uint32_t zone,collider;int medium;} parts[]={
        {zones[4],0x8fd2dfec,3},{zones[5],0x3ac8154a,3},{zones[4],0x8e1c9de6,2},{zones[4],0x8eb19d6a,2},{zones[5],0x68bbeb52,2},
        {zones[2],0xc4787b4e,3},{zones[2],0x03752c98,3},{zones[3],0xb2bcd839,3},{zones[3],0x1620b2ce,3},
        {zones[2],0x1ca2cd66,2},{zones[3],0x248004f5,2},{zones[4],0x03752c98,2},{zones[2],0x8fd2dfec,2},{zones[4],0,2}};
    for (unsigned i=0;i<sizeof(parts)/sizeof(parts[0]);i++) for (unsigned weight=0;weight<3;weight++) for (unsigned ap=0;ap<6;ap++) {
        // PT-BR: Pesada: braço inteiro e pernas AV3.
        // EN: Heavy: whole arm and legs AV3.
        int av=weight==1 ? parts[i].medium : weight==0 ? 1 : 3;
        assert(ArmorRuleEvaluateCollider(weight,parts[i].zone,parts[i].collider,(float)ap,&f)==1);
        assert(f==((int)ap<av ? 0 : (int)ap==av ? 0.65f : 1));
    }
    // PT-BR: Média reforçada: antebraço AV3, mão AV2; a padrão fica com os dois em AV2.
    // EN: Reinforced medium: forearm AV3, hand AV2; standard keeps both at AV2.
    for (unsigned ap=0;ap<6;ap++) for (int reinforced=0;reinforced<2;reinforced++) {
        int forearm=reinforced ? 3 : 2;
        assert(ArmorRuleEvaluateProfile(1,zones[2],0x1ca2cd66,(float)ap,reinforced,&f)==1 && f==((int)ap<forearm ? 0 : (int)ap==forearm ? 0.65f : 1));
        assert(ArmorRuleEvaluateProfile(1,zones[3],0x31e34dac,(float)ap,reinforced,&f)==1 && f==((int)ap<forearm ? 0 : (int)ap==forearm ? 0.65f : 1));
        assert(ArmorRuleEvaluateProfile(1,zones[2],0x5c0c68d3,(float)ap,reinforced,&f)==1 && f==((int)ap<2 ? 0 : (int)ap==2 ? 0.65f : 1));
        assert(ArmorRuleEvaluateProfile(2,zones[3],0x248004f5,(float)ap,reinforced,&f)==1 && f==((int)ap<3 ? 0 : (int)ap==3 ? 0.65f : 1));
    }
    // PT-BR: Leve: ombro AV2 (padrão) / AV3 (reforçada); antebraço sem placa na padrão e AV1 na reforçada; peito AV2 nos dois.
    // EN: Light: shoulder AV2 (standard) / AV3 (reinforced); forearm unplated on standard and AV1 on reinforced; chest AV2 on both.
    for (unsigned ap=0;ap<6;ap++) for (int reinforced=0;reinforced<2;reinforced++) {
        int av=reinforced ? 3 : 2;
        assert(ArmorRuleEvaluateProfile(0,zones[2],0x03752c98,(float)ap,reinforced,&f)==1 && f==((int)ap<av ? 0 : (int)ap==av ? 0.65f : 1));
        assert(ArmorRuleEvaluateProfile(0,zones[3],0xb2bcd839,(float)ap,reinforced,&f)==1 && f==((int)ap<av ? 0 : (int)ap==av ? 0.65f : 1));
        int hand=ArmorRuleEvaluateProfile(0,zones[2],0x5c0c68d3,(float)ap,reinforced,&f);
        if (reinforced) assert(hand==1 && f==((int)ap<1 ? 0 : (int)ap==1 ? 0.65f : 1));
        else assert(hand==0 && f==1);
        assert(ArmorRuleEvaluateProfile(0,zones[1],0x37ef0820,(float)ap,reinforced,&f)==1 && f==((int)ap<2 ? 0 : (int)ap==2 ? 0.65f : 1));
    }
}
static float replay_round(float value) { return floorf(value+0.5f); }
static unsigned select_index;
static float replay_select(void *unused, const unsigned char *data) {
    (void)unused;
    float value; memcpy(&value, data+0x9c+select_index*4, 4); return value;
}
static void prediction_tests(void) {
    extern int ArmorEquipmentFixtureRead(uintptr_t,void *,size_t);
    extern void ArmorEquipmentFixtureReset(void);
    ArmorEquipmentFixtureReset();
    ArmorBridgeTestEquipment(ArmorEquipmentFixtureRead);
    unsigned char context[0x118] = {0}, damage_event[0x70] = {0}, stack[0x130] = {0}, projectile[0x40] = {0};
    uintptr_t parent = (uintptr_t)(stack+0x38);
    uintptr_t ret = UINT64_C(0x10012a266e), grandparent = UINT64_C(0x10013ad4ed);
    uintptr_t frame = (uintptr_t)context-0x580, source = (uintptr_t)projectile;
    unsigned char source_data[16] = {0}; uintptr_t source_context = (uintptr_t)source_data;
    float base_values[2] = {2,6}, extra_values[4] = {0,1,2,3}, durable = 0.25f, scale = 1.5f;
    uintptr_t base = (uintptr_t)base_values, extra = (uintptr_t)extra_values;
    memcpy((void *)parent, &ret, 8); memcpy((void *)(parent+0x50), &grandparent, 8);
    memcpy((void *)(parent-0x10), &frame, 8); memcpy((void *)(parent-0x38), &source, 8);
    memcpy((void *)(parent+0x98), &base, 8); memcpy((void *)(parent+0x90), &extra, 8);
    memcpy((void *)(parent+0x28), &source_context, 8);
    uint64_t opaque = UINT64_C(0x1122334455667788);
    memcpy(source_data+8, &opaque, 8); memcpy(damage_event+0x18, &opaque, 8);
    memcpy(projectile+0x38, &scale, 4); memcpy(context+0x4c, &durable, 4);
    put(context, 0x20, 71); put(context, 0x7c, 2854072496u);
    put(damage_event, 0, 71); put(damage_event, 0x2c, 23);
    unsigned char original[0x118]; memcpy(original, context, sizeof(original));
    unsigned char original_event[0x70]; memcpy(original_event,damage_event,sizeof(original_event));
    ArmorBridgeTestSetLocal(71);
    ArmorBridgeTestReplay((void *)replay_round, (void *)replay_select);
    ArmorBridgeEnable(1);
    // PT-BR: Testes anteriores de concorrência podem ter contado recusas por trava ocupada; compara com a base.
    // EN: Earlier concurrency tests may have counted busy-lock rejections; compare against the baseline.
    ArmorBridgePrediction p_base;ArmorBridgeReadPrediction(&p_base);
    ArmorBridgeTestPredict(context, (uintptr_t)context, parent);
    ArmorBridgeObserve(ArmorBridgeApplySite, (uintptr_t)damage_event, 0);
    ArmorBridgePrediction p;
    ArmorBridgeReadPrediction(&p);
    assert(p.rebuilt == 1 && p.matched == 1 && p.selected == 5 && p.damage == 23 && p.region == 2854072496u);
    ArmorBridgeDecision d;
    ArmorBridgeReadDecision(&d);
    assert(d.evaluated==1 && !d.unavailable && d.original==1 && d.weight==2 && d.armor_id==123 && d.projected==23);
    assert(!memcmp(context, original, sizeof(original)) && p.rejected==p_base.rejected);
    ArmorBridgeObserve(ArmorBridgeApplySite, (uintptr_t)damage_event, 0);
    ArmorBridgeReadPrediction(&p);
    assert(p.unmatched == 1 && p.matched == 1);
    grandparent = 0; memcpy((void *)(parent+0x50), &grandparent, 8);
    ArmorBridgeTestPredict(context, (uintptr_t)context, parent);
    ArmorBridgeReadPrediction(&p);
    assert(p.rejected == p_base.rejected+1 && p.rebuilt == 1);
    grandparent=UINT64_C(0x10013ad4ed); memcpy((void *)(parent+0x50),&grandparent,8);
    base_values[0]=base_values[1]=2; scale=1; memcpy(projectile+0x38,&scale,4);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadDecision(&d);
    assert(d.evaluated==2 && d.blocked==1 && d.projected==0 && d.factor==0);
    base_values[0]=base_values[1]=3;
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadDecision(&d);
    assert(d.evaluated==3 && d.reduced==1 && d.projected==14 && d.factor==0.65f);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeTestEquipment(NULL);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadDecision(&d);
    assert(d.evaluated==3 && d.unavailable==1 && d.projected==23 && d.rule==UINT32_MAX);
    assert(!memcmp(context,original,sizeof(original)));
    uint32_t unchanged; memcpy(&unchanged,damage_event+0x2c,4); assert(unchanged==23);
    assert(!memcmp(damage_event,original_event,sizeof(original_event)));
    ArmorEquipmentFixtureReset(); ArmorBridgeTestEquipment(ArmorEquipmentFixtureRead);
    ArmorBridgeProtect(1);
    base_values[0]=base_values[1]=2;
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeEffect effect;
    ArmorBridgeReadEffect(&effect);
    assert(effect.enabled && effect.applied==1 && effect.blocked==1 && !effect.refused && effect.before==23 && effect.after==0);
    unsigned char expected_event[0x70]; memcpy(expected_event,original_event,sizeof(expected_event));
    put(expected_event,0x2c,0); assert(!memcmp(damage_event,expected_event,sizeof(expected_event)));
    put(damage_event,0x2c,20); base_values[0]=base_values[1]=3;
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==2 && effect.reduced==1 && effect.after==13 && effect.before==20);
    put(damage_event,0x2c,23);
    ArmorBridgeTestIdentity(1,0);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==2 && effect.refused==1 && effect.reason==1);
    ArmorBridgeTestIdentity(1,1);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeTestIdentity(2,1);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==2 && effect.refused==2 && effect.reason==2);
    ArmorBridgeTestIdentity(1,1);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeProtect(0);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(!effect.enabled && effect.applied==2 && !memcmp(damage_event,original_event,sizeof(original_event)));
    ArmorBridgeProtect(1);
    for (unsigned i=0;i<80;++i) {
        put(damage_event,0x2c,23);
        ArmorBridgeObserveLate((uintptr_t)context,parent);
        ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    }
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==82 && effect.reduced==81 && effect.after==14);
    extern void ArmorEquipmentFixtureWeight(uint32_t);
    for (unsigned weight=0;weight<2;++weight) {
        ArmorEquipmentFixtureWeight(weight); base_values[0]=base_values[1]=2;
        put(damage_event,0x2c,23);
        ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
        ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
        ArmorBridgeReadEffect(&effect);
        assert(effect.after==14);
    }
    put(context,0x7c,411052174); ArmorEquipmentFixtureWeight(0); put(damage_event,0x2c,23);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==84 && !memcmp(damage_event,original_event,sizeof(original_event)));
    put(context,0x7c,2854072496u); ArmorEquipmentFixtureWeight(2);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==84 && !memcmp(damage_event,original_event,sizeof(original_event)));
    put(damage_event,0,72);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    uint32_t unchanged_damage; memcpy(&unchanged_damage,damage_event+0x2c,4); assert(unchanged_damage==23);
    put(damage_event,0,71); ArmorBridgeProtect(0); ArmorBridgeProtect(1);
    put(damage_event,4,4);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    memcpy(&unchanged_damage,damage_event+0x2c,4); assert(unchanged_damage==23);
    put(damage_event,4,0);
    ArmorBridgeProtect(0); ArmorBridgeProtect(1);
    extern void ArmorEquipmentFixtureDuplicate(int);
    ArmorEquipmentFixtureDuplicate(0);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
    ArmorEquipmentFixtureDuplicate(1);
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadEffect(&effect);
    assert(effect.applied==84 && effect.reason==2 && !memcmp(damage_event,original_event,sizeof(original_event)));
    ArmorEquipmentFixtureReset();
    extern void ArmorEquipmentFixtureMixed(uint32_t,uint32_t);
    extern void ArmorEquipmentFixtureSelect(uint32_t);
    const uint32_t regions[]={0x8c5570c9,0xaa1db0b0,0x1880288e,0xb6f2baf5,0x64a3fa1d,0x87b05ff4};
    // PT-BR: Linha 3 é a leve reforçada (membros AV1); a leve padrão não tem blindagem nos membros (0 = dano nativo).
    // EN: Row 3 is light reinforced (limbs AV1); light standard has no limb plating (0 = native damage).
    const unsigned expected_armor[4][6]={{3,2,0,0,0,0},{3,2,2,2,2,2},{3,3,3,3,3,3},{3,2,1,1,1,1}};
    ArmorBridgeProtect(0); ArmorBridgeProtect(1);
    ArmorTotals totals_before;ArmorBridgeReadTotals(&totals_before);
    ArmorReport report_before;ArmorBridgeReadReport(&report_before);
    uint32_t want_blocked=0,want_reduced=0,want_saved=0,want_gaps=0;
    extern void ArmorBridgeTestGapRoll(int);
    extern int ArmorBridgeTestGapSample(void);
    // PT-BR: O sorteio da fresta acerta perto de 20% das vezes.
    // EN: The gap roll hits close to 20% of the time.
    {
        ArmorBridgeTestGapRoll(-1);
        unsigned hits=0;for (unsigned i=0;i<20000;i++) hits+=ArmorBridgeTestGapSample();
        assert(hits>3400 && hits<4600);
    }
    for (unsigned pass=0;pass<4;++pass) {
        unsigned weight=pass==3 ? 0 : pass;
        ArmorEquipmentFixtureSelect(500+weight);
        ArmorEquipmentFixtureMixed(weight,(weight+1)%3);
        ArmorBridgeProfileStep(500+weight,pass==3);
        for (unsigned region=0;region<6;++region) for (unsigned ap=0;ap<=4;++ap) {
            put(context,0x7c,regions[region]); put(damage_event,0x2c,23);
            base_values[0]=base_values[1]=(float)ap;
            // PT-BR: Força a fresta a passar só com AP0; nos outros casos o sorteio falha.
            // EN: Forces the gap to pass only at AP0; otherwise the roll fails.
            ArmorBridgeTestGapRoll(ap==0);
            ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
            ArmorBridgeReadDecision(&d); ArmorBridgeReadEffect(&effect);
            uint32_t result; memcpy(&result,damage_event+0x2c,4);
            unsigned av=expected_armor[pass][region];
            // PT-BR: Membros (índices 2 a 5) da pesada: o bloqueio que ganha o sorteio passa inteiro (23); leve e média bloqueiam tudo.
            // EN: Heavy limbs (indices 2 to 5): a block that wins the roll passes in full (23); light and medium block fully.
            int gap=weight==2 && region>=2 && ap<av && ap==0;
            uint32_t expected=!av || ap>av || gap ? 23 : ap<av ? 0 : 14;
            if (gap) ++want_gaps;
            assert(d.armor_id==500+weight && d.weight==weight && d.projected==expected);
            assert(result==expected && !effect.reason);
            if (expected==0) {++want_blocked;want_saved+=23;} else if (expected==14) {++want_reduced;want_saved+=9;}
            if (gap) {ArmorTotals g;ArmorBridgeReadTotals(&g);assert(g.last_kind==4 && g.last_after==23 && g.last_prevented==0);}
            memcpy(expected_event,original_event,sizeof(expected_event)); put(expected_event,0x2c,expected);
            assert(!memcmp(damage_event,expected_event,sizeof(expected_event)));
        }
    }
    // PT-BR: Totais da missão: cada bloqueio/redução conta uma vez e soma exatamente o dano evitado.
    // EN: Mission totals: each block/reduction counts once and adds exactly the prevented damage.
    ArmorTotals totals_after;ArmorBridgeReadTotals(&totals_after);
    assert(totals_after.shots_blocked-totals_before.shots_blocked==want_blocked && want_blocked);
    assert(totals_after.shots_reduced-totals_before.shots_reduced==want_reduced && want_reduced);
    assert(totals_after.shot_prevented-totals_before.shot_prevented==want_saved);
    ArmorBridgeTestGapRoll(-1);
    assert(want_gaps==4 && totals_after.sequence-totals_before.sequence==want_blocked+want_reduced+want_gaps);
    assert(totals_after.last_kind==1 || totals_after.last_kind==2 || totals_after.last_kind==4);
    assert(totals_after.last_region==0x8c5570c9 || totals_after.last_region==0xaa1db0b0 || totals_after.last_region==0x1880288e
        || totals_after.last_region==0xb6f2baf5 || totals_after.last_region==0x64a3fa1d || totals_after.last_region==0x87b05ff4);
    // PT-BR: O relatório por região soma exatamente os mesmos bloqueios, reduções e dano evitado dos totais.
    // EN: The per-region report adds up exactly the same blocks, reductions and prevented damage as the totals.
    {
        ArmorReport report_after;ArmorBridgeReadReport(&report_after);
        uint32_t blocked=0,reduced=0,saved=0,hits=0,full=0,attacker_hits=0;
        for (unsigned g=0;g<4;g++) {
            blocked+=report_after.regions[g].blocked-report_before.regions[g].blocked;
            reduced+=report_after.regions[g].reduced-report_before.regions[g].reduced;
            full+=report_after.regions[g].full-report_before.regions[g].full;
            hits+=report_after.regions[g].hits-report_before.regions[g].hits;
            saved+=report_after.regions[g].prevented-report_before.regions[g].prevented;
        }
        for (unsigned i=0;i<report_after.attacker_count;i++) attacker_hits+=report_after.attackers[i].hits;
        for (unsigned i=0;i<report_before.attacker_count;i++) attacker_hits-=report_before.attackers[i].hits;
        assert(blocked==want_blocked && reduced==want_reduced && saved==want_saved && hits==blocked+reduced+full);
        assert(hits==4*6*5 && attacker_hits==hits && report_after.last_kind==1 && report_after.last_sequence-report_before.last_sequence==hits);
    }
    // PT-BR: Escopeta: 3 chumbos no peitoral da pesada (AP 3, 3 e 2) chegam num evento só com dano 30 e posição média;
    // cada chumbo decide pela própria penetração (65% + 65% + 0%), então o evento vira 30*130/300 = 13.
    // EN: Shotgun: 3 pellets on the heavy upper torso (AP 3, 3 and 2) arrive as one event with 30 damage and an averaged
    // position; each pellet decides by its own penetration (65% + 65% + 0%), so the event becomes 30*130/300 = 13.
    {
        ArmorEquipmentFixtureSelect(502);ArmorEquipmentFixtureMixed(2,0);ArmorBridgeProfileStep(502,0);
        put(context,0x7c,0xaa1db0b0);
        float x0;memcpy(&x0,context+0x34,4);
        const float offsets[3]={0,1,3},aps[3]={3,3,2};
        for (unsigned i=0;i<3;i++) {
            float x=x0+offsets[i];memcpy(context+0x34,&x,4);
            base_values[0]=base_values[1]=aps[i];
            ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
        }
        memcpy(context+0x34,&x0,4);
        memcpy(damage_event,original_event,sizeof(original_event));
        float mid=x0+1.3f;memcpy(damage_event+0x50,&mid,4);put(damage_event,0x2c,30);
        ArmorBridgePrediction before_merge,after_merge;ArmorBridgeReadPrediction(&before_merge);
        // PT-BR: Com diagnóstico, o impacto entra na fila do log com dano, chumbos e região.
        // EN: With diagnostics, the hit enters the log queue with damage, pellets and region.
        ArmorHitLog drain;while (ArmorBridgePopHit(&drain)) {}
        ArmorBridgeDiagnostics(1);
        ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
        ArmorBridgeDiagnostics(0);
        {
            ArmorHitLog h,last={0};int n=0;
            while (ArmorBridgePopHit(&h)) {last=h;++n;}
            assert(n>=1 && last.kind==1 && last.before==30 && last.after==13 && last.region==0xaa1db0b0
                && ((last.flags>>8)&255)==3 && ((last.flags>>16)&255)==0 && last.weight==2);
            assert(!ArmorBridgePopHit(&h));
        }
        ArmorBridgeReadPrediction(&after_merge);ArmorBridgeReadEffect(&effect);
        uint32_t merged_result;memcpy(&merged_result,damage_event+0x2c,4);
        assert(after_merge.matched==before_merge.matched+1 && after_merge.unmatched==before_merge.unmatched);
        assert(merged_result==13 && !effect.reason && effect.before==30 && effect.after==13);
        memcpy(damage_event,original_event,sizeof(original_event));
    }
    // PT-BR: Placas inclinadas: o jogo escolhe a penetração pelo ângulo (4 valores). Peitoral da pesada padrão (AV3) contra AP4 de
    // frente = dano cheio; mesmo tiro em ângulo (AP escolhida 3 < 4 de frente) = raspão, AV vira 4 e o tiro é bloqueado.
    // Na leve, o mesmo raspão não ganha nível extra (AP3 contra AV2 = dano cheio). Tronco da média sem volume do peitoral
    // é AV2: raspão vira AP2 efetivo e mantém 65% (40 -> 26); de frente, AP4 passa inteiro.
    // EN: Angled plates: the game picks penetration by angle (4 values). Heavy standard upper chest (AV3) vs head-on AP4
    // = full damage; the same shot at an angle (picked AP 3 < head-on 4) = glancing, AV becomes 4 and the shot is blocked.
    // On light armor the same glancing hit gains no extra level (AP3 vs AV2 = full damage). Medium torso without the chest
    // volume is AV2: glancing becomes effective AP2 and keeps 65% (40 -> 26); head-on, AP4 goes through in full.
    {
        const float saved_extra[4]={extra_values[0],extra_values[1],extra_values[2],extra_values[3]};
        extra_values[0]=1;extra_values[1]=0;extra_values[2]=0;extra_values[3]=0;base_values[0]=base_values[1]=3;
        put(context,0x7c,0xaa1db0b0);
        // PT-BR: Desligado (padrão): raspão na pesada não ganha nível extra (AP3 = AV3 -> 65%).
        // EN: Off (default): a glancing hit on heavy gains no extra level (AP3 = AV3 -> 65%).
        {
            ArmorEquipmentFixtureSelect(512);ArmorEquipmentFixtureMixed(2,0);ArmorBridgeProfileStep(512,0);select_index=1;
            memcpy(damage_event,original_event,sizeof(original_event));put(damage_event,0x2c,40);
            ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
            uint32_t off_result;memcpy(&off_result,damage_event+0x2c,4);assert(off_result==26);
        }
        ArmorBridgeAngledPlates(1);
        const struct {unsigned weight,index;uint32_t expected;} cases[]={{2,0,40},{2,1,0},{0,1,40},{1,1,26},{1,0,40}};
        for (unsigned c=0;c<5;c++) {
            ArmorEquipmentFixtureSelect(510+cases[c].weight);ArmorEquipmentFixtureMixed(cases[c].weight,(cases[c].weight+1)%3);
            ArmorBridgeProfileStep(510+cases[c].weight,0);select_index=cases[c].index;
            memcpy(damage_event,original_event,sizeof(original_event));put(damage_event,0x2c,40);
            ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
            uint32_t angled_result;memcpy(&angled_result,damage_event+0x2c,4);
            assert(angled_result==cases[c].expected);
        }
        ArmorBridgeAngledPlates(0);select_index=0;memcpy(extra_values,saved_extra,sizeof(saved_extra));
        memcpy(damage_event,original_event,sizeof(original_event));
    }
    ArmorEquipmentFixtureReset(); put(context,0x7c,2854072496u);
    ArmorBridgeProtect(0);ArmorBridgeProtect(1);
    assert(ArmorBridgeTestInstall(slot,(uintptr_t)ArmorTestInitReturn,(uintptr_t)ArmorTestApplyReturn)==1);
    const uint32_t colliders[]={0x37ef0820,0x668f6a68,0x58d886fb,0x5a4bbaa2,0x9b115563,0,0x8c5570c9};
    for (unsigned weight=0;weight<3;weight++) {
        ArmorEquipmentFixtureWeight(weight);
        for (unsigned volume=0;volume<7;volume++) for (unsigned ap=2;ap<=5;ap++) {
            uint32_t actor=colliders[volume]^UINT32_C(0xa5a5a5a5);
            put(context,0x24,actor);memcpy(damage_event,original_event,sizeof(original_event));
            put(damage_event,0xc,actor);base_values[0]=base_values[1]=(float)ap;
            put(context,4,UINT32_MAX);
            assert(ArmorTestInitCall(actor,context,slot)==colliders[volume]);
            assert(GetLastError()==4242);
            put(context,4,ap);put(damage_event,8,ap);
            ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
            ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
            ArmorBridgeReadDecision(&d);ArmorBridgeReadEffect(&effect);
            unsigned av=weight==2 || (weight==1 && volume==0) ? 3 : 2;
            uint32_t expected=ap<av ? 0 : ap==av ? 14 : 23;
            assert(d.projected==expected && !effect.reason);
            assert(d.collider==(volume<5 ? colliders[volume] : 0));
            memcpy(expected_event,original_event,sizeof(expected_event));
            put(expected_event,0xc,actor);put(expected_event,8,ap);put(expected_event,0x2c,expected);
            assert(!memcmp(damage_event,expected_event,sizeof(expected_event)));
        }
    }
    OwnedFixture movement;fixture_create(&movement,0x34,0x14,0x38,0x48);
    fixture_float(movement.records,4,1);
    unsigned char *movement_game=VirtualAlloc(NULL,0x4000000,MEM_RESERVE,PAGE_READWRITE);
    assert(movement_game && VirtualAlloc(movement_game+0x3326000,4096,MEM_COMMIT,PAGE_READWRITE));
    fixture_ptr(movement_game,0x3326cf8,(uintptr_t)movement.manager);
    extern void ArmorBridgeTestRuntime(uintptr_t);
    ArmorBridgeTestRuntime((uintptr_t)movement_game);ArmorEquipmentFixtureWeight(2);
    for (unsigned mode=0;mode<2;mode++) for (unsigned volume=0;volume<2;volume++) for (unsigned ap=3;ap<6;ap++) {
        ArmorBridgeHeavyStep(mode);
        assert(fixture_value(movement.records,4)==(mode ? .9f : 1));
        uint32_t actor=colliders[volume]^UINT32_C(0xa5a5a5a5);
        put(context,0x24,actor);memcpy(damage_event,original_event,sizeof(original_event));
        put(damage_event,0xc,actor);base_values[0]=base_values[1]=(float)ap;
        put(context,4,UINT32_MAX);assert(ArmorTestInitCall(actor,context,slot)==colliders[volume]);
        put(context,4,ap);put(damage_event,8,ap);
        ArmorBridgeTestPredict(context,(uintptr_t)context,parent);
        ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
        ArmorBridgeReadDecision(&d);ArmorBridgeReadEffect(&effect);
        unsigned av=mode && volume==0 ? 4 : 3;
        uint32_t expected=ap<av ? 0 : ap==av ? 14 : 23;
        assert(d.heavy_av4==mode && d.projected==expected && !effect.reason);
        uint32_t observed;memcpy(&observed,damage_event+0x2c,4);assert(observed==expected);
    }
    ArmorBridgeHeavyStep(0);assert(fixture_value(movement.records,4)==1);
    fixture_u32(movement.descriptors,20,0);assert(!ArmorBridgeHeavyStep(1));
    uint32_t actor=colliders[0]^UINT32_C(0xa5a5a5a5);
    put(context,0x24,actor);memcpy(damage_event,original_event,sizeof(original_event));put(damage_event,0xc,actor);
    base_values[0]=base_values[1]=3;put(context,4,UINT32_MAX);
    assert(ArmorTestInitCall(actor,context,slot)==colliders[0]);put(context,4,3);put(damage_event,8,3);
    ArmorBridgeTestPredict(context,(uintptr_t)context,parent);ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)damage_event,0);
    ArmorBridgeReadDecision(&d);assert(!d.heavy_av4 && d.projected==14);
    ArmorBridgeHeavyStep(0);ArmorBridgeTestRuntime(0);fixture_destroy(&movement);
    assert(VirtualFree(movement_game,0,MEM_RELEASE));
    put(context,0x24,0);put(context,4,0);ArmorEquipmentFixtureReset();
    puts("Volumes aprovados: pesada AV3 no tronco; media AV3 somente em chest; leve AV1 nos membros; nome incompatível usa regra regional e apenas dano do alvo local alterado.");
    ArmorBridgeProtect(0);
    assert(!memcmp(context,original,sizeof(original)));
}
static void extension_tests(void) {
    extern void ArmorEquipmentFixtureReset(void);
    extern void ArmorEquipmentFixtureWeight(uint32_t);
    ArmorCombatSample sample;
    while (ArmorBridgePopCombat(&sample)) {}
    // PT-BR: Sem diagnóstico a fila bruta fica vazia; com diagnóstico as cotas originais valem.
    // EN: Without diagnostics the raw queue stays empty; with diagnostics the original quotas apply.
    {
        unsigned char quiet[0x118]={0},quiet_stack[0xa0]={0};
        put(quiet,0,6);put(quiet,0x20,71);ArmorBridgeTestSetLocal(71);ArmorBridgeEnable(1);
        ArmorBridgeDiagnostics(0);ArmorBridgeObserveLate((uintptr_t)quiet,(uintptr_t)quiet_stack);
        assert(!ArmorBridgePopCombat(&sample));
    }
    ArmorBridgeDiagnostics(1);
    unsigned char impact[0x118]={0}, event[0x70]={0}, stack[0xa0]={0};
    unsigned char params[20]={0};
    put(impact,0,6);put(impact,0x20,71);put(impact,0x7c,2854072496u);
    float raw=60,ap=4,scale=1.5f,extra_ap=2;
    memcpy(impact+0x98,&raw,4);memcpy(impact+0x9c,&ap,4);
    memcpy(params+8,&scale,4);memcpy(params+16,&extra_ap,4);
    uintptr_t parent=UINT64_C(0x10012a2cf7),parameters=(uintptr_t)params;
    memcpy(stack,&parent,8);memcpy(stack+0x90,&parameters,8);
    unsigned char original[sizeof(impact)];memcpy(original,impact,sizeof(impact));
    ArmorBridgeTestSetLocal(71);ArmorBridgeEnable(1);
    for (unsigned i=0;i<20;++i) ArmorBridgeObserveLate((uintptr_t)impact,(uintptr_t)stack);
    put(event,0,71);put(event,4,6);put(event,0x2c,40);
    unsigned char before[sizeof(event)];memcpy(before,event,sizeof(event));
    ArmorBridgeObserve(ArmorBridgeApplySite,(uintptr_t)event,0);
    unsigned late=0,applied=0;
    while (ArmorBridgePopCombat(&sample)) {
        assert(sample.kind==6 && sample.victim==71);
        if (sample.stage==1) {
            ++late;assert(sample.parent==0x12a2cf7 && sample.extra_valid);
            assert(sample.origin.sequence && sample.origin.kind==6 && sample.origin.region==2854072496u && sample.origin.flags&ARMOR_ORIGIN_CAUSE);
            assert(!memcmp(sample.data,impact,sizeof(impact)) && !memcmp(sample.extra,params,20));
        } else { ++applied;assert(sample.stage==2 && !memcmp(sample.data,event,sizeof(event)));
            assert(sample.origin.cause==0 && sample.origin.flags&ARMOR_ORIGIN_CAUSE && !(sample.origin.flags&ARMOR_ORIGIN_LINKED)); }
    }
    assert(late==16 && applied==1 && !memcmp(original,impact,sizeof(impact)) && !memcmp(before,event,sizeof(event)));
    ArmorOriginStats origin_stats;ArmorBridgeReadOrigin(&origin_stats);
    assert(origin_stats.built>=20 && origin_stats.recorded>=1 && origin_stats.unlinked>=1);
    extern void ArmorLocalRuntimeTests(void);
    ArmorLocalRuntimeTests();
    puts("Extensoes aprovadas: diagnostico corpo a corpo com copia posterior, cotas e nenhum dano alterado; ajustes locais independentes de municao.");
}
static void safe_copy_tests(void) {
    extern int ArmorSafeCopy(void *,const void *,size_t);
    unsigned char source[64],target[64]={0};
    for (unsigned i=0;i<64;i++) source[i]=(unsigned char)(i*7+1);
    assert(ArmorSafeCopy(target,source,64) && !memcmp(target,source,64));
    memset(target,0,64);assert(!ArmorSafeCopy(target,(const void *)(uintptr_t)0x1000,8));
    unsigned char *page=VirtualAlloc(NULL,8192,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);DWORD old;
    assert(page && VirtualProtect(page+4096,4096,PAGE_NOACCESS,&old));
    memset(page,0x5a,4096);
    assert(ArmorSafeCopy(target,page+4096-8,8) && target[0]==0x5a);
    assert(!ArmorSafeCopy(target,page+4096-8,16));
    assert(!ArmorSafeCopy(target,page+4096,4));
    assert(VirtualFree(page,0,MEM_RELEASE));
    // PT-BR: Mede o ganho frente a ReadProcessMemory (informativo).
    // EN: Measure the gain versus ReadProcessMemory (informational).
    LARGE_INTEGER f,t0,t1,t2;QueryPerformanceFrequency(&f);SIZE_T got;uint64_t value=0,sink=0;
    QueryPerformanceCounter(&t0);
    for (unsigned i=0;i<200000;i++) {ReadProcessMemory(GetCurrentProcess(),&sink,&value,8,&got);sink+=value+1;}
    QueryPerformanceCounter(&t1);
    for (unsigned i=0;i<200000;i++) {ArmorSafeCopy(&value,&sink,8);sink+=value+1;}
    QueryPerformanceCounter(&t2);
    printf("Leitura protegida aprovada: falhas de acesso devolvem 0; ReadProcessMemory %.0f ns, copia protegida %.0f ns por leitura.\n",
        (double)(t1.QuadPart-t0.QuadPart)*1e9/f.QuadPart/200000,(double)(t2.QuadPart-t1.QuadPart)*1e9/f.QuadPart/200000);
}
int main(void) {
    safe_copy_tests();
    extern void ArmorMovementTests(void);
    ArmorMovementTests();
    setvbuf(stdout,NULL,_IONBF,0);
    extern void ArmorErgonomicsTests(void);
    ArmorErgonomicsTests();
    extern void ArmorSwimmingTests(void);
    ArmorSwimmingTests();
    extern void ArmorPrivateSessionTests(void);
    ArmorPrivateSessionTests();
    extern void ArmorDamageCommitTests(void);
    ArmorDamageCommitTests();
    extern void ArmorMeleeTests(void);
    ArmorMeleeTests();
    extern void ArmorOriginTests(void);
    ArmorOriginTests();
    extern void ArmorEquipmentTests(void);
    ArmorEquipmentTests();
    extern void ArmorReplayTests(void);
    ArmorReplayTests();
    rules();
    assert(ArmorBridgeInstall() == -1);
    slot = VirtualAlloc(NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    assert(slot);
    *slot = (void *)actor_name;
    DWORD previous;
    assert(VirtualProtect(slot, 4096, PAGE_READONLY, &previous));
    assert(ArmorBridgeTestInstall(slot, (uintptr_t)ArmorTestInitReturn, (uintptr_t)ArmorTestApplyReturn) == 13);
    assert(ArmorBridgeTestExchange(slot, (void *)ArmorActorHook, (void *)actor_name) == -1);
    assert(*slot == (void *)actor_name);
    assert(VirtualProtect(slot, 4096, PAGE_READWRITE, &previous));
    assert(ArmorBridgeTestInstall(slot, (uintptr_t)ArmorTestInitReturn, (uintptr_t)ArmorTestApplyReturn) == 1);
    assert(*slot == (void *)ArmorActorHook);
    put(hit, 0, 0); put(hit, 0x20, 71); put(event, 0, 71); put(event, 4, 0); put(event, 0x2c, 90);
    unsigned char before_hit[sizeof(hit)], before_event[sizeof(event)];
    memcpy(before_hit, hit, sizeof(hit)); memcpy(before_event, event, sizeof(event));
    ArmorBridgeEnable(1);
    uint32_t actor = UINT32_C(2354409673) ^ UINT32_C(0xa5a5a5a5);
    assert(ArmorTestInitCall(actor, hit, slot) == UINT32_C(2354409673));
    assert(GetLastError() == 4242);
    ArmorBridgeStats s;
    ArmorBridgeReadStats(&s);
    assert(s.installed == 1 && s.stage == 1 && s.victim == 71 && s.zone == 2354409673u);
    assert(s.init_seen == 1 && s.captured == 1 && s.protection_active == 0);
    assert(ArmorTestApplyCall(actor, event, slot) == UINT32_C(2354409673));
    assert(GetLastError() == 4242);
    ArmorBridgeReadStats(&s);
    assert(s.stage == 2 && s.damage == 90 && s.apply_seen == 1);
    assert(ArmorTestApplyCall(actor, (void *)1, slot) == UINT32_C(2354409673));
    assert(GetLastError() == 4242);
    ArmorBridgeReadStats(&s);
    assert(s.read_failed == 1);
    LONG before = InterlockedCompareExchange(&original_calls, 0, 0);
    uint32_t (*call)(uint32_t) = (uint32_t (*)(uint32_t))*slot;
    assert(call(actor) == UINT32_C(2354409673));
    assert(InterlockedCompareExchange(&original_calls, 0, 0) == before + 1);
    ArmorBridgeEnable(0);
    assert(ArmorTestInitCall(actor, hit, slot) == UINT32_C(2354409673));
    ArmorBridgeReadStats(&s);
    assert(s.init_seen == 1);
    ArmorBridgeEnable(1);
    before = InterlockedCompareExchange(&original_calls, 0, 0);
    HANDLE threads[4];
    for (unsigned i = 0; i < 4; ++i) { threads[i] = CreateThread(NULL, 0, worker, NULL, 0, NULL); assert(threads[i]); }
    assert(WaitForMultipleObjects(4, threads, TRUE, INFINITE) == WAIT_OBJECT_0);
    for (unsigned i = 0; i < 4; ++i) CloseHandle(threads[i]);
    assert(InterlockedCompareExchange(&original_calls, 0, 0) == before + 80000);
    ArmorBridgeReadStats(&s);
    assert(s.init_seen == 40001 && s.apply_seen == 40002 && s.captured <= 128 && !s.protection_active);
    assert(!memcmp(hit, before_hit, sizeof(hit)) && !memcmp(event, before_event, sizeof(event)));
    late_tests();
    prediction_tests();
    extension_tests();
    extern void ArmorMeleeIntegrationTests(void);
    ArmorMeleeIntegrationTests();
    assert(ArmorBridgeDetach() == 1 && *slot == (void *)actor_name);
    assert(ArmorBridgeTestInstall(slot, (uintptr_t)ArmorTestInitReturn, (uintptr_t)ArmorTestApplyReturn) == 1);
    *slot = (void *)actor_name;
    assert(ArmorBridgeDetach() == 31 && *slot == (void *)actor_name);
    puts("Regras dos 3 perfis/6 regioes aprovadas; 120.000 chamadas concorrentes preservaram retorno, erro e dados; captura tardia local e restauracao aprovadas. Nenhum jogo utilizado.");
    return 0;
}
