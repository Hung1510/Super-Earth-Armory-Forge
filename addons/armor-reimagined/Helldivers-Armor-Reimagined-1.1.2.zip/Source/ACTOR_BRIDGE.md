# Blindagem regional — notas técnicas (1.0.0)

Perfis **padrão/reforçado por modelo**, selecionados na lista de armaduras do Arsenal. Todas começam no padrão; escolhas antigas `av4` passam a reforçado. As três categorias agora têm seletor, com prévia ao passar o mouse e números coloridos. A pesada padrão passa a ter **velocidade −5%**; a reforçada conserva −10% e recebe ergonomia −15%.

## Aviso para identificar novos ataques

**Desligado na 0.18.0.** O aviso de ataque físico desconhecido serviu para a coleta de dados e não aparece mais no menu; a identificação passou a ser automática pelo atacante (ID de rede) e pela distância.

A mesma causa avisa novamente após 60 segundos; entre bipes há pelo menos oito segundos. O código aparece também no log em **Aviso de ataque não identificado**, com sequência, avatar, dano e resultado do som. Anote o inimigo e o golpe que acabou de acontecer. O aviso não comprova que toda Ability física é corpo a corpo, nem identifica automaticamente a espécie.

Uma fila própria de 16 eventos guarda apenas valores, preservando um evento desconhecido mesmo se outro golpe conhecido chegar antes da leitura. Em excesso, descarta o mais antigo. A fila é consumida mesmo com avisos desligados; mudança de avatar invalida os avisos anteriores. A mensagem usa recursos temporários validados e fecha ao expirar/desligar/perder o mundo. Sem fonte disponível, o som e o registro ainda funcionam. O aviso não inclui o ataque na lista de redução e não altera seu dano.

A nova mensagem e o som passaram nos testes isolados; a visibilidade da fonte durante missão e a reprodução sonora ainda precisam de teste real após instalar e reiniciar.

## Regras

| Categoria e modo | Proteção de tiros | Redução adicional corpo a corpo | Ergonomia da principal | Movimento | Fôlego na água |
| --- | --- | --- | --- | --- | --- |
| Leve padrão | Tronco AV2; membros AV1 | Tronco 15%; membros 0% | +10% | **+10%** | Reposição local, se habilitada |
| Leve reforçada | Tronco AV2; membros AV1 | Tronco 15%; membros 10% | Original | **+5%** | Contagem original |
| Média padrão | Peitoral superior identificado AV3; restante e membros AV2 | Peitoral 20%; restante e membros 15% | Original | Original | Contagem original |
| Média reforçada | Peitoral superior identificado AV3; restante e membros AV2 | Peitoral 25%; restante e membros 20% | −10% | Original | Contagem original |
| Pesada padrão | Tronco AV3; membros AV2 | Tronco 20%; membros 15% | −10% | −5% | Contagem original |
| Pesada reforçada | Peitoral superior identificado AV4; restante AV3; membros AV2 | Tronco 30%; membros 20% | −15% | −10% | Contagem original |

Todos os capacetes mantêm AV3 para tiros. Corpo a corpo na cabeça e regiões desconhecidas permanece original. As porcentagens são redução do dano nativo já calculado, com arredondamento inteiro para baixo; não substituem o cálculo nativo de armadura/passivos. Exemplo de dano 40: pesada padrão 32 no tronco/34 nos membros; reforçada 28/32. Leve reforçada nos membros: 36.

**Corpo a corpo (0.17.2):** recebem a redução regional (1) as oito causas físicas já validadas; (2) **pares inimigo+golpe confirmados em partida**, com o atacante resolvido pelo **ID de rede** a até **6 m** (Devastator, Devastator MK3, Rocket Devastator, Female Agiator, Overseer, Fleshmob, Berserker, Marauder, Scout Strider, Bile Spewer MK2, Stalker, Hulk Bruiser); e (3) **qualquer outro golpe físico** (Ability, elemento 0, caminho validado) com atacante a até **3 m**. Nas regras (2) e (3) o causador do golpe precisa ser o próprio atacante: o **respingo do cuspe de ácido** vem da bolha (causador diferente) e fica sempre com dano nativo, enquanto o golpe de perto dos Cuspidores é reduzido. Charger (todas as variantes), Bile Titan e Impaler (inclusive tentáculo) ficam sempre com dano nativo, inclusive nas causas listadas. **Golpe letal continua letal:** se o dano nativo do golpe for maior ou igual à vida máxima do personagem, não há redução. Sem atacante resolvido, posição legível ou ligação única, o dano permanece original. Cabeça continua original. Explosão, fogo e tiros não entram.

A categoria vem da maioria estrita das peças do catálogo, conferida contra o equipamento local; não vem da classificação numérica de armadura. Revestimento Extra e passivos originais permanecem. Empates, dados inválidos, mudança de identidade e escolha de outro modelo não autorizam o perfil reforçado. Não são criadas hitboxes nem alterados seus contornos.

## Instalação e seleção

1. Feche o jogo.
2. Importe `Helldivers-Regional-Armor-1.0.0.zip` no Arsenal, substituindo a versão anterior; deixe apenas uma versão habilitada.
3. Habilite Bingus Shared Loader, respeite a prioridade indicada por ele e faça Deploy.
4. Reinicie o jogo; importar um ZIP não troca a DLL já carregada.

A única dependência de execução é **Bingus Shared Loader**. Ammunition não é utilizado como localizador nem necessário para os efeitos.

Na lista detalhada de armaduras, clique no indicador compacto de proteção para escolher padrão ou reforçado. A escolha pertence ao modelo visualizado e só atua quando ele estiver equipado. Passar o mouse compara valores sem gravar; clicar salva. Os capacetes mostram somente a proteção da cabeça. Bônus aparecem em verde, penalidades em vermelho, título em amarelo e valores neutros claros. A GUI fecha ao sair da lista, trocar a tela ou perder os recursos temporários; capas não recebem indicador.

Em **MODS → Regional Armor** há apenas o **idioma** (inglês padrão; português brasileiro e espanhol). Proteção, ergonomia, natação da leve e descrições do Arsenal ficam sempre ligadas; para voltar ao jogo original, desabilite o mod no Arsenal. **Diagnóstico detalhado** (origem de cada golpe, posições, resumo por causa) só liga quando existir o arquivo vazio `%LOCALAPPDATA%\CowboyBingus\Helldivers2\RegionalArmorDiagnostics.txt`; apague-o para desligar (verificação a cada 10 s). O aviso sonoro de ataque desconhecido ficou desligado.

Proteção controla tiros, resistência adicional aos golpes reconhecidos e movimento da pesada. Ergonomia tem controle separado. Natação somente repõe fôlego da leve padrão, se habilitada: a reforçada desabilita a reposição e perde o bônus de ergonomia, preservando as animações e o movimento originais na água. Não ressuscita personagem sem ar nem cria um temporizador exagerado.

Preferências: `%LOCALAPPDATA%\CowboyBingus\Helldivers2\RegionalArmorProfiles.txt`, formato `0x12345678=reinforced`. Padrão remove a linha do modelo. Leitura aceita `av4`/`av3` antigos; nova gravação usa `reinforced`. Gravação Unicode temporária e substituição somente após concluir; falhas preservam a escolha anterior e mostram aviso.

## Aplicação local e segurança da integração

**Jogue em lobby privado ou com amigos.** Os efeitos atuam só no personagem local, mas o mod não foi validado em partidas públicas e outros jogadores podem expulsar quem o usa. Sessão, host, lobby, ausência de transição, identidade e equipamento precisam ser confirmados. A autorização é renovada em 250 ms e expira em 750 ms. Host/convidado com outro jogador ainda exigem validação real; testes isolados de seleção não comprovam a autoridade da rede.

A proteção troca somente os quatro bytes do dano em evento+0x2C, após conferir o evento inteiro e uma associação única de 13 palavras entre impacto e dano. Capturas próprias têm limite de 128 e expiram em um segundo. Alterar perfil, equipamento, sessão ou desativar invalida associações; não há leitura tardia do ponteiro do impacto. Corpo a corpo reconfirma causa física conhecida e construtor/caminho de produção aceitos. Explosão, ácido, impacto e causas desconhecidas não recebem a redução adicional.

O volume `chest` (`0x37ef0820`) pertence ao peitoral superior. Na média, volume ausente ou incompatível usa AV2 e a porcentagem do restante do tronco; na pesada reforçada usa AV3. A associação inicial agora também acompanha tipo físico 6, sem misturá-lo com tiros. Essa extensão foi testada fora do jogo e ainda requer confirmação em partida para o bônus de peitoral da média.

AP abaixo da proteção bloqueia dano à vida; igualdade mantém 65%, arredondado para baixo; pelo menos um nível acima mantém dano nativo. AP é reconstruída no caminho de projéteis identificado, não lida diretamente como AP final. AV4 fica restrita ao peitoral pesado identificado e só é liberada com penalidade de movimento confirmada na mesma entidade/modelo. Se isso falhar, mantém AV3 e a porcentagem padrão de corpo a corpo da pesada.

Movimento usa apenas o fator da instância local em registro+4, produto de modificadores nativos. Padrão multiplica por 0,95; reforçada por 0,90. Antes de reaplicar/trocar restaura o fator anterior; se o terreno o multiplicou depois, remove somente nosso multiplicador. Não altera os outros fatores. Desligar proteção/mod, sair da missão ou equipar outra categoria restaura o ajuste. Mods que substituam esse campo diretamente ainda exigem teste de compatibilidade.

Ergonomia ajusta quatro campos da principal selecionada e segurada, com coeficientes nativos conferidos, identidade local e valores relidos. Restaura antes da atualização nativa e reaplica sobre a instância atual; não acumula multiplicadores. Fôlego usa o contador local de afogamento, limitado ao máximo original, sem escrita em definições compartilhadas ou registros de outro jogador. Sangue, contusão, empurrão e demais efeitos visuais permanecem originais.

## Logs e validação

Log: `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\HelldiversArmorBridge.log`.

- **Movimento da pesada**: fator antes/previsto/relido, instância, aplicações e restaurações; padrão deve mostrar `antes×0,95`, reforçada `antes×0,90`.
- **Corpo a corpo regional**: causa, região, volume, categoria, modo, percentual mantido e dano antes/depois; contador de reduções comprova escrita. Cabeça permanece intacta.
- **Ergonomia**: valor nativo e previsto/relido; fatores leve 1,10/1,00, média 1,00/0,90, pesada 0,90/0,85.
- **Natação experimental**: contador local, reposições e motivo de suspensão.

Suítes nativa e LuaJIT/DLL passaram fora do jogo: seis perfis, capturas binárias reais com eventos sintetizados por categoria/volume, troca de perfil entre captura/evento recusada, restauração de movimento com terreno, isolamento remoto, ABI, três idiomas, persistência/migração e GUI. Inclui regressões de 120 mil chamadas concorrentes e módulos anteriores. Ver `VALIDACAO_1.0.0.md`.

O pacote não foi instalado nem testado em partida nesta preparação. Ainda é necessário validar: velocidade −5% e troca de modos em caminhada/corrida/terreno; nova resistência por categoria e volume; reforçada leve interrompendo o fôlego; ergonomia reforçada; autoridade host/convidado e peitoral AV4 contra AP3/AP4. A sessão anterior confirmou perfil AV4, movimento 0,90 e bloqueio AP2, mas AP2 não distingue AV3 de AV4.

## Compatibilidade e desenvolvimento

São aceitos os binários e consumidores conferidos:

- `game.dll`: `2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E`.
- `helldivers2.exe`: `F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06`.

Preserva adaptadores de ponteiros de dados sem editar instruções do jogo. A DLL extraída por hash fica residente até fechar o processo. Transmog precisa de validação específica. Fontes/testes acompanham o ZIP; pesquisa e código extraído do jogo não são distribuídos.

Compilação nesta pasta:

    python build_bridge.py --test
    python build_bridge.py
    python tests/run_actor.py --lua-dll "C:/Program Files (x86)/Steam/steamapps/common/Helldivers 2/bin/lua51.dll"
    python build_actor_addon.py --output "../../dist/Helldivers-Regional-Armor-1.0.0.zip"

Zig 0.15.0; empacotador Bingus fixado em `3d7e3a120828178573ef1ee0a5c7eeae4a951865`; GUID `bd17fd49-74ea-49d0-af16-9d5601c4c389`, recurso `mods/lobao/armor_probe` preservados.

## Coleta de origem na 0.15.0

O log acrescenta `Origem do impacto` com produtor, ID do causador/dono e tipos de entidade. Quando o tipo consta no catálogo incluído, registra também seu nome técnico; ausência de nome permanece explícita. Usa os campos do próprio evento, sem adivinhar por dano, posição ou último inimigo visto. O leitor consulta no máximo 64 posições do mapa de entidades e reconfirma identidade e cabeçalho; falha de leitura não interfere na proteção. A cota diagnóstica é renovada a cada dez segundos, além da troca de avatar.

Não usa a mensagem de morte para atribuir golpes anteriores: o evento fatal não demonstra o causador de cada impacto. Os nomes ainda precisam de confirmação em partida com esta versão. Nenhuma dependência adicional ao Bingus.

## Coleta de origem na 0.16.0

As regras de dano são as mesmas da 0.15.0; esta versão melhora apenas a coleta para preparar novas reduções.

- **Nome do atacante:** o tipo agora vem do descritor do gerenciador de vida, a mesma chave do catálogo de nomes técnicos. A 0.15.0 lia o mapa de entidades, cujo tipo é outro e por isso nunca encontrava nomes. O tipo antigo continua no log como `tipo mapa causador`.
- **Distância:** posição do atacante e do personagem local lidas no registro de unidades do executável, com geração de 8 bits conferida e acessor de cena verificado byte a byte. Aparece como `distância=… m` ou `indisponível`.
- **Ligação exata:** cada impacto local recebe uma `sequência`; o evento de dano é ligado ao preparo pela mesma chave de 13 palavras usada na proteção, sem tempo nem proximidade. Correspondências múltiplas ficam como `ambíguo=1` e não são escolhidas. O evento herda produtor, região e distância do preparo.
- **Resumo de causa:** a cada 10 s o log grava uma linha por combinação tipo/elemento/causa/produtor/atacante que mudou: eventos, ligados, se está na lista corpo a corpo, reduzidos, dano mín/médio/máx, distância mín/média/máx e regiões atingidas. O resumo cobre todos os eventos locais, inclusive os de causa zero, independentemente das cotas de diagnóstico. Limite de 128 combinações por sessão; o excedente é contado.
- `marcas` (hex): 1/2 tipo do mapa do causador/dono, 4/8 descritor de vida do causador/dono, 16/32 posição do causador/local, 64 chave calculada, 128 causa lida, 256 ligado, 512 ambíguo, 1024/2048 ID do causador/dono completado pela geração do motor (`id completo causador`), 4096 alcance do golpe, 8192/16384 tipo/posição pela hipótese de ID de rede.

O resumo serve para escolher candidatos (por exemplo, causa com distância média abaixo de 3 m, sempre do mesmo atacante e ligada ao produtor físico), **não** libera redução automaticamente. Para relatórios: `python tools/analyze_combat_log.py HelldiversArmorBridge.log --output relatorio.json` gera `eventos_com_origem` e `resumo_causas`.

Posições e nomes vêm de referências do mesmo build (`F5FEE03DCFDB`) e passaram em testes isolados; ainda precisam de confirmação em partida.
