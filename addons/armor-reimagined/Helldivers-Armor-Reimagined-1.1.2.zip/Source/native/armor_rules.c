#include "armor_rules.h"
#include <math.h>

uint32_t ArmorColliderRegion(uint32_t collider) {
    static const uint32_t groups[6][6]={
        {0x8c5570c9,0x8c5570c9,0xe9ecca21,0,0,0},
        {0xaa1db0b0,0x37ef0820,0x668f6a68,0x58d886fb,0x5a4bbaa2,0x9b115563},
        {0x1880288e,0xc4787b4e,0x03752c98,0x1ca2cd66,0x5c0c68d3,0},
        {0xb6f2baf5,0xb2bcd839,0x1620b2ce,0x248004f5,0x31e34dac,0},
        {0x64a3fa1d,0x8eb19d6a,0x8fd2dfec,0xecd5bb39,0x8e1c9de6,0},
        {0x87b05ff4,0x46ddad11,0x3ac8154a,0x68bbeb52,0x748f4281,0}
    };
    if (!collider) return 0;
    for (unsigned i=0;i<6;i++) for (unsigned j=1;j<6;j++)
        if (groups[i][j]==collider) return groups[i][0];
    return 0;
}

int ArmorRuleEvaluate(uint32_t weight, uint32_t zone, float penetration, float *factor) {
    if (!factor) return -1;
    *factor = 1.0f;
    if (weight > 2 || !isfinite(penetration) || penetration < 0) return -1;
    int armor;
    if (zone == UINT32_C(2354409673)) armor = 3;
    else if (zone == UINT32_C(2854072496)) armor = weight == 2 ? 3 : 2;
    else if (zone == UINT32_C(411052174) || zone == UINT32_C(3069360885)) {
        // PT-BR: Braços: a pesada tem AV3 do ombro até a mão (decisão de 12/10/2026, com ergonomia -20%).
        // EN: Arms: heavy has AV3 from shoulder to hand (decided 2026-10-12, with -20% ergonomics).
        armor = weight == 0 ? 1 : weight == 2 ? 3 : 2;
    } else if (zone == UINT32_C(1688467997) || zone == UINT32_C(2276483060)) {
        // PT-BR: Pernas (leg_left/leg_right): a pesada tem AV3 (decisão de 11/10/2026, escopeta AP3 acertava as pernas).
        // EN: Legs (leg_left/leg_right): heavy has AV3 (decided 2026-10-11, AP3 shotgun pellets kept hitting the legs).
        armor = weight == 0 ? 1 : weight == 2 ? 3 : 2;
    } else return 0;
    *factor = penetration < armor ? 0.0f : penetration < armor + 1 ? 0.65f : 1.0f;
    return 1;
}

int ArmorRuleEvaluateCollider(uint32_t weight,uint32_t zone,uint32_t collider,float penetration,float *factor) {
    int result=ArmorRuleEvaluate(weight,zone,penetration,factor);
    // PT-BR: Na média, AV3 exige chest identificado; tronco sem identificação conserva AV2.
    // EN: Medium armor requires an identified chest for AV3; unidentified torso retains AV2.
    if (result==1 && weight==1 && zone==UINT32_C(0xaa1db0b0) && collider==UINT32_C(0x37ef0820))
        *factor=penetration<3 ? 0.0f : penetration<4 ? 0.65f : 1.0f;
    // PT-BR: Na média, a canela (volume l_knee/r_knee, do joelho ao tornozelo) tem AV3; coxa, pé e perna sem volume
    // identificado conservam AV2 (decisão de 11/10/2026).
    // EN: Medium armor gives the shin (l_knee/r_knee volume, knee to ankle) AV3; thigh, foot and a leg without an
    // identified volume keep AV2 (decided 2026-10-11).
    if (result==1 && weight==1 && (zone==UINT32_C(1688467997) || zone==UINT32_C(2276483060))
        && (collider==UINT32_C(0x8fd2dfec) || collider==UINT32_C(0x3ac8154a)))
        *factor=penetration<3 ? 0.0f : penetration<4 ? 0.65f : 1.0f;
    // PT-BR: Na média e na pesada, o ombro (volumes l_clavicle/r_clavicle e l_shoulder/r_shoulder, até o cotovelo) tem AV3.
    // EN: Medium and heavy armor give the shoulder (l_clavicle/r_clavicle and l_shoulder/r_shoulder volumes, up to the elbow) AV3.
    if (result==1 && (weight==1 || weight==2) && (zone==UINT32_C(411052174) || zone==UINT32_C(3069360885))
        && (collider==UINT32_C(0xc4787b4e) || collider==UINT32_C(0xb2bcd839)
            || collider==UINT32_C(0x03752c98) || collider==UINT32_C(0x1620b2ce)))
        *factor=penetration<3 ? 0.0f : penetration<4 ? 0.65f : 1.0f;
    return result;
}
static int shoulder(uint32_t zone,uint32_t collider) {
    return (zone==UINT32_C(411052174) || zone==UINT32_C(3069360885))
        && (collider==UINT32_C(0xc4787b4e) || collider==UINT32_C(0xb2bcd839)
            || collider==UINT32_C(0x03752c98) || collider==UINT32_C(0x1620b2ce));
}
int ArmorRuleEvaluateProfile(uint32_t weight,uint32_t zone,uint32_t collider,float penetration,int reinforced,float *factor) {
    int result=ArmorRuleEvaluateCollider(weight,zone,collider,penetration,factor);
    // PT-BR: Leve: ombro (clavicle/shoulder) AV2 na padrão e AV3 na reforçada; o peito continua AV2 (decisão de 11/10/2026).
    // EN: Light: shoulder (clavicle/shoulder) AV2 on standard and AV3 on reinforced; the chest stays AV2 (decided 2026-10-11).
    if (result==1 && weight==0 && shoulder(zone,collider)) {
        int armor=reinforced ? 3 : 2;
        *factor=penetration<armor ? 0.0f : penetration<armor+1 ? 0.65f : 1.0f;
        return 1;
    }
    // PT-BR: Leve padrão não tem blindagem nos membros: o tiro mantém o dano nativo. A reforçada mantém AV1.
    // EN: Light standard has no limb plating: the shot keeps native damage. Reinforced keeps AV1.
    if (result==1 && !reinforced && weight==0 && zone!=UINT32_C(0xaa1db0b0) && zone!=UINT32_C(2354409673)) {*factor=1.0f;return 0;}
    // PT-BR: Média reforçada: antebraço (volumes l_elbow/r_elbow) AV3; a mão continua AV2 (decisão de 12/10/2026, ergonomia -10%).
    // EN: Reinforced medium: forearm (l_elbow/r_elbow volumes) AV3; the hand stays AV2 (decided 2026-10-12, -10% ergonomics).
    if (result==1 && reinforced && weight==1 && (zone==UINT32_C(411052174) || zone==UINT32_C(3069360885))
        && (collider==UINT32_C(0x1ca2cd66) || collider==UINT32_C(0x31e34dac)))
        *factor=penetration<3 ? 0.0f : penetration<4 ? 0.65f : 1.0f;
    if (result==1 && reinforced && weight==2 && zone==UINT32_C(0xaa1db0b0) && collider==UINT32_C(0x37ef0820))
        *factor=penetration<4 ? 0.0f : penetration<5 ? 0.65f : 1.0f;
    return result;
}
