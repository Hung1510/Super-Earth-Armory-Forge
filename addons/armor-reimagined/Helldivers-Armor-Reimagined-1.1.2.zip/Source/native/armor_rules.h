#pragma once
#include <stdint.h>
int ArmorRuleEvaluateProfile(uint32_t weight,uint32_t zone,uint32_t collider,float penetration,int reinforced,float *factor);
int ArmorRuleEvaluate(uint32_t weight, uint32_t zone, float penetration, float *factor);
uint32_t ArmorColliderRegion(uint32_t collider);
int ArmorRuleEvaluateCollider(uint32_t weight, uint32_t zone, uint32_t collider, float penetration, float *factor);
