#include "actor_bridge.h"
#include "projectile_replay.h"
#include "armor_equipment.h"
#include "armor_rules.h"
#include "damage_commit.h"
#include "melee.h"
#include "damage_source.h"
#include "ergonomics.h"
#include "swimming.h"
#include "handling.h"
#include "private_session.h"
#include <windows.h>
#include <bcrypt.h>
#include <string.h>
#include <math.h>
#include "spin_lock.h"

void *ArmorActorOriginal;
void *ArmorLateOriginal;
uintptr_t ArmorBridgeInitSite, ArmorBridgeApplySite;
uintptr_t ArmorBridgeLateSite;
static void **actor_slot;
static void **late_slot;
static uintptr_t game_base;
static volatile LONG installed, enabled, status, slot_protection;
static volatile LONG late_installed, local_entity, local_init_seen, local_apply_seen;
static volatile LONG late_seen, local_late_seen, local_captured, local_read_failed, detail_lock;
static ArmorBridgeDetail detail;
static volatile LONG projectile_seen, other_seen, projectile_captured, other_captured;
static uint32_t quota_avatar = UINT32_MAX, projectile_attempts, other_attempts;
static ArmorRound round_projectile;
static float (*select_penetration)(void *, const unsigned char *);
static volatile LONG rebuilt, rejected, matched, unmatched, ambiguous, prediction_lock;
static ArmorBridgePrediction prediction;
static volatile LONG equipment_lock, decision_lock;
static ArmorEquipmentCache equipment_cache;
static ArmorBridgeDecision decision={.weight=UINT32_MAX,.rule=UINT32_MAX};
static volatile LONG protection, protection_epoch;
static volatile LONG heavy_mode,heavy_avatar=-1,heavy_armor=-1;
static volatile LONG profile_lock;
static struct {uint32_t avatar,armor,weight;int reinforced;} profile;
static ArmorBridgeEffect effect;
static ArmorUnknownAttack unknown_attacks[16];
static uint32_t unknown_head,unknown_count,unknown_sequence;
static volatile LONG totals_sequence,totals_blocked,totals_reduced,totals_shot_prevented,totals_melee,totals_melee_prevented;
static volatile LONG totals_last_kind,totals_last_prevented,totals_last_region,totals_last_collider,totals_last_after,totals_gaps;
static ArmorReport report;
static volatile LONG report_lock;
// PT-BR: Momento do último dano real recebido (tiro/golpe que não foi totalmente bloqueado), para a lentidão ao levar golpe.
// EN: Time of the last real damage taken (shot/strike not fully blocked), for the slow-on-hit.
static volatile LONG64 hurt_at;
static uint64_t now_ms(void);
static unsigned region_group(uint32_t region) {
    // PT-BR: Hashes dos nomes de região do jogo: head, body, arm_left/arm_right, leg_left/leg_right.
    // EN: Hashes of the game's region names: head, body, arm_left/arm_right, leg_left/leg_right.
    if (region==0x8c5570c9) return 0;
    if (region==0xaa1db0b0) return 1;
    if (region==0x1880288e || region==0xb6f2baf5) return 2;
    if (region==0x64a3fa1d || region==0x87b05ff4) return 3;
    return 4;
}
static uint64_t origin_type(const ArmorOrigin *o) {
    if (!o) return 0;
    if ((o->flags&ARMOR_ORIGIN_NET_HEALTH) && o->net_type) return o->net_type;
    if (o->flags&ARMOR_ORIGIN_DEALER_HEALTH) return o->dealer_health_type;
    if (o->flags&ARMOR_ORIGIN_OWNER_HEALTH) return o->owner_health_type;
    return 0;
}
// PT-BR: kind 1 = tiro, 2 = corpo a corpo; after é o dano que realmente ficou (igual a before quando nada mudou).
// EN: kind 1 = shot, 2 = melee; after is the damage that actually remained (equal to before when nothing changed).
static void record_outcome(uint32_t kind,uint32_t avatar,uint32_t region,const ArmorOrigin *o,uint32_t before,uint32_t after) {
    if (!before) return;
    if (after>before) after=before;
    if (after) InterlockedExchange64(&hurt_at,(LONG64)now_ms());
    if (!ArmorTake(&report_lock)) return;
    uint32_t saved=before-after;unsigned g=region_group(region);
    if (g<4) {
        ArmorRegionStats *r=&report.regions[g];
        ++r->hits;
        if (!after) ++r->blocked;else if (after<before) ++r->reduced;else ++r->full;
        r->taken+=after;r->prevented+=saved;
    }
    uint64_t type=origin_type(o);unsigned i;
    for (i=0;i<report.attacker_count;++i) if (report.attackers[i].type==type) break;
    if (i==report.attacker_count) {
        if (i<16) {report.attackers[i].type=type;++report.attacker_count;}
        else ++report.overflow;
    }
    if (i<16) {++report.attackers[i].hits;report.attackers[i].taken+=after;report.attackers[i].prevented+=saved;}
    report.last_type=type;report.last_avatar=avatar;report.last_region=region;
    report.last_before=before;report.last_after=after;report.last_kind=kind;++report.last_sequence;
    InterlockedExchange(&report_lock,0);
}
// PT-BR: tipo 1 = tiro bloqueado, 2 = tiro reduzido, 3 = golpe reduzido, 4 = tiro que passou pela fresta de um membro da
// pesada (só aviso; conta como reduzido se parte da rajada foi evitada); a sequência sobe por último.
// EN: kind 1 = shot blocked, 2 = shot reduced, 3 = strike reduced, 4 = shot that got through a heavy limb gap (flash only;
// counts as reduced when part of the volley was prevented); the sequence is raised last.
static void count_prevented(LONG kind,uint32_t before,uint32_t after,uint32_t region,uint32_t collider) {
    LONG saved=(LONG)(before>after ? before-after : 0);
    InterlockedExchangeAdd(kind==3 ? &totals_melee_prevented : &totals_shot_prevented,saved);
    // PT-BR: Fresta (4) só conta como reduzido se parte da rajada ainda foi evitada.
    // EN: A gap (4) only counts as reduced when part of the volley was still prevented.
    if (kind!=4 || saved>0) InterlockedIncrement(kind==1 ? &totals_blocked : kind==3 ? &totals_melee : &totals_reduced);
    if (kind==4) InterlockedIncrement(&totals_gaps);
    InterlockedExchange(&totals_last_after,(LONG)after);
    InterlockedExchange(&totals_last_kind,kind);InterlockedExchange(&totals_last_prevented,saved);
    InterlockedExchange(&totals_last_region,(LONG)region);InterlockedExchange(&totals_last_collider,(LONG)collider);
    InterlockedIncrement(&totals_sequence);
}
static ArmorMeleeStats melee;
static volatile LONG melee_lock,melee_prepared,melee_rejected;
#ifdef ARMOR_BRIDGE_TEST
static ArmorEquipmentReader equipment_reader;
static uint32_t test_network=1, test_session_confirmed=1;
static uintptr_t test_runtime_base;
#endif
static volatile LONG init_seen, apply_seen, captured, dropped, read_failed, sample_lock;
static ArmorBridgeStats sample;
_Static_assert(sizeof(ArmorOrigin)==160,"origin ABI");
_Static_assert(sizeof(ArmorCauseStats)==112,"cause ABI");
_Static_assert(sizeof(ArmorCombatSample)==512,"combat ABI");
_Static_assert(sizeof(ArmorTotals)==56,"totals ABI");
_Static_assert(sizeof(ArmorReport)==520,"report ABI");
static ArmorCombatSample combat_queue[64];
static volatile LONG combat_lock;
static unsigned combat_read,combat_write,combat_count,combat_avatar=UINT32_MAX;
static unsigned combat_quota[2][16];
static uint64_t combat_window;
static uintptr_t exe_base;
static volatile LONG diagnostics;
// PT-BR: Fila de impactos para o log (128, a mais antiga é descartada quando cheia). Só enche com diagnóstico ligado.
// EN: Hit queue for the log (128, the oldest is dropped when full). Only fills with diagnostics on.
static ArmorHitLog hit_ring[128];
static uint32_t hit_head,hit_count,hit_sequence;
static volatile LONG hit_lock,hit_dropped;
static void push_hit(ArmorHitLog *h) {
    if (!InterlockedCompareExchange(&diagnostics,0,0) || !ArmorTake(&hit_lock)) return;
    h->sequence=++hit_sequence;
    if (hit_count==128) {hit_head=(hit_head+1)%128;--hit_count;InterlockedIncrement(&hit_dropped);}
    hit_ring[(hit_head+hit_count)%128]=*h;++hit_count;
    InterlockedExchange(&hit_lock,0);
}
static int read_at(uintptr_t address, void *out, SIZE_T size);
static ArmorSettingsDump settings_ring[32];
static uint32_t settings_head,settings_count,settings_sequence;
static volatile LONG settings_lock;
static void push_settings(uint32_t kind,uint32_t region,uint32_t damage,uintptr_t base,uintptr_t extra,uintptr_t projectile) {
    if (!InterlockedCompareExchange(&diagnostics,0,0)) return;
    ArmorSettingsDump d;memset(&d,0,sizeof(d));
    d.kind=kind;d.region=region;d.damage=damage;
    if (base && !read_at(base,d.base,sizeof(d.base))) memset(d.base,0,sizeof(d.base));
    if (extra && !read_at(extra,d.extra,sizeof(d.extra))) memset(d.extra,0,sizeof(d.extra));
    if (projectile && !read_at(projectile,d.projectile,sizeof(d.projectile))) memset(d.projectile,0,sizeof(d.projectile));
    if (!ArmorTake(&settings_lock)) return;
    d.sequence=++settings_sequence;
    if (settings_count==32) {settings_head=(settings_head+1)%32;--settings_count;}
    settings_ring[(settings_head+settings_count)%32]=d;++settings_count;
    InterlockedExchange(&settings_lock,0);
}
BRIDGE_API int ArmorBridgePopSettings(ArmorSettingsDump *out) {
    if (!out || !ArmorTake(&settings_lock)) return 0;
    int ok=settings_count>0;
    if (ok) {*out=settings_ring[settings_head];settings_head=(settings_head+1)%32;--settings_count;}
    InterlockedExchange(&settings_lock,0);
    return ok;
}
BRIDGE_API int ArmorBridgeKeyDown(int virtual_key) {
#ifdef ARMOR_BRIDGE_TEST
    (void)virtual_key;return 0;
#else
    return virtual_key>0 && virtual_key<256 && (GetAsyncKeyState(virtual_key)&0x8000) ? 1 : 0;
#endif
}
BRIDGE_API int ArmorBridgePopHit(ArmorHitLog *out) {
    if (!out || !ArmorTake(&hit_lock)) return 0;
    int ok=hit_count>0;
    if (ok) {*out=hit_ring[hit_head];hit_head=(hit_head+1)%128;--hit_count;}
    InterlockedExchange(&hit_lock,0);
    return ok;
}
static volatile LONG origin_sequence,origin_built,origin_linked,origin_ambiguous,origin_unlinked,origin_link_busy,origin_recorded;

extern int ArmorSafeCopy(void *destination, const void *source, size_t size);
static int read_at(uintptr_t address, void *out, SIZE_T size) {
    if (!out || address < 65536 || address >= UINT64_C(0x800000000000)-size || !size || size > 4096) return 0;
    // PT-BR: Cópia protegida em vez de chamada ao sistema por campo; mesmo resultado em falha de acesso.
    // EN: Guarded copy instead of a system call per field; same result on access faults.
    return ArmorSafeCopy(out,(const void *)address,size);
}
static uint32_t word(const unsigned char *data, SIZE_T at) {
    uint32_t value;
    memcpy(&value, data + at, 4);
    return value;
}
static void capture_combat(uintptr_t context, unsigned stage, unsigned kind, uint32_t avatar, uintptr_t parent_at,
                           const ArmorOrigin *origin) {
    if (kind>=16 || !InterlockedCompareExchange(&diagnostics,0,0) || !ArmorTake(&combat_lock)) return;
    uint64_t now=GetTickCount64();
    if (combat_avatar!=avatar || now-combat_window>=10000) {
        memset(combat_quota,0,sizeof(combat_quota));combat_avatar=avatar;combat_window=now;
    }
    if (combat_quota[stage-1][kind]>=16 || combat_count==64) {
        InterlockedExchange(&combat_lock,0);return;
    }
    ArmorCombatSample record={.stage=stage,.kind=kind,.victim=avatar};
    size_t size=stage==1 ? sizeof(record.data) : 0x70;
    if (!read_at(context,record.data,size) || word(record.data,stage==1 ? 0x20 : 0)!=avatar
        || word(record.data,stage==1 ? 0 : 4)!=kind) { InterlockedExchange(&combat_lock,0);return; }
    uintptr_t parent=0,parameters=0;
    if (stage==1 && parent_at && read_at(parent_at,&parent,8) && game_base
        && parent>=game_base && parent<game_base+0x4744000) {
        record.parent=(uint32_t)(parent-game_base);
        // PT-BR: O tipo 6 recebe ajustes após este ponto; registra a cópia sem tratá-la como AP final.
        // EN: Kind 6 receives adjustments after this point; record the copy without treating it as final AP.
        if (record.parent==0x12a2cf7 && read_at(parent_at+0x90,&parameters,8)
            && read_at(parameters,record.extra,sizeof(record.extra))) {
            record.extra_valid=1;
            InterlockedExchange(&combat_lock,0);
            push_settings(kind,word(record.data,0x7c),0,parameters,0,0);
            if (!ArmorTake(&combat_lock)) return;
        }
    }
    // PT-BR: Origem já resolvida no impacto; a fila só copia valores, sem nova leitura de ponteiros.
    // EN: Origin was resolved at impact time; the queue only copies values, with no further pointer reads.
    record.dealer=word(record.data,stage==1 ? 0x84 : 0x10);
    record.owner=word(record.data,stage==1 ? 0x104 : 0x14);
    if (origin) {
        record.origin=*origin;record.producer=origin->producer;
        record.dealer_type=origin->dealer_type;record.owner_type=origin->owner_type;
    }
    combat_queue[combat_write]=record;combat_write=(combat_write+1)%64;
    ++combat_count;++combat_quota[stage-1][kind];
    InterlockedExchange(&combat_lock,0);
}
BRIDGE_API int ArmorBridgePopCombat(ArmorCombatSample *out) {
    if (!out || !ArmorTake(&combat_lock)) return 0;
    if (!combat_count) { InterlockedExchange(&combat_lock,0);return 0; }
    *out=combat_queue[combat_read];combat_read=(combat_read+1)%64;--combat_count;
    InterlockedExchange(&combat_lock,0);return 1;
}
static int read_ptr(uintptr_t address, uintptr_t *out);
static uint32_t resolve_local(void);
static uint32_t resolve_identity(uint32_t *network, uint32_t *session_confirmed);
static uint32_t game_rva(uintptr_t address) {
    return game_base && address>=game_base && address<game_base+0x4744000 ? (uint32_t)(address-game_base) : 0;
}
static void build_hit_origin(const unsigned char *hit,uint32_t avatar,uintptr_t parent_at,ArmorOrigin *o) {
    memset(o,0,sizeof(*o));
    o->kind=word(hit,0);o->victim=avatar;o->region=word(hit,0x7c);
    o->dealer=word(hit,0x84);o->owner=word(hit,0x104);
    uintptr_t parent=0,producer=0,source;
    if (parent_at && read_at(parent_at,&parent,8)) o->parent=game_rva(parent);
    if (parent_at && read_at(parent_at+0x50,&producer,8)) o->producer=game_rva(producer);
    if (o->parent==0x12a2cf7 && read_at(parent_at+0x88,&o->cause,4)) o->flags|=ARMOR_ORIGIN_CAUSE;
    int full=InterlockedCompareExchange(&diagnostics,0,0)!=0;
    ArmorOriginResolve(game_base,exe_base,read_at,o,full);
    if (full) {
        if (ArmorHitReach(hit,&o->reach)) o->flags|=ARMOR_ORIGIN_REACH;
        ArmorHitGaps(hit,o);
    }
    o->sequence=(uint32_t)InterlockedIncrement(&origin_sequence);
    InterlockedIncrement(&origin_built);
    // PT-BR: Mesma chave de 13 palavras da proteção; liga preparo e evento sem usar tempo ou proximidade.
    // EN: Same 13-word key as protection; links preparation and event without timing or proximity.
    unsigned char copy[0x118];ArmorReplayKey key;
    memcpy(copy,hit,sizeof(copy));
    if (!parent_at || !read_ptr(parent_at+0x28,&source) || !read_at(source+8,copy+0x110,8)) return;
    o->flags|=ARMOR_ORIGIN_KEY;ArmorReplayHitKey(copy,&key);
    if (!ArmorOriginRemember(&key,o,GetTickCount64())) InterlockedIncrement(&origin_link_busy);
}
static void build_event_origin(const unsigned char *event,ArmorOrigin *o) {
    ArmorReplayKey key;ArmorReplayEventKey(event,&key);
    int found=ArmorOriginTake(&key,GetTickCount64(),o);
    if (found==1) {o->flags|=ARMOR_ORIGIN_LINKED;InterlockedIncrement(&origin_linked);}
    else {
        memset(o,0,sizeof(*o));
        if (found==-2) {o->flags|=ARMOR_ORIGIN_AMBIGUOUS;InterlockedIncrement(&origin_ambiguous);}
        else InterlockedIncrement(&origin_unlinked);
        o->kind=word(event,4);o->victim=word(event,0);o->dealer=word(event,0x10);o->owner=word(event,0x14);
        if (InterlockedCompareExchange(&diagnostics,0,0)) ArmorOriginResolve(game_base,exe_base,read_at,o,1);
    }
    // PT-BR: A causa publicada no evento prevalece sobre a lida durante a preparação.
    // EN: The cause published in the event takes precedence over the one read during preparation.
    o->cause=word(event,0x60);o->flags|=ARMOR_ORIGIN_CAUSE;
}
static void record_cause(const unsigned char *event,uintptr_t context,const ArmorOrigin *o) {
    uint32_t before=word(event,0x2c),after=before;
    if (!read_at(context+0x2c,&after,4)) after=before;
    uint32_t known=word(event,4)==6 && ArmorMeleeKnown(6,word(event,8),o->cause);
    if (ArmorCauseRecord(o,word(event,8),before,known,after<before)) InterlockedIncrement(&origin_recorded);
}
// PT-BR: Placas inclinadas são opcionais (menu MODS, desligadas por padrão): fortes demais contra Devastadores.
// EN: Angled plates are optional (MODS menu, off by default): too strong against Devastators.
static volatile LONG angled_plates;
// PT-BR: Impactos de fogo direto deixados com dano nativo.
// EN: Direct fire hits left with native damage.
static volatile LONG fire_native;
BRIDGE_API uint32_t ArmorBridgeFireNative(void) {return (uint32_t)InterlockedCompareExchange(&fire_native,0,0);}
BRIDGE_API uint32_t ArmorBridgeReadGaps(void) {return (uint32_t)InterlockedCompareExchange(&totals_gaps,0,0);}
// PT-BR: Episódio de queimadura: começa no primeiro fogo e termina após 1,5 s sem fogo. Causador 32767 = fogo no chão,
// causador = dono (a própria entidade do jogador) = queimando, outro causador = jato/impacto direto. O valor em +0x98 é
// o bruto antes do passivo; a vida (registro de 28 bytes do gerenciador) é lida no início e no fim para medir o dano real.
// Só observa; nunca altera o dano.
// EN: Burn episode: starts at the first fire and ends after 1.5 s without fire. Dealer 32767 = ground fire,
// dealer = owner (the player's own entity) = burning, any other dealer = direct stream/hit. The +0x98 value is raw,
// before the passive; health (the manager's 28-byte record) is read at start and end to measure the real damage.
// Observation only; never changes damage.
static volatile LONG fire_lock;
static ArmorFireStats fire_open,fire_done;
static uint64_t fire_start,fire_last;
static int read_equipment(ArmorEquipment *out, int strict);
#ifndef ARMOR_BRIDGE_TEST
static int lookup(uintptr_t header, uint32_t key, uint32_t *out);
#endif
static int health_record(uint32_t avatar,uint32_t out[7]) {
    memset(out,0,7*sizeof(uint32_t));
#ifdef ARMOR_BRIDGE_TEST
    (void)avatar;return 0;
#else
    uintptr_t health,ext;uint32_t live,index;
    return game_base && read_ptr(game_base+0x3326688,&health) && read_at(health+0x1020,&live,4) && live && live<=4096
        && lookup(health+0x1030,avatar,&index) && index<live && read_ptr(health+0x1060,&ext)
        && read_at(ext+(uintptr_t)index*28,out,28);
#endif
}
static void fire_close(uint64_t now) {
    if (!fire_open.ticks || now-fire_last<1500) return;
    health_record(fire_open.avatar,fire_open.health_end);
    fire_open.duration_ms=(uint32_t)(fire_last-fire_start);
    fire_open.sequence=fire_done.sequence+1;fire_done=fire_open;
    memset(&fire_open,0,sizeof(fire_open));
}
static void observe_fire(const unsigned char *hit,uint32_t local) {
    if (!ArmorTake(&fire_lock)) return;
    uint64_t now=now_ms();
    fire_close(now);
    float damage;memcpy(&damage,hit+0x98,4);
    if (!isfinite(damage)) damage=0;
    if (!fire_open.ticks) {
        ArmorEquipment eq;
        fire_start=now;fire_open.first_damage=damage;fire_open.avatar=local;
        if (read_equipment(&eq,0)) {fire_open.armor_id=eq.id;fire_open.weight=eq.weight;} else fire_open.weight=UINT32_MAX;
        health_record(local,fire_open.health_start);
    }
    uint32_t dealer=word(hit,0x84),owner=word(hit,0x104);
    unsigned how=dealer==32767 ? 2 : dealer==owner || dealer==local ? 3 : 1;
    if (!fire_open.ignition) fire_open.ignition=how;
    if (how==2) ++fire_open.ground;else if (how==3) ++fire_open.burning;else ++fire_open.direct;
    ++fire_open.ticks;fire_open.damage+=damage;fire_last=now;
    InterlockedExchange(&fire_lock,0);
}
BRIDGE_API void ArmorBridgeReadFire(ArmorFireStats *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (!ArmorTake(&fire_lock)) return;
    fire_close(now_ms());*out=fire_done;
    InterlockedExchange(&fire_lock,0);
}
// PT-BR: Frestas nas juntas (opção ligada por padrão, só pesada): tiro bloqueado no braço ou na perna tem 20% de chance
// de passar pela junta com o dano inteiro.
// EN: Joint gaps (option on by default, heavy only): a blocked shot on an arm or leg has a 20% chance to get through the
// joint with full damage.
static volatile LONG arm_gaps=1;
BRIDGE_API void ArmorBridgeArmGaps(int value) {InterlockedExchange(&arm_gaps,value ? 1 : 0);}
// PT-BR: Sorteio da fresta (xorshift, chamado só sob decision_lock). Nos testes pode ser forçado.
// EN: Gap roll (xorshift, only called under decision_lock). Tests can force it.
static uint32_t gap_state;
#ifdef ARMOR_BRIDGE_TEST
static int gap_forced=-1;
void ArmorBridgeTestGapRoll(int value) {gap_forced=value;}
#endif
static int gap_roll(void) {
#ifdef ARMOR_BRIDGE_TEST
    if (gap_forced>=0) return gap_forced;
#endif
    if (!gap_state) gap_state=(uint32_t)GetTickCount64()^UINT32_C(0x9e3779b9);
    gap_state^=gap_state<<13;gap_state^=gap_state>>17;gap_state^=gap_state<<5;
    return gap_state%100<20;
}
#ifdef ARMOR_BRIDGE_TEST
int ArmorBridgeTestGapSample(void) {return gap_roll();}
#endif
static int arm_region(uint32_t region) {
    return region==UINT32_C(0x1880288e) || region==UINT32_C(0xb6f2baf5) || region==UINT32_C(0x64a3fa1d) || region==UINT32_C(0x87b05ff4);
}
BRIDGE_API void ArmorBridgeAngledPlates(int value) {InterlockedExchange(&angled_plates,value ? 1 : 0);}
BRIDGE_API void ArmorBridgeDiagnostics(int value) {
    // PT-BR: Diagnóstico desligado mantém a proteção e o resumo; omite fila bruta e leituras de pesquisa.
    // EN: Diagnostics off keeps protection and the summary; skips the raw queue and research reads.
    InterlockedExchange(&diagnostics,value ? 1 : 0);
}
BRIDGE_API int ArmorBridgeReadCause(uint32_t index,ArmorCauseStats *out) {
    if (!out) return 0;
    memset(out,0,sizeof(*out));
    return ArmorCauseRead(index,out);
}
BRIDGE_API void ArmorBridgeReadOrigin(ArmorOriginStats *out) {
    if (!out) return;
    out->built=(uint32_t)InterlockedCompareExchange(&origin_built,0,0);
    out->linked=(uint32_t)InterlockedCompareExchange(&origin_linked,0,0);
    out->ambiguous=(uint32_t)InterlockedCompareExchange(&origin_ambiguous,0,0);
    out->unlinked=(uint32_t)InterlockedCompareExchange(&origin_unlinked,0,0);
    out->link_busy=(uint32_t)InterlockedCompareExchange(&origin_link_busy,0,0);
    out->recorded=(uint32_t)InterlockedCompareExchange(&origin_recorded,0,0);
    out->overflow=ArmorCauseOverflow();out->version=ArmorCauseVersion();
}
static int read_equipment(ArmorEquipment *out, int strict) {
    if (!ArmorTake(&equipment_lock)) return 0;
    if (strict) memset(&equipment_cache,0,sizeof(equipment_cache));
#ifdef ARMOR_BRIDGE_TEST
    int ok=equipment_reader && ArmorEquipmentRead(game_base,equipment_reader,&equipment_cache,out);
#else
    int ok=ArmorEquipmentRead(game_base,read_at,&equipment_cache,out);
#endif
    InterlockedExchange(&equipment_lock,0);
    return ok;
}
static int heavy_active(uint32_t avatar,uint32_t armor,uint32_t weight) {
    return weight==2 && InterlockedCompareExchange(&heavy_mode,0,0)
        && (uint32_t)InterlockedCompareExchange(&heavy_avatar,0,0)==avatar
        && (uint32_t)InterlockedCompareExchange(&heavy_armor,0,0)==armor && ArmorMovementValid(avatar);
}
static int profile_active(uint32_t avatar,uint32_t armor,uint32_t weight) {
    if (!ArmorTake(&profile_lock)) return 0;
    int result=profile.reinforced && profile.avatar==avatar && profile.armor==armor && profile.weight==weight;
    InterlockedExchange(&profile_lock,0);return result;
}
static int melee_reinforced(uint32_t avatar,uint32_t armor,uint32_t weight) {
    return profile_active(avatar,armor,weight) && (weight!=2 || heavy_active(avatar,armor,weight));
}
static void capture_melee(const unsigned char *hit,uintptr_t context,uintptr_t parent_at,const ArmorOrigin *origin) {
    if (!game_base || !InterlockedCompareExchange(&protection,0,0)) return;
    uintptr_t parent,producer,source;
    uint32_t cause;
    if (!read_at(parent_at,&parent,8) || parent!=game_base+0x12a2cf7) return;
    if (!read_at(parent_at+0x50,&producer,8)
        || (producer!=game_base+0x7d247e && producer!=game_base+0x7d2e3c)
        || !ArmorMeleeRoute((uint32_t)(parent-game_base),(uint32_t)(producer-game_base))
        || !read_at(parent_at+0x88,&cause,4)) {InterlockedIncrement(&melee_rejected);return;}
    // PT-BR: Causa listada ou golpe físico de atacante confirmado a até 3 m pelo ID de rede.
    // EN: Listed cause, or a physical strike from an attacker confirmed within 3 m through its network ID.
    float distance=0;
    int known=ArmorMeleeKnown(word(hit,0),word(hit,4),cause);
    int proximity=known || word(hit,0)!=6 || word(hit,4) ? 0 : ArmorMeleeProximity(origin,cause,&distance);
    if (!known && !proximity) return;
    // PT-BR: Exclusões valem também para causas listadas quando o atacante foi resolvido pelo ID de rede.
    // EN: Exclusions also apply to listed causes when the attacker was resolved through its network ID.
    if (known && origin && origin->flags&ARMOR_ORIGIN_NET_HEALTH && ArmorMeleeExcluded(origin->net_type)) return;
    ArmorMeleeSample record={.cause=cause,.proximity=(uint32_t)proximity,.distance=distance};
    record.hit.epoch=(uint32_t)InterlockedCompareExchange(&protection_epoch,0,0);
    uint32_t avatar=resolve_identity(&record.hit.avatar_network,&record.hit.session_confirmed);
    ArmorEquipment equipment;
    if (avatar!=word(hit,0x20) || !record.hit.session_confirmed || !read_equipment(&equipment,0)) return;
    unsigned char copy[0x118];memcpy(copy,hit,sizeof(copy));
    // PT-BR: O construtor ainda preencherá a causa e o ID opaco; antecipa apenas na cópia própria.
    // EN: The constructor will fill the cause and opaque ID later; anticipate only in the owned copy.
    if (!read_ptr(parent_at+0x28,&source) || !read_at(source+8,copy+0x110,8)) {
        InterlockedIncrement(&melee_rejected);return;
    }
    ArmorReplayHitKey(copy,&record.hit.key);
    record.hit.armor_id=equipment.id;record.hit.weight=equipment.weight;record.hit.equipment_valid=1;
    record.hit.region=word(hit,0x7c);
    record.hit.reinforced=melee_reinforced(avatar,equipment.id,equipment.weight);
    uint32_t collider=ArmorReplayTakeCollider(context,hit,GetTickCount64());
    record.hit.collider=ArmorColliderRegion(collider)==record.hit.region ? collider : 0;
    if (ArmorMeleeRemember(&record,GetTickCount64())) InterlockedIncrement(&melee_prepared);
    else InterlockedIncrement(&melee_rejected);
}
BRIDGE_API int ArmorBridgePopUnknown(ArmorUnknownAttack *out) {
    if (!out || !ArmorTake(&melee_lock)) return 0;
    int found=unknown_count!=0;
    if (found) {*out=unknown_attacks[unknown_head];unknown_head=(unknown_head+1)%16;--unknown_count;}
    InterlockedExchange(&melee_lock,0);return found;
}
static void record_unknown(const unsigned char *event) {
    uint32_t network,session;
    if (word(event,8) || !word(event,0x60) || !word(event,0x2c)
        || resolve_identity(&network,&session)!=word(event,0) || !session) return;
    // PT-BR: Copia só valores para uma fila própria limitada; o aviso não guarda ponteiros nem modifica dano.
    // EN: Copy values only into a bounded owned queue; notifications retain no pointers and never modify damage.
    if (unknown_count==16) {unknown_head=(unknown_head+1)%16;--unknown_count;}
    unknown_attacks[(unknown_head+unknown_count++)%16]=(ArmorUnknownAttack){
        ++unknown_sequence,word(event,0),word(event,0x60),word(event,0x2c),6,word(event,8)};
}
#ifdef ARMOR_BRIDGE_TEST
static uint32_t test_max_health=1000;
#else
static int lookup(uintptr_t header, uint32_t key, uint32_t *out);
#endif
static uint32_t local_max_health(uint32_t avatar) {
#ifdef ARMOR_BRIDGE_TEST
    (void)avatar;return test_max_health;
#else
    // PT-BR: Vida máxima do avatar local no gerenciador de vida (extensão +0x1060, passo 28, campo +20).
    // EN: Local avatar max health from the health manager (extension +0x1060, stride 28, field +20).
    uintptr_t health,ext;uint32_t live,index,maximum;
    if (!game_base || !read_ptr(game_base+0x3326688,&health) || !read_at(health+0x1020,&live,4) || !live || live>4096
        || !lookup(health+0x1030,avatar,&index) || index>=live || !read_ptr(health+0x1060,&ext)
        || !read_at(ext+(uintptr_t)index*28+20,&maximum,4) || maximum<50 || maximum>2000) return 0;
    return maximum;
#endif
}
static void match_melee(const unsigned char *event,uintptr_t context,const ArmorOrigin *origin) {
    if (word(event,4)!=6 || !InterlockedCompareExchange(&protection,0,0)
        || !ArmorTake(&melee_lock)) return;
    melee.victim=word(event,0);melee.cause=word(event,0x60);
    melee.before=melee.after=word(event,0x2c);melee.reason=0;
    melee.keep_percent=100;
    melee.region=0;melee.armor_id=0;melee.weight=UINT32_MAX;melee.collider=0;melee.reinforced=0;
    melee.distance=0;
    ArmorReplayKey key;ArmorMeleeSample record;
    int known=ArmorMeleeKnown(6,word(event,8),melee.cause),found=0;
    if (known || !word(event,8)) {ArmorReplayEventKey(event,&key);found=ArmorMeleeMatch(&key,melee.cause,GetTickCount64(),&record);}
    if (!known && !(found==1 && record.proximity)) {
        if (found==-2) ++melee.ambiguous;
        ++melee.unknown;melee.reason=5;record_unknown(event);
    }
    else {
        if (found!=1) {if (found==-2) ++melee.ambiguous;melee.reason=6;}
        else {
            ++melee.matched;melee.region=record.hit.region;melee.armor_id=record.hit.armor_id;
            melee.weight=record.hit.weight;
            melee.collider=record.hit.collider;melee.reinforced=record.hit.reinforced;melee.distance=record.distance;
            melee.keep_percent=ArmorMeleeKeepPercent(record.hit.weight,record.hit.region,record.hit.collider,record.hit.reinforced);
            uint32_t network,session;ArmorEquipment current;
            uint32_t avatar=resolve_identity(&network,&session);
            if (!session || !record.hit.session_confirmed) melee.reason=1;
            else if (avatar!=melee.victim || network!=record.hit.avatar_network || !record.hit.equipment_valid
                || !read_equipment(&current,1) || current.id!=record.hit.armor_id || current.weight!=record.hit.weight) melee.reason=2;
            else if ((uint32_t)InterlockedCompareExchange(&protection_epoch,0,0)!=record.hit.epoch) melee.reason=3;
            else if (melee.before && melee.keep_percent<100) {
                ArmorEquipment final;uint32_t network_after,session_after,maximum=local_max_health(avatar);
                // PT-BR: Golpe que mata com vida cheia continua letal; vida máxima ilegível não bloqueia a redução.
                // EN: A strike lethal at full health stays lethal; unreadable max health does not block reduction.
                melee.max_health=maximum;
                if (maximum && melee.before>=maximum) {melee.reason=7;++melee.lethal;}
                else if (resolve_identity(&network_after,&session_after)!=avatar || network_after!=network || !session_after
                    || !read_equipment(&final,0) || final.id!=current.id || final.weight!=current.weight) melee.reason=2;
                else if (!InterlockedCompareExchange(&enabled,0,0) || !InterlockedCompareExchange(&protection,0,0)
                    || (uint32_t)InterlockedCompareExchange(&protection_epoch,0,0)!=record.hit.epoch
                    || melee_reinforced(avatar,current.id,current.weight)!=(int)record.hit.reinforced) melee.reason=3;
                else if (!ArmorMeleeDamageCommit(context,event,ArmorMeleeDamage(melee.before,melee.keep_percent),(int)record.proximity)) melee.reason=4;
                else {
                    melee.after=ArmorMeleeDamage(melee.before,melee.keep_percent);++melee.applied;
                    count_prevented(3,melee.before,melee.after,melee.region,melee.collider);
                    if (record.proximity) ++melee.proximity;
                    if (record.proximity==ARMOR_MELEE_BY_ATTACKER) ++melee.by_attacker;
                }
            }
        }
        if (melee.reason && melee.reason!=7) ++melee.refused;
    }
    uint32_t melee_victim=melee.victim,melee_region=melee.region,melee_before=melee.before,melee_after=melee.after;
    ArmorHitLog h={0};
    h.kind=2;h.element=word(event,8);h.cause=melee.cause;h.region=melee.region;h.collider=melee.collider;h.weight=melee.weight;
    h.reinforced=melee.reinforced;h.before=melee.before;h.after=melee.after;h.reason=melee.reason;h.ap=0;
    h.distance=melee.distance ? melee.distance : (origin ? origin->net_distance : 0);h.attacker=origin_type(origin);
    InterlockedExchange(&melee_lock,0);
    push_hit(&h);
    if (word(event,8)==0) record_outcome(2,melee_victim,melee_region,origin,melee_before,melee_after);
}
BRIDGE_API void ArmorBridgeReadMelee(ArmorMeleeStats *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (!ArmorTake(&melee_lock)) return;
    *out=melee;
    out->prepared=(uint32_t)InterlockedCompareExchange(&melee_prepared,0,0);
    out->rejected=(uint32_t)InterlockedCompareExchange(&melee_rejected,0,0);
    InterlockedExchange(&melee_lock,0);
}
static void decide_projectile(const ArmorReplaySample *record, const unsigned char *event, uintptr_t context,const float *pellet_ap,const unsigned char *pellet_glance,unsigned pellets,const ArmorOrigin *origin) {
    if (!ArmorTake(&decision_lock)) return;
    decision.victim=word(event,0); decision.region=record->region;
    decision.collider=record->collider;
    decision.damage=word(event,0x2c); decision.projected=decision.damage;
    decision.penetration=record->selected; decision.factor=1;
    decision.armor_id=record->armor_id; decision.weight=record->weight; decision.rule=UINT32_MAX;
    decision.heavy_av4=0;
    int light_reinforced=0;
    int leak=0;
    unsigned gap_rolls=0,gap_passes=0,angled_used=0;uint32_t hit_weight=UINT32_MAX,hit_reinforced=0;
    ArmorEquipment current;
    uint32_t network=UINT32_MAX, session_confirmed=0;
    uint32_t avatar=resolve_identity(&network,&session_confirmed);
    int applying=InterlockedCompareExchange(&protection,0,0)!=0;
    if (avatar!=decision.victim || network!=record->avatar_network || !record->equipment_valid || !read_equipment(&current,applying)
        || current.id!=record->armor_id || current.weight!=record->weight) ++decision.unavailable;
    else {
        float factor;
        decision.heavy_av4=record->heavy_av4 && heavy_active(avatar,current.id,current.weight);
        light_reinforced=current.weight==0 && profile_active(avatar,current.id,current.weight);
        int reinforced_rule=current.weight==0 ? light_reinforced : decision.heavy_av4;
        // PT-BR: Placas inclinadas (média/pesada, fora da cabeça): raspão reduz a penetração efetiva em 1 (= blindagem +1).
        // EN: Angled plates (medium/heavy, outside the head): a glancing hit lowers effective penetration by 1 (= armor +1).
        int angled=InterlockedCompareExchange(&angled_plates,0,0) && (current.weight==1 || current.weight==2)
            && record->region!=UINT32_C(0x8c5570c9);
        float effective=angled && record->glancing && record->selected>=1 ? record->selected-1 : record->selected;
        angled_used=effective!=record->selected;hit_weight=current.weight;hit_reinforced=(uint32_t)reinforced_rule;
        int rule=ArmorRuleEvaluateProfile(current.weight,record->region,record->collider,effective,reinforced_rule,&factor);
        // PT-BR: Chumbos somados: cada um decide pela própria penetração; o dano somado é dividido igualmente.
        // EN: Summed pellets: each one decides by its own penetration; the summed damage is split evenly.
        uint64_t kept=0;
        // PT-BR: Frestas só na pesada: leve e média já têm pouca blindagem nos braços.
        // EN: Gaps only on heavy: light and medium already have little arm armor.
        int gaps=InterlockedCompareExchange(&arm_gaps,0,0) && current.weight==2 && arm_region(record->region);
        if (rule>=0 && pellet_ap && pellets>=2) {
            float highest=0;
            for (unsigned i=0;i<pellets && rule>=0;++i) {
                float each;
                float ap=angled && pellet_glance && pellet_glance[i] && pellet_ap[i]>=1 ? pellet_ap[i]-1 : pellet_ap[i];
                int r=ArmorRuleEvaluateProfile(current.weight,record->region,record->collider,ap,reinforced_rule,&each);
                if (r<0) rule=-1;
                else {
                    if (each==0) {if (gaps) {++gap_rolls;if (gap_roll()) {kept+=100;leak=1;++gap_passes;}}}
                    else kept+=each<1 ? 65 : 100;
                    if (pellet_ap[i]>highest) highest=pellet_ap[i];
                }
            }
            decision.penetration=highest;
            factor=rule>=0 ? (float)kept/(100.0f*pellets) : 1;
        }
        if (rule<0) ++decision.unavailable;
        else {
            decision.rule=(uint32_t)rule; decision.factor=factor;
            // PT-BR: O fator regional usa razão inteira para evitar erro de arredondamento em 65%.
            // EN: The regional factor uses an integer ratio to avoid rounding error at 65%.
            if (pellet_ap && pellets>=2) decision.projected=(uint32_t)((uint64_t)decision.damage*kept/(100u*pellets));
            else {
                if (factor==0 && gaps) {++gap_rolls;leak=gap_roll();gap_passes+=(unsigned)leak;}
                decision.projected=factor==0 ? (leak ? decision.damage : 0)
                    : factor<1 ? (uint32_t)((uint64_t)decision.damage*65/100) : decision.damage;
            }
            ++decision.evaluated;
            if (record->collider) ++decision.identified;else ++decision.fallback;
            if (rule && factor==0) ++decision.blocked;
            else if (rule && factor<1) ++decision.reduced;
            else ++decision.original;
        }
    }
    if (applying) {
        effect.victim=decision.victim; effect.region=decision.region;
        effect.before=decision.damage; effect.after=decision.damage; effect.reason=0;
        if (decision.rule==UINT32_MAX) effect.reason=2;
        else if (decision.projected<decision.damage) {
            ArmorEquipment final;
            uint32_t network_after=UINT32_MAX, private_session_after=0;
            if (!session_confirmed || !record->session_confirmed) effect.reason=1;
            else if ((uint32_t)InterlockedCompareExchange(&protection_epoch,0,0)!=record->epoch) effect.reason=3;
            else if (!read_equipment(&final,0) || final.id!=current.id || final.weight!=current.weight
                || resolve_identity(&network_after,&private_session_after)!=avatar || network_after!=network || !private_session_after) effect.reason=2;
            else if (!InterlockedCompareExchange(&enabled,0,0) || !InterlockedCompareExchange(&protection,0,0)) effect.reason=3;
            else if (decision.heavy_av4 && !heavy_active(avatar,current.id,current.weight)) effect.reason=3;
            else if (light_reinforced && !profile_active(avatar,current.id,current.weight)) effect.reason=3;
            else if (!ArmorDamageCommit(context,event,decision.projected)) effect.reason=4;
            else {
                effect.after=decision.projected; ++effect.applied;
                if (!decision.projected) ++effect.blocked; else ++effect.reduced;
                count_prevented(leak && decision.projected ? 4 : decision.projected ? 2 : 1,effect.before,effect.after,record->region,record->collider);
            }
        }
        // PT-BR: Fresta com dano inteiro: nada é escrito, mas o aviso na tela mostra que a bala achou a junta.
        // EN: Gap with full damage: nothing is written, but the on-screen flash shows the bullet found the joint.
        else if (leak) count_prevented(4,effect.before,effect.after,record->region,record->collider);
        if (effect.reason) ++effect.refused;
        record_outcome(1,decision.victim,record->region,origin,effect.before,effect.after);
    }
    {
        ArmorHitLog h={0};
        h.kind=1;h.element=word(event,8);h.cause=word(event,0x60);h.region=record->region;h.collider=record->collider;
        h.weight=hit_weight;h.reinforced=hit_reinforced;h.before=decision.damage;
        h.after=applying ? effect.after : decision.projected;h.reason=applying ? effect.reason : (decision.rule==UINT32_MAX ? 2 : 0);
        h.flags=(record->glancing ? 1u : 0u)|(angled_used ? 2u : 0u)|((pellets>255 ? 255u : pellets)<<8)|((gap_rolls>255 ? 255u : gap_rolls)<<16)
            |((gap_passes>255 ? 255u : gap_passes)<<24);
        h.ap=decision.penetration;h.distance=origin ? origin->net_distance : 0;h.attacker=origin_type(origin);
        push_hit(&h);
    }
    InterlockedExchange(&decision_lock,0);
}
static void predict_projectile(const unsigned char *hit, uintptr_t context, uintptr_t parent_address) {
    if (!round_projectile || !select_penetration || !game_base || word(hit, 0) != 0 || hit[0x71]) return;
    uintptr_t parent, grandparent, projectile, frame, base_ap, extra_ap, source_context;
    if (!read_at(parent_address, &parent, 8) || parent != game_base+0x12a266e) return;
    if (!read_at(parent_address+0x50, &grandparent, 8) || grandparent != game_base+0x13ad4ed
        || !read_at(parent_address-0x10, &frame, 8) || context < 0x580 || frame != context-0x580
        || !read_ptr(parent_address-0x38, &projectile)
        || !read_ptr(parent_address+0x98, &base_ap) || !read_ptr(parent_address+0x90, &extra_ap)
        || !read_ptr(parent_address+0x28, &source_context)) {
        InterlockedIncrement(&rejected); return;
    }
    ArmorReplayInput input;
    memcpy(&input.durable, hit+0x4c, 4);
    if (!read_at(base_ap, input.base, sizeof(input.base)) || !read_at(extra_ap, input.extra, sizeof(input.extra))
        || !read_at(projectile+0x38, &input.scale, 4)) { InterlockedIncrement(&rejected); return; }
    push_settings(0,word(hit,0x7c),0,base_ap,extra_ap,projectile);
    ArmorReplaySample record = {0};
    record.avatar_network=UINT32_MAX;
    record.epoch=(uint32_t)InterlockedCompareExchange(&protection_epoch,0,0);
    uint32_t current_avatar=resolve_identity(&record.avatar_network,&record.session_confirmed);
    record.weight=UINT32_MAX;
    ArmorEquipment equipment;
    if (current_avatar==word(hit,0x20) && read_equipment(&equipment,0)) {
        record.equipment_valid=1; record.armor_id=equipment.id; record.weight=equipment.weight;
        record.heavy_av4=heavy_active(current_avatar,equipment.id,equipment.weight);
    }
    unsigned char copy[0x118];
    memcpy(copy, hit, sizeof(copy));
    // PT-BR: O identificador opaco é copiado pelo jogo após a consulta observada.
    // EN: The game copies the opaque identifier after the observed query.
    if (!read_at(source_context+8, copy+0x110, 8)) { InterlockedIncrement(&rejected); return; }
    if (!ArmorReplayCalculate(&input, round_projectile, record.penetration)) { InterlockedIncrement(&rejected); return; }
    for (unsigned i=0; i<3; ++i) {
        float direction, normal;
        memcpy(&direction, hit+0x28+i*4, 4); memcpy(&normal, hit+0x88+i*4, 4);
        if (!isfinite(direction) || !isfinite(normal) || fabsf(direction) > 1.01f || fabsf(normal) > 1.01f) {
            InterlockedIncrement(&rejected); return;
        }
    }
    // PT-BR: O seletor recebe uma cópia própria; o impacto original nunca é modificado.
    // EN: The selector receives an owned copy; the original hit is never modified.
    memcpy(copy+0x9c, record.penetration, sizeof(record.penetration));
    record.selected = select_penetration(NULL, copy);
    if (!isfinite(record.selected) || record.selected < 0 || record.selected > 100) {
        InterlockedIncrement(&rejected); return;
    }
    // PT-BR: Raspão pelo critério do próprio jogo: a penetração escolhida pelo ângulo de impacto ficou abaixo da penetração
    // de frente (primeiro dos 4 valores). Placas inclinadas da média/pesada somam +1 de blindagem nesse caso.
    // EN: Glancing hit by the game's own criterion: the penetration picked for the impact angle is below the head-on
    // penetration (first of the 4 values). Medium/heavy angled plates add +1 armor in that case.
    record.glancing = record.selected < record.penetration[0] ? 1 : 0;
    ArmorReplayHitKey(copy, &record.key);
    record.region = word(hit, 0x7c);
    uint32_t collider=ArmorReplayTakeCollider(context,hit,GetTickCount64());
    record.collider=ArmorColliderRegion(collider)==record.region ? collider : 0;
    if (ArmorReplayRemember(&record, GetTickCount64())) InterlockedIncrement(&rebuilt);
    else InterlockedIncrement(&rejected);
}
static void match_projectile(const unsigned char *event, uintptr_t context,const ArmorOrigin *origin) {
    if (word(event, 4) != 0 || !round_projectile) return;
    ArmorReplayKey key;
    ArmorReplaySample record;
    ArmorReplayEventKey(event, &key);
    int found = ArmorReplayMatch(&key, GetTickCount64(), &record);
    unsigned pellets=0;float pellet_ap[32];unsigned char pellet_glance[32];
    if (found == 0) found = ArmorReplayMatchMerged(&key, GetTickCount64(), &record, pellet_ap, pellet_glance, 32, &pellets);
    if (found != 1) { InterlockedIncrement(found == -2 ? &ambiguous : &unmatched); return; }
    InterlockedIncrement(&matched);
    if (ArmorFireNative(word(event,8),origin ? origin->net_type : 0)) {
        InterlockedIncrement(&fire_native);
        ArmorHitLog h={0};
        h.kind=3;h.element=word(event,8);h.cause=word(event,0x60);h.region=record.region;h.collider=record.collider;h.weight=record.weight;
        h.before=h.after=word(event,0x2c);h.ap=record.selected;h.distance=origin ? origin->net_distance : 0;h.attacker=origin_type(origin);
        push_hit(&h);
        return;
    }
    decide_projectile(&record,event,context,pellets>=2 ? pellet_ap : NULL,pellets>=2 ? pellet_glance : NULL,pellets,origin);
    if (!ArmorTake(&prediction_lock)) return;
    prediction.victim = word(event, 0);
    prediction.region = record.region;
    prediction.damage = word(event, 0x2c);
    prediction.selected = record.selected;
    memcpy(prediction.penetration, record.penetration, sizeof(record.penetration));
    InterlockedExchange(&prediction_lock, 0);
}
static int read_ptr(uintptr_t address, uintptr_t *out) {
    return read_at(address, out, 8) && *out >= 65536 && *out < UINT64_C(0x800000000000);
}
#ifndef ARMOR_BRIDGE_TEST
static int lookup(uintptr_t header, uint32_t key, uint32_t *out) {
    unsigned char h[20];
    uintptr_t buckets;
    if (!read_at(header, h, sizeof(h))) return 0;
    memcpy(&buckets, h, 8);
    uint32_t capacity = word(h, 8), empty = word(h, 12), multiplier = word(h, 16);
    if (!capacity || capacity > 1048576 || (capacity & (capacity-1))) return 0;
    for (uint32_t i = 0; i < capacity && i < 4096; ++i) {
        uint32_t row[2];
        if (!read_at(buckets+((key*multiplier+i)&(capacity-1))*8, row, 8)) return 0;
        if (row[0] == key) { *out = row[1]; return row[1] != UINT32_MAX; }
        if (row[0] == empty) return 0;
    }
    return 0;
}
#endif
static uint32_t resolve_identity(uint32_t *network_out, uint32_t *session_confirmed_out) {
#ifdef ARMOR_BRIDGE_TEST
    *network_out=test_network; *session_confirmed_out=test_session_confirmed;
    return (uint32_t)InterlockedCompareExchange(&local_entity,0,0);
#else
    uintptr_t user, players, entities, health, descriptors, descriptor;
    uint64_t peer, candidate;
    uint32_t count, slot = UINT32_MAX, network, index, entity, live, health_index;
    unsigned char data[24];
    if (!game_base || !read_ptr(game_base+0x347cef0, &user) || !read_at(user+0xb398, &peer, 8)
        || !read_ptr(game_base+0x3326468, &players) || !read_at(players+0x84, &count, 4)
        || !count || count > 4) return UINT32_MAX;
    for (uint32_t i = 0; i < count; ++i) {
        if (!read_at(players+0x2c8+i*0x38, &candidate, 8)) return UINT32_MAX;
        if (peer == candidate) { if (slot != UINT32_MAX) return UINT32_MAX; slot = i; }
    }
    if (slot == UINT32_MAX || !read_at(players+0x3a8+slot*0x20, &network, 4)
        || network == 0x7fff || !read_ptr(game_base+0x346bf98, &entities)
        || !lookup(entities+0xf22ec8, network, &index) || index >= 1048576
        || !read_at(entities+0xf32f20+index*24, &entity, 4)
        || !read_ptr(game_base+0x3326688, &health) || !read_at(health+0x1020, &live, 4)
        || !live || live > 4096 || !lookup(health+0x1030, entity, &health_index) || health_index >= live
        || !read_ptr(health+0x1048, &descriptors) || !read_ptr(descriptors+health_index*8, &descriptor)
        || !read_at(descriptor, data, sizeof(data))) return UINT32_MAX;
    uint64_t type;
    memcpy(&type, data, 8);
    uintptr_t health_records;uint32_t life;
    if (!read_ptr(health+0x1058,&health_records)
        || !read_at(health_records+(uintptr_t)health_index*440+412,&life,4) || life>=2) return UINT32_MAX;
    uint32_t network_after, entity_after, index_after;
    uintptr_t descriptor_after;
    unsigned char after[24];
    if (type != UINT64_C(0x4d1c334d294dfa97) || word(data, 8) != entity || !(word(data, 20)&1)
        || !read_at(players+0x3a8+slot*0x20, &network_after, 4) || network != network_after
        || !read_at(entities+0xf32f20+index*24, &entity_after, 4) || entity != entity_after
        || !lookup(health+0x1030, entity, &index_after) || index_after != health_index
        || !read_ptr(descriptors+health_index*8, &descriptor_after) || descriptor != descriptor_after
        || !read_at(descriptor, after, sizeof(after)) || memcmp(data, after, sizeof(data))) return UINT32_MAX;
    uint64_t peer_after;uint32_t count_after;
    if (!read_at(user+0xb398,&peer_after,8) || peer_after!=peer
        || !read_at(players+0x84,&count_after,4) || count_after!=count) return UINT32_MAX;
    *network_out=network; *session_confirmed_out=ArmorSessionMission(read_at,game_base);
    return entity;
#endif
}
static uint32_t resolve_local(void) {
#ifdef ARMOR_BRIDGE_TEST
    return UINT32_MAX;
#else
    uint32_t network=UINT32_MAX, session_confirmed=0;
    return resolve_identity(&network,&session_confirmed);
#endif
}
BRIDGE_API void ArmorBridgeRefreshLocal(void) {
    if (ArmorSessionRefresh(read_at,game_base)) {
        InterlockedIncrement(&protection_epoch);ArmorReplayClear();ArmorMeleeClear();
    }
    // PT-BR: Identidade em cache só para diagnóstico; não autoriza modificar dano.
    // EN: Cached identity is diagnostic only and never authorizes changing damage.
    InterlockedExchange(&local_entity, (LONG)resolve_local());
}
static int exchange_slot(void **slot, void *replacement, void *expected) {
    // PT-BR: Uma recusa de acesso deve desligar o experimento, sem encerrar o jogo.
    // EN: An access refusal must disable the experiment without terminating the game.
    extern int ArmorExchangeSlot(void **, void *, void *);
    return ArmorExchangeSlot(slot, replacement, expected);
}

void ArmorBridgeObserve(uintptr_t site, uintptr_t context, uint32_t zone) {
    if (!InterlockedCompareExchange(&enabled, 0, 0)) return;
    LONG seen;
    uint32_t stage;
    if (site == ArmorBridgeInitSite) { stage = 1; seen = InterlockedIncrement(&init_seen); }
    else if (site == ArmorBridgeApplySite) { stage = 2; seen = InterlockedIncrement(&apply_seen); }
    else return;
    // PT-BR: Captura limitada; nenhuma leitura tardia de ponteiros de impactos é permitida.
    // EN: Capture is bounded; deferred reads of hit pointers are never allowed.
    unsigned char identity[0x40];
    int is_local = read_at(context, identity, stage == 1 ? sizeof(identity) : 4)
        && word(identity, stage == 1 ? 0x20 : 0) == (uint32_t)InterlockedCompareExchange(&local_entity, 0, 0)
        && (uint32_t)InterlockedCompareExchange(&local_entity, 0, 0) != UINT32_MAX;
    LONG local_count = is_local ? InterlockedIncrement(stage == 1 ? &local_init_seen : &local_apply_seen) : 0;
    if (stage==1 && is_local)
        ArmorReplayRememberCollider(context,identity,ArmorColliderRegion(zone) ? zone : 0,GetTickCount64());
    if (stage == 2 && is_local) {
        unsigned char event[0x70];
        if (read_at(context, event, sizeof(event)) && word(event, 0) == word(identity, 0)) {
            ArmorOrigin origin;
            build_event_origin(event,&origin);
            capture_combat(context,2,word(event,4),word(event,0),0,&origin);
            match_projectile(event,context,&origin);
            match_melee(event,context,&origin);
            record_cause(event,context,&origin);
        }
    }
    if (seen > 64 && (!is_local || local_count > 64)) return;
    unsigned char data[0x70];
    if (!read_at(context, data, stage == 1 ? 0x28 : sizeof(data))) {
        InterlockedIncrement(&read_failed);
        return;
    }
    if (InterlockedCompareExchange(&sample_lock, 1, 0)) {
        InterlockedIncrement(&dropped);
        return;
    }
    sample.stage = stage;
    sample.victim = word(data, stage == 1 ? 0x20 : 0);
    sample.zone = zone;
    sample.source_kind = word(data, stage == 1 ? 0 : 4);
    sample.damage = stage == 1 ? 0 : word(data, 0x2c);
    InterlockedIncrement(&captured);
    InterlockedExchange(&sample_lock, 0);
}

void ArmorBridgeObserveLate(uintptr_t context, uintptr_t parent_return_address) {
    if (!InterlockedCompareExchange(&enabled, 0, 0)) return;
    InterlockedIncrement(&late_seen);
    unsigned char identity[0x28], hit[0x118];
    uint32_t local = (uint32_t)InterlockedCompareExchange(&local_entity, 0, 0);
    if (local == UINT32_MAX || !read_at(context, identity, sizeof(identity)) || word(identity, 0x20) != local) return;
    InterlockedIncrement(&local_late_seen);
    // PT-BR: A origem é montada para todo impacto local, antes das cotas de diagnóstico.
    // EN: The origin is built for every local hit, ahead of the diagnostic quotas.
    ArmorOrigin origin;memset(&origin,0,sizeof(origin));
    if (word(identity,0)<16 && read_at(context,hit,sizeof(hit)) && word(hit,0)==word(identity,0) && word(hit,0x20)==local)
        build_hit_origin(hit,local,parent_return_address,&origin);
    if (word(identity,0)==2 && word(hit,0)==2 && word(hit,0x20)==local) observe_fire(hit,local);
    capture_combat(context,1,word(identity,0),local,parent_return_address,&origin);
    // PT-BR: A proteção não depende da cota limitada de registros de diagnóstico.
    // EN: Protection does not depend on the bounded diagnostic sample quota.
    if (word(identity,0)==6 && read_at(context,hit,sizeof(hit))
        && word(hit,0)==6 && word(hit,0x20)==local) capture_melee(hit,context,parent_return_address,&origin);
    int projectile = word(identity, 0) == 0;
    InterlockedIncrement(projectile ? &projectile_seen : &other_seen);
    // PT-BR: Trava ocupada após a espera curta conta como recusa, para nunca sumir sem rastro no log.
    // EN: A lock still busy after the short wait counts as rejected, so it never vanishes from the log.
    if (!ArmorTake(&detail_lock)) { if (projectile) InterlockedIncrement(&rejected); return; }
    if ((uint32_t)InterlockedCompareExchange(&local_entity, 0, 0) != local) {
        InterlockedExchange(&detail_lock, 0);
        return;
    }
    // PT-BR: Cada avatar recebe cotas separadas; outras categorias não esgotam os tiros.
    // EN: Each avatar gets separate quotas; other categories cannot exhaust projectile samples.
    if (quota_avatar != local) {
        quota_avatar = local;
        projectile_attempts = other_attempts = 0;
    }
    uint32_t *attempts = projectile ? &projectile_attempts : &other_attempts;
    int diagnostic=*attempts<64;
    if (!diagnostic && (!projectile || !InterlockedCompareExchange(&protection,0,0))) {
        InterlockedExchange(&detail_lock,0); return;
    }
    if (diagnostic) ++*attempts;
    if (!read_at(context, hit, sizeof(hit)) || word(hit, 0x20) != local
        || word(hit, 0) != word(identity, 0)) {
        InterlockedIncrement(&local_read_failed);
        InterlockedExchange(&detail_lock, 0);
        return;
    }
    detail.sample_avatar = word(hit, 0x20);
    if (projectile) predict_projectile(hit, context, parent_return_address);
    if (!diagnostic) { InterlockedExchange(&detail_lock,0); return; }
    detail.region = word(hit, 0x7c);
    detail.source_kind = word(hit, 0);
    memcpy(detail.penetration, hit+0x9c, sizeof(detail.penetration));
    memcpy(&detail.raw_damage, hit+0x98, 4);
    memcpy(&detail.multiplier, hit+0x94, 4);
    uintptr_t parent = 0;
    detail.parent_return_rva = read_at(parent_return_address, &parent, sizeof(parent))
        && game_base && parent >= game_base && parent < game_base+0x4744000 ? (uint32_t)(parent-game_base) : 0;
    InterlockedIncrement(&local_captured);
    InterlockedIncrement(projectile ? &projectile_captured : &other_captured);
    InterlockedExchange(&detail_lock, 0);
}

// PT-BR: Ponteiro de dados gravável: o jogo usa PAGE_READWRITE; outro mod que fez gancho perto pode ter deixado a página
// como PAGE_EXECUTE_READWRITE (relato de 12/10/2026, código 42). As duas aceitam a troca atômica do ponteiro.
// EN: Writable data pointer: the game uses PAGE_READWRITE; another mod hooking nearby may have left the page as
// PAGE_EXECUTE_READWRITE (report of 2026-10-12, code 42). Both accept the atomic pointer swap.
// PT-BR: PAGE_WRITECOPY/PAGE_EXECUTE_WRITECOPY: página da própria imagem do jogo que ainda não foi gravada (vira READWRITE
// na primeira escrita). Relato de 12/10/2026: código 42 mesmo só com o carregador; a troca atômica funciona igual.
// EN: PAGE_WRITECOPY/PAGE_EXECUTE_WRITECOPY: a page of the game's own image not yet written (becomes READWRITE on the first
// write). Report of 2026-10-12: code 42 even with only the loader; the atomic swap works the same.
static volatile LONG refused_protect,refused_state;
static int writable_slot(DWORD protect) {
    DWORD base=protect&0xff;
    return !(protect&(PAGE_GUARD|PAGE_NOACCESS)) && (base==PAGE_READWRITE || base==PAGE_EXECUTE_READWRITE
        || base==PAGE_WRITECOPY || base==PAGE_EXECUTE_WRITECOPY);
}
BRIDGE_API uint32_t ArmorBridgeRefusedProtection(void) {return (uint32_t)InterlockedCompareExchange(&refused_protect,0,0);}
BRIDGE_API uint32_t ArmorBridgeRefusedState(void) {return (uint32_t)InterlockedCompareExchange(&refused_state,0,0);}
static int attach_late(void **slot, uintptr_t site) {
    if (InterlockedCompareExchange(&late_installed, 0, 0)) return 1;
    MEMORY_BASIC_INFORMATION region;
    void *previous;
    if ((uintptr_t)slot % 8 || !read_at((uintptr_t)slot, &previous, 8) || !previous
        || VirtualQuery(slot, &region, sizeof(region)) != sizeof(region)) return 41;
    if (region.State != MEM_COMMIT || !writable_slot(region.Protect)
        || (uintptr_t)slot+8 > (uintptr_t)region.BaseAddress+region.RegionSize) {
        InterlockedExchange(&refused_protect,(LONG)region.Protect);InterlockedExchange(&refused_state,(LONG)region.State);
        return 42;
    }
    if (previous == (void *)ArmorLateHook || (ArmorLateOriginal && previous != ArmorLateOriginal)) return 43;
    ArmorLateOriginal = previous;
    ArmorBridgeLateSite = site;
    late_slot = slot;
    int result = exchange_slot(slot, (void *)ArmorLateHook, previous);
    if (result != 1) return result < 0 ? 45 : 44;
    InterlockedExchange(&late_installed, 1);
    return 1;
}

static int attach(void **slot, uintptr_t init_site, uintptr_t apply_site) {
    if (InterlockedCompareExchange(&installed, 0, 0)) return 1;
    MEMORY_BASIC_INFORMATION region;
    void *previous;
    if ((uintptr_t)slot % sizeof(void *) || !read_at((uintptr_t)slot, &previous, sizeof(previous)) || !previous)
        return 11;
    if (VirtualQuery(slot, &region, sizeof(region)) != sizeof(region)) return 12;
    InterlockedExchange(&slot_protection, (LONG)region.Protect);
    if (region.State != MEM_COMMIT || !writable_slot(region.Protect)
        || (uintptr_t)slot + sizeof(void *) > (uintptr_t)region.BaseAddress + region.RegionSize) {
        InterlockedExchange(&refused_protect,(LONG)region.Protect);InterlockedExchange(&refused_state,(LONG)region.State);
        return 13;
    }
    if (previous == (void *)ArmorActorHook || (ArmorActorOriginal && ArmorActorOriginal != previous)) return 14;
    ArmorActorOriginal = previous;
    ArmorBridgeInitSite = init_site;
    ArmorBridgeApplySite = apply_site;
    actor_slot = slot;
    // PT-BR: Publica só o ponteiro de dados confirmado; não escreve nem reprotege instruções.
    // EN: Publish only the verified data pointer; instructions are neither written nor reprotected.
    int swapped = exchange_slot(slot, (void *)ArmorActorHook, previous);
    if (swapped != 1) return swapped < 0 ? 16 : 15;
    InterlockedExchange(&installed, 1);
    return 1;
}

#ifndef ARMOR_BRIDGE_TEST
static int fingerprint(HMODULE module, const char *expected) {
    WCHAR path[32768];
    if (!GetModuleFileNameW(module, path, 32768)) return 0;
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                             NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return 0;
    BCRYPT_ALG_HANDLE algorithm = NULL;
    BCRYPT_HASH_HANDLE hash = NULL;
    unsigned char buffer[65536], digest[32];
    char identity[65];
    const char hex[] = "0123456789abcdef";
    int ok = 0;
    DWORD count;
    if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, NULL, 0) < 0
        || BCryptCreateHash(algorithm, &hash, NULL, 0, NULL, 0, 0) < 0) goto done;
    for (;;) {
        if (!ReadFile(file, buffer, sizeof(buffer), &count, NULL)) goto done;
        if (!count) break;
        if (BCryptHashData(hash, buffer, count, 0) < 0) goto done;
    }
    if (BCryptFinishHash(hash, digest, sizeof(digest), 0) < 0) goto done;
    for (unsigned i = 0; i < 32; ++i) {
        identity[2*i] = hex[digest[i] >> 4];
        identity[2*i+1] = hex[digest[i] & 15];
    }
    identity[64] = 0;
    ok = !strcmp(identity, expected);
done:
    if (hash) BCryptDestroyHash(hash);
    if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0);
    CloseHandle(file);
    return ok;
}
static int code_fingerprint(uintptr_t address, SIZE_T length, const char *expected) {
    unsigned char code[512], digest[32];
    const char hex[] = "0123456789abcdef";
    if (length > sizeof(code) || !read_at(address, code, length)
        || BCryptHash(BCRYPT_SHA256_ALG_HANDLE, NULL, 0, code, (ULONG)length, digest, 32) < 0) return 0;
    for (unsigned i=0; i<32; ++i)
        if (expected[2*i] != hex[digest[i] >> 4] || expected[2*i+1] != hex[digest[i]&15]) return 0;
    return 1;
}
static int install_live(void) {
    HMODULE game = GetModuleHandleW(L"game.dll"), executable = GetModuleHandleW(NULL), own;
    if (!game) return -1;
    if (!fingerprint(game, "2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e")
        || !fingerprint(executable, "f5fee03dcfdb2e553a4752c283590950ac13316b376d8196aa556ff0400d5f06")) return 21;
    uintptr_t base = (uintptr_t)game, table, engine, getter_table;
    static const unsigned char init_pin[] = {
        0x48,0x8b,0x05,0x0f,0x45,0x08,0x02,0x41,0x8b,0x4e,0x24,0x48,0x8b,0x50,0x78,0xff,0xd2};
    static const unsigned char apply_pin[] = {
        0x48,0x8b,0x05,0xa4,0xe5,0x07,0x02,0x41,0x8b,0x4e,0x0c,0x48,0x8b,0x50,0x78,0xff,0xd2};
    static const unsigned char late_pin[] = {
        0x48,0x8b,0x0d,0x9f,0x3d,0x08,0x02,0x48,0x8b,0x41,0x40,0x48,0x8b,0x98,0x68,0x01,0x00,0x00,
        0x48,0x8b,0x41,0x38,0xff,0x50,0x08};
    unsigned char code[17];
    if (!read_at(base + 0x12a1e22, code, sizeof(code)) || memcmp(code, init_pin, sizeof(code))
        || !read_at(base + 0x12a7d8d, code, sizeof(code)) || memcmp(code, apply_pin, sizeof(code))) return 22;
    if (!read_at(base + 0x3326338, &table, sizeof(table))) return 23;
    void *target;
    MEMORY_BASIC_INFORMATION region;
    if (!read_at(table + 0x78, &target, sizeof(target))
        || VirtualQuery(target, &region, sizeof(region)) != sizeof(region)
        || region.AllocationBase != executable || region.State != MEM_COMMIT
        || !(region.Protect == PAGE_EXECUTE_READ || region.Protect == PAGE_EXECUTE_WRITECOPY)) return 24;
    unsigned char late_code[sizeof(late_pin)];
    if (!read_at(base+0x12a2562, late_code, sizeof(late_code)) || memcmp(late_code, late_pin, sizeof(late_code))) return 46;
    static const unsigned char gear_pin[]={
        0x0f,0x10,0x81,0x20,0x01,0x00,0x00,0x0f,0x11,0x83,0x4c,0x01,0x00,0x00,
        0x0f,0x10,0x89,0x30,0x01,0x00,0x00,0x0f,0x11,0x8b,0x5c,0x01,0x00,0x00};
    unsigned char gear_code[sizeof(gear_pin)];
    if (!read_at(base+0x1751380,gear_code,sizeof(gear_code)) || memcmp(gear_code,gear_pin,sizeof(gear_code))) return 52;
    if (!code_fingerprint(base+0x20bbb78, 101, "9e9ece86f9eb27230bfe53d6cb001d2733c2284bfb9568ff2048ee466c4a376e")
        || !code_fingerprint(base+0x12a25b0, 462, "b9e602a17316995090dfe5eaf5a78ee3e8479702b4e191775fce876651d1e692")
        || !code_fingerprint(base+0x13ad484, 233, "9e1e487e11828a453f22552338c885382b9852d2e399e50b723b6b61606c8948")
        || !code_fingerprint(base+0x129c7c0, 308, "8f2f835399b4e507f791735def02c77757f3f4476c2143bbcd2e90b2376a4a95")) return 51;
    if (!code_fingerprint(base+0x9aaa50, 256, "9c153f5f7c023d42f1718f1f1ed333554f75685a9fa779194f244e0eaa0491f1")
        || !code_fingerprint(base+0x9aab50, 256, "db5b1dd038431dde0199230dae04c0dadf90232a4ef1a06f04aed791ea2820c8")
        || !code_fingerprint(base+0x9aac50, 80, "9ce271e71761693943a552f9da01e253a38917b2e793bca70db517505844d70b")
        || !code_fingerprint(base+0x785de0, 272, "0ca097208fa395ba4f5fffb511bb0a1916071f6447aa86bc1cae7c4a4db201c1")
        || !code_fingerprint(base+0x89c050, 171, "d22045b31ae933ed08510b70a32b090df47ebc7bcdf020e6d09000b4f94faf94")
        || !code_fingerprint(base+0x89cf70, 256, "7a56ce39d1c71a63b24ab2fac5bffbf69d440f12f20648fadf1751417e247428")
        || !code_fingerprint(base+0x89c540, 80, "c074cd2d570ef7cbf37fae20f2e75b3df6215e68ac41f799f9de1c173537f876")
        || !code_fingerprint(base+0x512f90, 160, "ab278e1df58c206fb53e401cb489ce43d341ebd460000073529aef86bfee56e2")
        || !code_fingerprint(base+0x509570, 180, "39dbbd8d1c7b0830f5d9650a6acb0917c7f7a608c56cf406e63d25b5080a0658")
        || !code_fingerprint(base+0x752714, 102, "23e3ca88bbeb0ac780dcaf03143f8e4714492a37fdfd66086a7af07bd66e9e28")) return 61;
    round_projectile = (ArmorRound)(base+0x20bbb78);
    select_penetration = (float (*)(void *, const unsigned char *))(base+0x129c7c0);
    if (!read_ptr(base+0x3326308, &engine) || !read_ptr(engine+0x38, &getter_table)
        || !read_at(getter_table+8, &target, 8) || VirtualQuery(target, &region, sizeof(region)) != sizeof(region)
        || region.AllocationBase != executable || region.State != MEM_COMMIT
        || !(region.Protect == PAGE_EXECUTE_READ || region.Protect == PAGE_EXECUTE_WRITECOPY)) return 47;
    // PT-BR: A DLL fica residente mesmo após desativar, pois outra thread pode estar no adaptador.
    // EN: The DLL remains resident after disabling because another thread may be inside the adapter.
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
                           (LPCWSTR)(uintptr_t)ArmorActorHook, &own)) return 25;
    game_base = base;
    exe_base = (uintptr_t)executable;
    InterlockedExchange(&local_entity, -1);
    int result = attach_late((void **)(getter_table+8), base+0x12a257b);
    if (result != 1) return result;
    result = attach((void **)(table + 0x78), base + 0x12a1e33, base + 0x12a7d9e);
    if (result != 1) ArmorBridgeDetach();
    return result;
}
#endif

BRIDGE_API int ArmorBridgeInstall(void) {
    if (InterlockedCompareExchange(&installed, 0, 0)) return 1;
#ifdef ARMOR_BRIDGE_TEST
    int result = -1;
#else
    int result = install_live();
#endif
    InterlockedExchange(&status, result);
    return result;
}
BRIDGE_API void ArmorBridgeEnable(int value) {
    InterlockedExchange(&enabled, value ? 1 : 0);
    if (!value) { ArmorBridgeProtect(0); ArmorBridgeProfileStep(0,0); ArmorBridgeHeavyStep(0); ArmorReplayClear();ArmorMeleeClear(); ArmorOriginClear(); ArmorErgoRestore(); ArmorSwimRestore(); }
}
BRIDGE_API void ArmorBridgeReadSwim(ArmorSwimStats *out) { ArmorSwimReadStats(out); }
static volatile LONG category_lock;
static uint64_t category_time;
static LONG category_epoch;
static ArmorEquipment category_armor;
static uint32_t category_avatar;
#ifdef ARMOR_BRIDGE_TEST
static uint64_t category_cache_ms;
#else
static const uint64_t category_cache_ms=250;
#endif
static int runtime_category(ArmorEquipment *armor,uint32_t *avatar) {
    uint32_t network,session_confirmed,after_network,after_session;ArmorEquipment after;
    if (!InterlockedCompareExchange(&enabled,0,0)) return 0;
    // PT-BR: Identidade/categoria confirmadas valem 250 ms; escritas seguem validadas pelo registro próprio.
    // EN: Confirmed identity/category stay valid for 250 ms; writes remain validated by the owned record.
    uint64_t now=GetTickCount64();LONG epoch=InterlockedCompareExchange(&protection_epoch,0,0);
    if (category_cache_ms && ArmorTake(&category_lock)) {
        int hit=category_time && now>=category_time && now-category_time<category_cache_ms && category_epoch==epoch;
        if (hit) {*armor=category_armor;*avatar=category_avatar;}
        InterlockedExchange(&category_lock,0);
        if (hit) return 1;
    }
    *avatar=resolve_identity(&network,&session_confirmed);
    int valid=*avatar!=UINT32_MAX && session_confirmed && read_equipment(armor,0)
        && resolve_identity(&after_network,&after_session)==*avatar && after_session && after_network==network
        && read_equipment(&after,0) && after.id==armor->id && after.weight==armor->weight;
    if (ArmorTake(&category_lock)) {
        category_time=valid ? now : 0;category_epoch=epoch;
        if (valid) {category_armor=*armor;category_avatar=*avatar;}
        InterlockedExchange(&category_lock,0);
    }
    return valid;
}
static uintptr_t runtime_game(void) {
#ifdef ARMOR_BRIDGE_TEST
    return test_runtime_base;
#else
    return game_base;
#endif
}
BRIDGE_API void ArmorBridgeReadMovement(ArmorMovementStats *out) {ArmorMovementReadStats(out);}
// PT-BR: Pesquisa (só leitura) das tabelas de status e de passivos do jogo. Os endereços e o formato das tabelas
// (mapa de status por dono, blocos de 48 bytes por status, passivo -> lista de modificadores de 16 bytes) seguem o
// que o mod Realistic Resistances documentou para esta versão do jogo; cada trecho de código é conferido byte a byte
// antes do uso e, se o jogo mudar, a pesquisa fica desligada. Nada é escrito.
// EN: Read-only research into the game's status and passive tables. The addresses and table layout (status map by
// owner, 48-byte status blocks, passive -> list of 16-byte modifiers) follow what the Realistic Resistances mod
// documented for this game build; each code site is checked byte by byte before use and, if the game changes, the
// research stays off. Nothing is written.
#ifndef ARMOR_BRIDGE_TEST
typedef struct ResearchLayout {
    int state;
    uintptr_t status,passives,link,owners,players;
    uint32_t smap,blocks,bstride,bcount,entries,pmap,rstride,slot[2],ptable,plist,lmap,lstride,lrec,omap,orows;
} ResearchLayout;
static ResearchLayout research;
static volatile LONG research_lock;
// PT-BR: Etapa da pesquisa que falhou (1-14: trechos de código; 20+: leitura das tabelas), para o log.
// EN: Research step that failed (1-14: code sites; 20+: table reads), for the log.
static volatile uint32_t research_fail,research_owner_seen,research_key_seen,research_avatar_seen;
static volatile uint32_t research_raw[3];
static int code_match(uint32_t rva,const char *pattern,unsigned char *code,unsigned size) {
    unsigned n=0;
    for (const char *p=pattern;p[0] && p[1];p+=2) {
        if (n>=size) return 0;
        ++n;
    }
    if (!game_base || !read_at(game_base+rva,code,n)) return 0;
    n=0;
    for (const char *p=pattern;p[0] && p[1];p+=2,++n) {
        if (p[0]=='?') continue;
        unsigned v=0;
        for (int k=0;k<2;++k) {char c=p[k];v=v*16+(unsigned)(c<='9' ? c-'0' : c-'a'+10);}
        if (code[n]!=v) return 0;
    }
    return 1;
}
static uint32_t code_u32(const unsigned char *code,unsigned at) {uint32_t v;memcpy(&v,code+at,4);return v;}
static uintptr_t code_rip(uint32_t rva,const unsigned char *code,unsigned at) {
    int32_t d;memcpy(&d,code+at,4);return game_base+rva+at+4+(intptr_t)d;
}
static int research_ready(void) {
    if (research.state) return research.state>0;
    unsigned char c[64];
    research.state=-1;
    if (!code_match(0xC22AC,"4c8b1d????????33d248896c2450458b8b????????418b9b????????0fafd8",c,sizeof(c))) {research_fail=1;return 0;}
    research.status=code_rip(0xC22AC,c,3);
    uint32_t cap=code_u32(c,17),mult=code_u32(c,24);
    if (mult!=cap+8) {research_fail=2;return 0;}
    research.smap=cap-8;
    if (!code_match(0x699D14,"8bc24c69d0????????33c04c0391????????458b5a??4585db74??90488d0c404803c9453984ca????????75??45398cca????????",c,sizeof(c))) {research_fail=3;return 0;}
    research.bstride=code_u32(c,5);research.blocks=code_u32(c,14);research.bcount=c[21];research.entries=code_u32(c,49);
    if (code_u32(c,39)!=research.entries+4 || research.bstride<=research.entries) {research_fail=4;return 0;}
    if (!code_match(0x11D9EF5,"4c8b0d????????448bc7458b91????????418bb1????????0faff1",c,sizeof(c))) {research_fail=5;return 0;}
    research.passives=code_rip(0x11D9EF5,c,3);cap=code_u32(c,13);mult=code_u32(c,20);
    if (mult!=cap+8) {research_fail=6;return 0;}
    research.pmap=cap-8;
    if (!code_match(0x11D9F7D,"4c6bd8??438b840b????????85c074??41f6c40174??418b4c81??83f9ff74??498b41??",c,sizeof(c))) {research_fail=7;return 0;}
    research.rstride=c[3];research.slot[0]=code_u32(c,8);research.ptable=c[26];research.plist=c[35];
    if (!code_match(0x11D9FDA,"438b840b????????85c074??41f6c40274??418b4c81",c,sizeof(c))) {research_fail=8;return 0;}
    research.slot[1]=code_u32(c,4);
    if (!code_match(0x11D9E19,"4c8b1d????????448bc7458b8b????????418bb3????????0faff1",c,sizeof(c))) {research_fail=9;return 0;}
    research.link=code_rip(0x11D9E19,c,3);cap=code_u32(c,13);mult=code_u32(c,20);
    if (mult!=cap+8) {research_fail=10;return 0;}
    research.lmap=cap-8;
    if (!code_match(0x11D9ECA,"b8ffffffff8bc8486bc1??488d4c2450428b9418????????e8",c,sizeof(c))) {research_fail=11;return 0;}
    research.lstride=c[10];research.lrec=code_u32(c,20);
    if (!code_match(0xFD9BA4,"4c8b1d????????448bc24c8bc981faff7f000075??8b05????????",c,sizeof(c))) {research_fail=12;return 0;}
    research.owners=code_rip(0xFD9BA4,c,3);
    if (!code_match(0xFD9BC9,"458b93????????33d248895c2410418b9b????????48896c2418410fafd8",c,sizeof(c))) {research_fail=13;return 0;}
    cap=code_u32(c,3);mult=code_u32(c,17);
    if (mult!=cap+8) {research_fail=14;return 0;}
    research.omap=cap-8;
    if (!code_match(0xFD9C44,"44390075??8b4004488d0440488d80????????498d04c38b00418901",c,sizeof(c))) {research_fail=15;return 0;}
    research.orows=code_u32(c,15)*8-8;
    // PT-BR: Tabela de jogadores: o helldiver local fica em +936 (contadores em +132).
    // EN: Players table: the local helldiver sits at +936 (counters at +132).
    if (!code_match(0x3A4BDE,"488b05????????488d542448488b88e8000000",c,sizeof(c))) {research_fail=16;return 0;}
    research.players=code_rip(0x3A4BDE,c,3);
    research.state=1;
    return 1;
}
static uint32_t research_avatar(void) {
    uintptr_t players;uint32_t counts[2],avatar;
    // PT-BR: Guarda os valores crus (contadores e helldiver) para o log mostrar por que a leitura falhou.
    // EN: Keeps the raw values (counters and helldiver) so the log shows why the read failed.
    research_raw[0]=research_raw[1]=research_raw[2]=UINT32_MAX;
    if (!read_ptr(research.players,&players) || !read_at(players+132,counts,8)) return UINT32_MAX;
    research_raw[0]=counts[0];research_raw[1]=counts[1];
    if (!counts[0] || !counts[1] || !read_at(players+936,&avatar,4)) return UINT32_MAX;
    research_raw[2]=avatar;
    if (avatar==32767) return UINT32_MAX;
    research_avatar_seen=avatar;
    return avatar;
}
static uint32_t research_owner(uint32_t entity) {
    uintptr_t owners;uint32_t row,owner;
    if (!read_ptr(research.owners,&owners) || !lookup(owners+research.omap,entity,&row)
        || !read_at(owners+research.orows+(uintptr_t)row*24+8,&owner,4)) return UINT32_MAX;
    return owner;
}
BRIDGE_API void ArmorBridgeReadStatus(ArmorStatusDump *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (!ArmorTake(&research_lock)) return;
    uintptr_t map,blocks;uint32_t index,count=0,local=UINT32_MAX;
    // PT-BR: A etapa com falha vale só para a leitura atual (antes ficava presa no último erro, mesmo com leituras boas).
    // EN: The failed step only reflects the current read (before it stuck on the last error, even after good reads).
    if (research.state>0) research_fail=0;
    if (!research_ready()) {}
    else if ((local=research_avatar())==UINT32_MAX) research_fail=19;
    else if ((out->owner=research_owner(local))==UINT32_MAX) research_fail=20;
    else if (!read_ptr(research.status,&map)) research_fail=21;
    else if (!lookup(map+research.smap,out->owner,&index)) research_fail=22;
    else if (!read_ptr(map+research.blocks,&blocks)) research_fail=23;
    else {
        uintptr_t block=blocks+(uintptr_t)index*research.bstride;
        if (!read_at(block+research.bcount,&count,4) || count>(research.bstride-research.entries)/48) research_fail=24;
        else {
            unsigned char e[48];
            out->valid=1;
            for (uint32_t i=0;i<count && out->count<16;++i) {
                if (!read_at(block+research.entries+(uintptr_t)i*48,e,48)) {out->valid=0;break;}
                ArmorStatusEntry *s=&out->entry[out->count++];
                s->id=word(e,0);memcpy(&s->value,e+8,4);memcpy(&s->clock,e+12,4);memcpy(&s->ends,e+16,4);s->on=word(e,20)!=0;
            }
        }
    }
    InterlockedExchange(&research_lock,0);
}
static int research_tables(uint32_t key,ArmorPassiveDump *out) {
    uintptr_t g,list,table,mods;uint32_t index;
    if (!read_ptr(research.passives,&g) || !lookup(g+research.pmap,key,&index)) return 0;
    for (int s=0;s<2;++s) {
        uint32_t a,k;unsigned char head[32];
        if (!read_at(g+(uintptr_t)index*research.rstride+research.slot[s],&a,4) || !a || a>=100000) continue;
        if (!read_at(g+(uintptr_t)a*4+research.ptable,&k,4) || k==UINT32_MAX || !read_ptr(g+research.plist,&list)
            || !read_ptr(list+(uintptr_t)k*8,&table) || !read_at(table,head,32)) continue;
        uint32_t id=word(head,0);
        int seen=0;
        for (uint32_t t=0;t<out->tables;++t) if (out->table[t].id==id) seen=1;
        if (seen) continue;
        ArmorPassiveTable *p=&out->table[out->tables++];
        p->id=id;p->name=word(head,4);p->count=word(head,24);
        memcpy(&mods,head+16,8);
        for (uint32_t m=0;m<p->count && m<8;++m) {
            unsigned char r[16];
            if (mods<0x10000 || !read_at(mods+(uintptr_t)m*16,r,16)) break;
            p->modifier[m].stat=word(r,0);p->modifier[m].op=word(r,4);memcpy(&p->modifier[m].value,r+8,4);
        }
    }
    return out->tables>0;
}
BRIDGE_API void ArmorBridgeReadPassives(ArmorPassiveDump *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (!ArmorTake(&research_lock)) return;
    uint32_t local=research_ready() ? research_avatar() : UINT32_MAX;
    if (local!=UINT32_MAX && (out->owner=research_owner(local))!=UINT32_MAX) {
        out->key=out->owner;
        if (!research_tables(out->owner,out)) {
            // PT-BR: O mapa de passivos pode usar outra chave; o mapa de ligação redireciona o dono.
            // EN: The passive map may use another key; the link map redirects the owner.
            uintptr_t g;uint32_t li,target;
            if (read_ptr(research.link,&g) && lookup(g+research.lmap,out->owner,&li)
                && read_at(g+research.lrec+(uintptr_t)li*research.lstride,&target,4) && target!=32767
                && (out->key=research_owner(target))!=UINT32_MAX) research_tables(out->key,out);
        }
        out->valid=out->tables>0;
        if (!out->valid) research_fail=30;
        research_owner_seen=out->owner;research_key_seen=out->key;
    }
    else if (research.state>0) research_fail=31;
    InterlockedExchange(&research_lock,0);
}
// PT-BR: Troca temporária do valor de um modificador do passivo vestido (teste do tranco). Guarda o original e o devolve
// ao desligar, ao trocar de passivo ou ao fechar o jogo. Escreve com WriteProcessMemory (falha sem derrubar o jogo).
// EN: Temporary override of a modifier of the worn passive (flinch test). Keeps the original and puts it back when turned
// off, when the passive changes or when the game closes. Writes with WriteProcessMemory (fails without crashing the game).
static uintptr_t override_at;static uint32_t override_stat;static float override_original;
static int override_restore(void) {
    if (!override_at) return 1;
    SIZE_T written=0;
    int ok=WriteProcessMemory(GetCurrentProcess(),(void *)override_at,&override_original,4,&written) && written==4;
    override_at=0;override_stat=0;
    return ok;
}
BRIDGE_API int ArmorBridgePassiveOverride(uint32_t stat,float value,int enable) {
    if (!ArmorTake(&research_lock)) return -1;
    int result=0;
    if (!enable) result=override_restore();
    else if (research_ready()) {
        uint32_t local=research_avatar(),owner=local==UINT32_MAX ? UINT32_MAX : research_owner(local);
        uintptr_t g,list,table,mods,found=0;uint32_t index;
        if (owner!=UINT32_MAX && read_ptr(research.passives,&g) && lookup(g+research.pmap,owner,&index)) {
            for (int s=0;s<2 && !found;++s) {
                uint32_t a,k,n;unsigned char head[32];
                if (!read_at(g+(uintptr_t)index*research.rstride+research.slot[s],&a,4) || !a || a>=100000) continue;
                if (!read_at(g+(uintptr_t)a*4+research.ptable,&k,4) || k==UINT32_MAX || !read_ptr(g+research.plist,&list)
                    || !read_ptr(list+(uintptr_t)k*8,&table) || !read_at(table,head,32)) continue;
                n=word(head,24);memcpy(&mods,head+16,8);
                for (uint32_t m=0;m<n && m<8 && !found;++m) {
                    uint32_t st;if (mods>=0x10000 && read_at(mods+(uintptr_t)m*16,&st,4) && st==stat) found=mods+(uintptr_t)m*16+8;
                }
            }
        }
        if (found) {
            if (override_at && override_at!=found) override_restore();
            if (!override_at) {
                float original;
                if (read_at(found,&original,4)) {override_at=found;override_stat=stat;override_original=original;}
            }
            SIZE_T written=0;
            result=override_at && WriteProcessMemory(GetCurrentProcess(),(void *)found,&value,4,&written) && written==4 ? 1 : -1;
        }
        else {override_restore();result=0;}
    }
    InterlockedExchange(&research_lock,0);
    return result;
}
BRIDGE_API void ArmorBridgeResearchState(uint32_t out[9]) {
    if (!out) return;
    out[6]=research_raw[0];out[7]=research_raw[1];out[8]=research_raw[2];
    out[0]=(uint32_t)research.state;out[1]=research_fail;out[2]=(uint32_t)InterlockedCompareExchange(&local_entity,0,0);
    out[3]=research_owner_seen;out[4]=research_key_seen;out[5]=research_avatar_seen;
}
#else
BRIDGE_API void ArmorBridgeResearchState(uint32_t out[9]) {if (out) memset(out,0,9*sizeof(uint32_t));}
BRIDGE_API int ArmorBridgePassiveOverride(uint32_t stat,float value,int enable) {(void)stat;(void)value;(void)enable;return 0;}
BRIDGE_API void ArmorBridgeReadStatus(ArmorStatusDump *out) {if (out) memset(out,0,sizeof(*out));}
BRIDGE_API void ArmorBridgeReadPassives(ArmorPassiveDump *out) {if (out) memset(out,0,sizeof(*out));}
#endif
// PT-BR: Pesquisa (só leitura): copia o registro local de 0x34 bytes onde fica a velocidade (+4), para achar outros
// multiplicadores de passivo, como a chance de derrubada (Rock-Solid = 0,7). Devolve 1 quando a cópia é válida.
// EN: Research (read-only): copies the local 0x34-byte record that holds movement (+4), to find other passive
// multipliers such as knockdown chance (Rock-Solid = 0.7). Returns 1 when the copy is valid.
BRIDGE_API int ArmorBridgeReadCharacterRecord(uint32_t out[13]) {
    if (!out) return 0;
    memset(out,0,13*sizeof(uint32_t));
    uint32_t avatar;ArmorEquipment armor;ArmorOwnedRecord r;
    if (!runtime_category(&armor,&avatar) || !ArmorLocalMovement(read_at,runtime_game(),avatar,&r) || r.stride!=0x34) return 0;
    return read_at(r.record,out,13*sizeof(uint32_t)) ? 1 : 0;
}
BRIDGE_API void ArmorBridgeReadEquipped(ArmorEquippedStats *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));out->weight=UINT32_MAX;
    ArmorEquipment armor;uint32_t avatar;
    if (!runtime_category(&armor,&avatar)) return;
    out->avatar=avatar;out->armor_id=armor.id;out->weight=armor.weight;out->valid=1;
}
BRIDGE_API int ArmorBridgeProfileStep(uint32_t armor_id,int reinforced) {
    // PT-BR: Vincula o modo ao avatar/modelo/categoria atuais e invalida os impactos capturados antes da troca.
    // EN: Bind the mode to the current avatar/model/category and invalidate hits captured before a change.
    ArmorEquipment armor;uint32_t avatar;
    int valid=armor_id && armor_id!=UINT32_MAX && runtime_category(&armor,&avatar) && armor.id==armor_id;
    if (!ArmorTake(&profile_lock)) return 0;
    uint32_t next_avatar=valid ? avatar : UINT32_MAX,next_weight=valid ? armor.weight : UINT32_MAX;
    uint32_t next_armor=valid ? armor.id : 0;int next_mode=valid && reinforced;
    int changed=profile.avatar!=next_avatar || profile.armor!=next_armor || profile.weight!=next_weight || profile.reinforced!=next_mode;
    profile.avatar=next_avatar;profile.armor=next_armor;profile.weight=next_weight;profile.reinforced=next_mode;
    if (changed) InterlockedIncrement(&protection_epoch);
    InterlockedExchange(&profile_lock,0);
    if (changed) {ArmorReplayClear();ArmorMeleeClear();}
    return valid;
}
static int movement_step(int wanted,uint32_t required_id,uint32_t weight,float factor,int reinforced) {
    LONG mode=weight==2 && wanted && reinforced ? 1 : 0;
    if (InterlockedExchange(&heavy_mode,mode)!=mode) {
        InterlockedIncrement(&protection_epoch);ArmorReplayClear();ArmorMeleeClear();
    }
    InterlockedExchange(&heavy_avatar,-1);InterlockedExchange(&heavy_armor,-1);
    uint32_t avatar;ArmorEquipment armor;ArmorOwnedRecord r;
    if (!wanted || !InterlockedCompareExchange(&protection,0,0)) {ArmorMovementSuspend(1);return 0;}
    if (!runtime_category(&armor,&avatar) || armor.weight!=weight) {ArmorMovementSuspend(5);return 0;}
    if (required_id!=UINT32_MAX && armor.id!=required_id) {ArmorMovementSuspend(5);return 0;}
    if (!ArmorLocalMovement(read_at,runtime_game(),avatar,&r)) {ArmorMovementSuspend(2);return 0;}
    uint32_t after;ArmorEquipment final;
    if (!runtime_category(&final,&after) || after!=avatar || final.id!=armor.id || final.weight!=weight
        || !ArmorMovementApplyFactor(&r,factor)) {ArmorMovementRestore();return 0;}
    if (weight!=2) return 1;
    // PT-BR: AV4 só é liberada depois de aplicar e reler a penalidade na mesma instância local.
    // EN: Enable AV4 only after applying and reading back the penalty on the same local instance.
    InterlockedExchange(&heavy_armor,(LONG)armor.id);InterlockedExchange(&heavy_avatar,(LONG)avatar);
    return 1;
}
static int heavy_step(int wanted,uint32_t required_id,float factor,int reinforced) {
    return movement_step(wanted,required_id,2,factor,reinforced);
}
BRIDGE_API int ArmorBridgeHeavyStep(int wanted) {return heavy_step(wanted,UINT32_MAX,.9f,1);}
BRIDGE_API int ArmorBridgeHeavyArmorStep(uint32_t armor_id) {
    return heavy_step(armor_id!=0 && armor_id!=UINT32_MAX,armor_id,.9f,1);
}
BRIDGE_API int ArmorBridgeArmorStep(uint32_t armor_id,int reinforced) {
    if (!ArmorBridgeProfileStep(armor_id,reinforced)) {
        heavy_step(0,UINT32_MAX,.9f,0);return 0;
    }
    ArmorEquipment armor;uint32_t avatar;
    if (!runtime_category(&armor,&avatar) || armor.id!=armor_id) {
        ArmorBridgeProfileStep(0,0);heavy_step(0,UINT32_MAX,.9f,0);return 0;
    }
    // PT-BR: Leve ganha velocidade (padrão +10%, reforçada +5%); média mantém o movimento original.
    // Lentidão ao levar golpe: leve x0,75 por 1,5 s; média x0,85 por 1 s; pesada nenhuma.
    // EN: Light gains speed (standard +10%, reinforced +5%); medium keeps original movement.
    // Slow-on-hit: light x0.75 for 1.5 s; medium x0.85 for 1 s; heavy none.
    uint64_t hurt=(uint64_t)InterlockedCompareExchange64(&hurt_at,0,0),now=now_ms();
    uint64_t since=hurt && now>=hurt ? now-hurt : UINT64_MAX;
    if (armor.weight==0) {
        float base=reinforced ? 1.05f : 1.10f;
        return movement_step(1,armor_id,0,since<=1500 ? base*.75f : base,0);
    }
    if (armor.weight==1) {
        if (since<=1000) return movement_step(1,armor_id,1,.85f,0);
        heavy_step(0,UINT32_MAX,.9f,0);return 1;
    }
    if (armor.weight!=2) {heavy_step(0,UINT32_MAX,.9f,0);return 1;}
    return heavy_step(1,armor_id,reinforced ? .90f : .95f,reinforced);
}
BRIDGE_API void ArmorBridgeReadHandling(uintptr_t unused,ArmorHandlingStats *out) {
    (void)unused;
    if (!out) return;
    memset(out,0,sizeof(*out));out->reason=1;
    uint32_t network,session_confirmed;ArmorOwnedRecord r;float base;
    uint32_t avatar=resolve_identity(&network,&session_confirmed);
    if (avatar==UINT32_MAX || !ArmorLocalPrimary(read_at,runtime_game(),avatar,&r,&base)) return;
    out->source=r.record;memcpy(&out->resource,r.identity,8);out->source_value=base;
    ArmorHandlingRow *row=&out->rows[0];
    memcpy(&row->entity,r.identity+8,4);memcpy(&row->unit,r.identity+12,4);
    if (!read_at(r.record+0x360,&row->base,4) || !read_at(r.record+0x3a8,&row->current,4)
        || !read_at(r.record+0x340,&row->response_a,4) || !read_at(r.record+0x344,&row->response_b,4)
        || !ArmorOwnedValidate(read_at,&r)) return;
    out->count=1;out->reason=0;
}
BRIDGE_API int ArmorBridgeSwimStep(int wanted) {
    uint32_t avatar;ArmorEquipment armor;ArmorOwnedRecord r;float maximum;
    if (!wanted || !runtime_category(&armor,&avatar))
        return ArmorSwimStep(NULL,0,UINT32_MAX,0);
    // PT-BR: Toda armadura leve (padrão e reforçada) repõe o fôlego; média e pesada não.
    // EN: Every light armor (standard and reinforced) refills breath; medium and heavy do not.
    if (armor.weight!=0) return ArmorSwimStep(NULL,0,armor.weight,0);
    if (!ArmorLocalAir(read_at,runtime_game(),avatar,&r,&maximum)) return ArmorSwimStep(NULL,0,armor.weight,1);
    uint32_t after;ArmorEquipment final;
    if (!runtime_category(&final,&after) || after!=avatar || final.id!=armor.id || final.weight!=armor.weight)
        return ArmorSwimStep(NULL,0,UINT32_MAX,0);
    return ArmorSwimStep(&r,maximum,armor.weight,1);
}
BRIDGE_API int ArmorBridgeErgoRestore(void) { return ArmorErgoRestore(); }
BRIDGE_API void ArmorBridgeReadErgo(ArmorErgoStats *out) { ArmorErgoReadStats(out); }
BRIDGE_API int ArmorBridgeErgoStep(int wanted) {
    uint32_t avatar;ArmorEquipment armor;ArmorOwnedRecord r;float base;
    if (!wanted || !InterlockedCompareExchange(&enabled,0,0)) {ArmorErgoRestore();return ArmorErgoReject(ARMOR_ERGO_INACTIVE);}
    if (!runtime_category(&armor,&avatar)) {ArmorErgoRestore();return ArmorErgoReject(ARMOR_ERGO_NOT_MISSION);}
    if (!ArmorLocalPrimary(read_at,runtime_game(),avatar,&r,&base)) return ArmorErgoReject(ARMOR_ERGO_BAD_RECORD);
    uint32_t after;ArmorEquipment final;
    if (!runtime_category(&final,&after) || after!=avatar || final.id!=armor.id || final.weight!=armor.weight)
        return ArmorErgoReject(ARMOR_ERGO_IDENTITY_CHANGED);
    return ArmorErgoApplyProfile(&r,base,armor.weight,profile_active(avatar,armor.id,armor.weight));
}
BRIDGE_API void ArmorBridgeProtect(int value) {
    LONG wanted=value ? 1 : 0;
    if (InterlockedExchange(&protection,wanted)!=wanted) {
        InterlockedIncrement(&protection_epoch); ArmorReplayClear();ArmorMeleeClear();
    }
}
#ifndef ARMOR_BRIDGE_TEST
static int override_restore(void);
#endif
BRIDGE_API int ArmorBridgeDetach(void) {
    ArmorBridgeEnable(0);
#ifndef ARMOR_BRIDGE_TEST
    override_restore();
#endif
    if (InterlockedCompareExchange(&late_installed, 0, 0)) {
        MEMORY_BASIC_INFORMATION late_region;
        if (VirtualQuery(late_slot, &late_region, sizeof(late_region)) != sizeof(late_region)
            || late_region.State != MEM_COMMIT || !writable_slot(late_region.Protect)) return 48;
        if (exchange_slot(late_slot, ArmorLateOriginal, (void *)ArmorLateHook) != 1) return 49;
        InterlockedExchange(&late_installed, 0);
    }
    if (!InterlockedCompareExchange(&installed, 0, 0)) return 1;
    MEMORY_BASIC_INFORMATION region;
    if (VirtualQuery(actor_slot, &region, sizeof(region)) != sizeof(region)
        || region.State != MEM_COMMIT || !writable_slot(region.Protect)) return 32;
    if (exchange_slot(actor_slot, ArmorActorOriginal, (void *)ArmorActorHook) != 1) return 31;
    InterlockedExchange(&installed, 0);
    return 1;
}
BRIDGE_API void ArmorBridgeReadDetail(ArmorBridgeDetail *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    if (!InterlockedCompareExchange(&detail_lock, 1, 0)) {
        *out = detail;
        InterlockedExchange(&detail_lock, 0);
    }
    out->late_installed = InterlockedCompareExchange(&late_installed, 0, 0);
    out->local_avatar = InterlockedCompareExchange(&local_entity, 0, 0);
    out->local_init_seen = InterlockedCompareExchange(&local_init_seen, 0, 0);
    out->local_apply_seen = InterlockedCompareExchange(&local_apply_seen, 0, 0);
    out->late_seen = InterlockedCompareExchange(&late_seen, 0, 0);
    out->local_late_seen = InterlockedCompareExchange(&local_late_seen, 0, 0);
    out->local_captured = InterlockedCompareExchange(&local_captured, 0, 0);
    out->local_read_failed = InterlockedCompareExchange(&local_read_failed, 0, 0);
}
BRIDGE_API void ArmorBridgeReadSampling(ArmorBridgeSampling *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    out->quota_avatar = UINT32_MAX;
    if (!InterlockedCompareExchange(&detail_lock, 1, 0)) {
        out->quota_avatar = quota_avatar;
        out->projectile_remaining = 64-projectile_attempts;
        out->other_remaining = 64-other_attempts;
        InterlockedExchange(&detail_lock, 0);
    }
    out->projectile_seen = InterlockedCompareExchange(&projectile_seen, 0, 0);
    out->other_seen = InterlockedCompareExchange(&other_seen, 0, 0);
    out->projectile_captured = InterlockedCompareExchange(&projectile_captured, 0, 0);
    out->other_captured = InterlockedCompareExchange(&other_captured, 0, 0);
}
BRIDGE_API void ArmorBridgeReadPrediction(ArmorBridgePrediction *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    if (!InterlockedCompareExchange(&prediction_lock, 1, 0)) {
        *out = prediction;
        InterlockedExchange(&prediction_lock, 0);
    }
    out->rebuilt = InterlockedCompareExchange(&rebuilt, 0, 0);
    out->rejected = InterlockedCompareExchange(&rejected, 0, 0);
    out->matched = InterlockedCompareExchange(&matched, 0, 0);
    out->unmatched = InterlockedCompareExchange(&unmatched, 0, 0);
    out->ambiguous = InterlockedCompareExchange(&ambiguous, 0, 0);
}
BRIDGE_API void ArmorBridgeReadDecision(ArmorBridgeDecision *out) {
    if (!out) return;
    memset(out,0,sizeof(*out)); out->weight=out->rule=UINT32_MAX;
    if (ArmorTake(&decision_lock)) {
        *out=decision;
        InterlockedExchange(&decision_lock,0);
    }
}
#ifdef ARMOR_BRIDGE_TEST
static uint64_t test_now;
void ArmorBridgeTestNow(uint64_t ms) {test_now=ms;}
void ArmorBridgeTestHurt(uint64_t ms) {InterlockedExchange64(&hurt_at,(LONG64)ms);}
static uint64_t now_ms(void) {return test_now ? test_now : GetTickCount64();}
#else
static uint64_t now_ms(void) {return GetTickCount64();}
#endif
BRIDGE_API void ArmorBridgeReadReport(ArmorReport *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (!ArmorTake(&report_lock)) return;
    *out=report;InterlockedExchange(&report_lock,0);
}
BRIDGE_API void ArmorBridgeReadTotals(ArmorTotals *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    out->sequence=(uint32_t)InterlockedCompareExchange(&totals_sequence,0,0);
    out->shots_blocked=(uint32_t)InterlockedCompareExchange(&totals_blocked,0,0);
    out->shots_reduced=(uint32_t)InterlockedCompareExchange(&totals_reduced,0,0);
    out->shot_prevented=(uint32_t)InterlockedCompareExchange(&totals_shot_prevented,0,0);
    out->melee_reduced=(uint32_t)InterlockedCompareExchange(&totals_melee,0,0);
    out->melee_prevented=(uint32_t)InterlockedCompareExchange(&totals_melee_prevented,0,0);
    out->last_kind=(uint32_t)InterlockedCompareExchange(&totals_last_kind,0,0);
    out->last_prevented=(uint32_t)InterlockedCompareExchange(&totals_last_prevented,0,0);
    out->last_region=(uint32_t)InterlockedCompareExchange(&totals_last_region,0,0);
    out->last_collider=(uint32_t)InterlockedCompareExchange(&totals_last_collider,0,0);
    out->last_after=(uint32_t)InterlockedCompareExchange(&totals_last_after,0,0);
#ifndef ARMOR_BRIDGE_TEST
    out->mission=game_base && ArmorSessionMission(read_at,game_base) ? 1 : 0;
    out->session=out->mission ? ArmorSessionCurrent() : 0;
#else
    out->mission=test_session_confirmed;out->session=test_session_confirmed ? 1 : 0;
#endif
}
BRIDGE_API void ArmorBridgeReadEffect(ArmorBridgeEffect *out) {
    if (!out) return;
    memset(out,0,sizeof(*out));
    if (ArmorTake(&decision_lock)) {
        *out=effect; InterlockedExchange(&decision_lock,0);
    }
    out->enabled=InterlockedCompareExchange(&enabled,0,0) && InterlockedCompareExchange(&protection,0,0);
}
BRIDGE_API void ArmorBridgeReadStats(ArmorBridgeStats *out) {
    if (!out) return;
    memset(out, 0, sizeof(*out));
    if (!InterlockedCompareExchange(&sample_lock, 1, 0)) {
        *out = sample;
        InterlockedExchange(&sample_lock, 0);
    }
    out->installed = InterlockedCompareExchange(&installed, 0, 0);
    out->enabled = InterlockedCompareExchange(&enabled, 0, 0);
    out->status = InterlockedCompareExchange(&status, 0, 0);
    out->slot_protection = InterlockedCompareExchange(&slot_protection, 0, 0);
    out->init_seen = InterlockedCompareExchange(&init_seen, 0, 0);
    out->apply_seen = InterlockedCompareExchange(&apply_seen, 0, 0);
    out->captured = InterlockedCompareExchange(&captured, 0, 0);
    out->dropped = InterlockedCompareExchange(&dropped, 0, 0);
    out->read_failed = InterlockedCompareExchange(&read_failed, 0, 0);
    // PT-BR: Estado da opção; a confirmação de escrita está nos contadores de efeito.
    // EN: Option state; successful writes are confirmed by the effect counters.
    out->protection_active = InterlockedCompareExchange(&enabled,0,0) && InterlockedCompareExchange(&protection,0,0);
}
#ifdef ARMOR_BRIDGE_TEST
void ArmorBridgeTestMaxHealth(uint32_t value) {test_max_health=value;}
void ArmorBridgeTestCategoryCache(uint64_t ms) {category_cache_ms=ms;category_time=0;}
void ArmorBridgeTestIdentity(uint32_t network, int session_confirmed) { test_network=network; test_session_confirmed=session_confirmed ? 1 : 0; }
void ArmorBridgeTestRuntime(uintptr_t base) {test_runtime_base=base;}
void ArmorBridgeTestEquipment(ArmorEquipmentReader reader) {
    equipment_reader=reader; memset(&equipment_cache,0,sizeof(equipment_cache));
}
void ArmorBridgeTestReplay(void *round_value, void *select_value) {
    game_base = UINT64_C(0x1000000000);
    round_projectile = (ArmorRound)round_value;
    select_penetration = (float (*)(void *, const unsigned char *))select_value;
}
void ArmorBridgeTestPredict(const unsigned char *hit, uintptr_t context, uintptr_t parent) {
    predict_projectile(hit, context, parent);
}
void ArmorBridgeTestSetLocal(uint32_t entity) { InterlockedExchange(&local_entity, (LONG)entity); }
int ArmorBridgeTestLateInstall(void **slot, uintptr_t site) { return attach_late(slot, site); }
int ArmorBridgeTestExchange(void **slot, void *replacement, void *expected) {
    return exchange_slot(slot, replacement, expected);
}
int ArmorBridgeTestInstall(void **slot, uintptr_t init_site, uintptr_t apply_site) {
    return attach(slot, init_site, apply_site);
}
#endif
