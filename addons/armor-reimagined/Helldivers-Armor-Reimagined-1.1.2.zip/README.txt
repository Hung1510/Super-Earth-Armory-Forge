# Armor Reimagined 1.1.2 - Helldivers 2

**English** · [Português](#português)

Light, medium and heavy armor finally feel different. Each armor class gets regional protection against shots, its own melee damage reduction, ergonomics and movement speed. Every armor model has a **standard** or **reinforced** profile you pick in the Armory.

This is an **addition on top of the original armor system**, not a replacement: the game's armor rating still gives its normal damage resistance, and the mod's regional protection and melee reduction stack on top of it.

> **Play in private lobbies or with friends.** The mod only changes your own character, but Helldivers 2 is an online game. Use it at your own risk.

## What changes

| Armor | Shots (armor value) | Melee reduction (torso / limbs) | Primary ergonomics | Movement |
| --- | --- | --- | --- | --- |
| Light standard | Torso AV2, shoulders AV2 | 15% / 0% | +15% | **+10%** |
| Light reinforced | Torso AV2, shoulders AV3, rest of limbs AV1 | 15% / 10% | +10% | **+5%** |
| Medium standard | Upper chest, shoulders and shins AV3, rest AV2 | Chest 20%, rest and limbs 15% | 0% | 0% |
| Medium reinforced | Upper chest, shoulders, forearms and shins AV3, rest AV2 | Chest 25%, rest and limbs 20% | −10% | 0% |
| Heavy standard | Torso, arms and legs AV3 | 25% / 20% | −20% | −5% |
| Heavy reinforced | Upper chest AV4, rest of torso, arms and legs AV3 | 35% / 25% | −20% | −10% |

- **Shots:** penetration below the armor value is blocked. Equal penetration keeps 65% of the damage. Higher penetration deals full damage.
- **Melee:** any physical strike from an enemy right next to you gets the armor reduction. That includes enemies the mod has never seen.
- **Slow when hit (new in 1.1):** damage your armor did not fully block slows light armor by 25% for 1.5 s and medium armor by 15% for 1 s. Heavy armor is not slowed, and a blocked shot never slows you.
- **Angled plates (optional, off by default, medium and heavy):** when a shot hits at an angle steep enough for the game itself to lower its penetration, the armor also counts one level higher. In my tests this is very strong, so only turn it on if you don't mind. Helmets are not affected.
- **Gaps in arm and leg armor (on by default, heavy armor only):** a shot blocked on an arm or leg has a 20% chance to get through the joint with full damage. Can be turned off in the MODS menu.
- **Helmets:** every helmet counts as AV3 against shots and reduces melee hits to the head by **20%**, whatever armor you wear.
- **Never reduced:** lethal blows (a strike that would kill you from full health stays lethal), acid spit, explosions, fire, and the Charger, Bile Titan and Impaler.
- **Light standard** has no plating on forearms and legs (shots there deal normal damage), only AV2 shoulders, and both light versions let you swim without running out of breath. The reinforced light version adds AV1 to the limbs and AV3 shoulders.
- **On screen (new in 1.1):** a short **BLOCKED** or **ARMOR -X** flash under the crosshair whenever your armor stops or softens a hit, and an **Armor Report** at the end of each mission (after the statistics screen) with shots blocked, shots reduced, melee hits reduced and total damage prevented.
- Effects apply **only to your own character**. Visual hit effects are unchanged.

## Choosing standard or reinforced

In the Armory armor list, click the small protection indicator under the armor to switch between **standard** and **reinforced**. Hover to preview the values: a body silhouette shows the armor value of each region. The choice is saved per armor model.

## Installation

1. Requires **Bingus Shared Loader**. Keep it at the bottom of the mod list.
2. Import the ZIP in the Arsenal mod manager, replacing any older version. Keep only one enabled.
3. Deploy, then **restart the game**.
4. The MODS menu has four settings: **language** (English, Português do Brasil, Español), **on-screen armor feedback** (the BLOCKED / ARMOR -X flash and the end-of-mission report, on by default) **gaps in arm and leg armor** (on by default) and **angled plates** (experimental, off by default).

## Game updates and safety

The mod checks the exact game version on startup. After a game patch it **turns itself off** and shows a message on screen until it is updated, so the game never runs with outdated addresses. If anything looks wrong, the mod keeps the original game behavior.

**Compatibility:** other mods that change the same values (armor stats, character movement speed or weapon ergonomics) may conflict. In that case the mod refuses to write instead of stacking changes.

**Known issue - friendly fire:** shots from other players are not blocked or reduced yet, because in multiplayer the shooter's game decides that damage. Enemy attacks are reduced normally. A fix is planned for a future update.

**Diagnostics (optional):** create an empty file `%LOCALAPPDATA%\CowboyBingus\Helldivers2\RegionalArmorDiagnostics.txt` to log detailed information about each hit. Delete it to turn diagnostics off. Log: `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\HelldiversArmorBridge.log`.

## Credits

- **CowboyBingus - Bingus Shared Loader.** Without it this mod would certainly not have been possible: it is the foundation that loads, isolates and keeps every part of Armor Reimagined running.
- **ChaosOfficerOnyx**, author of [Helldivers' Ammunition](https://github.com/ChaosOfficerOnyx/Helldivers-Ammunition): the Armory description UI style was inspired by his mod.
- **ice36656**, author of **HD2 Entity Summoner**: summoning enemies on demand made testing every melee attack possible.
- **SkyeShade / HD2Runtime**: public research on the game's entity and health structures, used as a reference.
- **Community concept image** showing a Helldiver unarmored, in light armor and in medium armor ("the devs watching this: I just know this would be a nightmare to add"). Author unknown - this image is what inspired the creation of this mod. If you are the author, please get in touch so you can be credited by name.

---

## Português

Armaduras leves, médias e pesadas agora fazem diferença de verdade. Cada classe tem proteção regional contra tiros, redução própria de dano corpo a corpo, ergonomia e velocidade. Cada modelo de armadura tem um perfil **padrão** ou **reforçado**, escolhido no Arsenal.

Isto é uma **adição ao sistema de armadura original**, não uma substituição: o Armor Rating do jogo continua dando a resistência normal, e a proteção regional e a redução de corpo a corpo do mod se somam a ela.

> **Jogue em lobby privado ou com amigos.** O mod altera só o seu personagem, mas Helldivers 2 é um jogo online. Use por sua conta e risco.

### O que muda

| Armadura | Tiros (blindagem) | Redução corpo a corpo (tronco / membros) | Ergonomia da principal | Movimento |
| --- | --- | --- | --- | --- |
| Leve padrão | Tronco AV2, ombros AV2 | 15% / 0% | +15% | **+10%** |
| Leve reforçada | Tronco AV2, ombros AV3, resto dos membros AV1 | 15% / 10% | +10% | **+5%** |
| Média padrão | Peitoral, ombros e canelas AV3, restante AV2 | Peitoral 20%, restante e membros 15% | 0% | 0% |
| Média reforçada | Peitoral, ombros, antebraços e canelas AV3, restante AV2 | Peitoral 25%, restante e membros 20% | −10% | 0% |
| Pesada padrão | Tronco, braços e pernas AV3 | 25% / 20% | −20% | −5% |
| Pesada reforçada | Peitoral AV4, resto do tronco, braços e pernas AV3 | 35% / 25% | −20% | −10% |

- **Tiros:** penetração abaixo da blindagem é bloqueada. Penetração igual mantém 65% do dano. Penetração maior causa dano total.
- **Corpo a corpo:** qualquer golpe físico de um inimigo colado em você recebe a redução da armadura, inclusive de inimigos que o mod nunca viu.
- **Lentidão ao levar golpe (novo na 1.1):** dano que a armadura não bloqueou por completo deixa a leve 25% mais lenta por 1,5 s e a média 15% mais lenta por 1 s. A pesada não fica lenta, e tiro bloqueado nunca deixa lento.
- **Placas inclinadas (opcional, desligado por padrão, média e pesada):** quando o tiro pega num ângulo em que o próprio jogo já reduz a penetração, a blindagem também conta um nível acima. Pelos meus testes fica muito forte, então ative só se não se importar. Capacetes não mudam.
- **Frestas nos braços e pernas (ligado por padrão, só na pesada):** um tiro bloqueado no braço ou na perna tem 20% de chance de passar pela junta com o dano inteiro. Dá para desligar no menu MODS.
- **Capacetes:** todo capacete conta como AV3 contra tiros e reduz em **20%** os golpes corpo a corpo na cabeça, com qualquer armadura.
- **Nunca reduzidos:** golpes letais (um golpe que mata com vida cheia continua matando), cuspe de ácido, explosões, fogo, e Charger, Bile Titan e Impaler.
- **Leve padrão** não tem blindagem nos antebraços e pernas (tiros ali causam dano normal), só ombros AV2, e as duas versões da leve permitem nadar sem perder o fôlego. A leve reforçada põe AV1 nos membros e ombros AV3.
- **Na tela (novo na 1.1):** um aviso rápido **BLOQUEADO** ou **ARMADURA -X** abaixo da mira sempre que a armadura segura ou amortece um golpe, e um **Relatório da Armadura** no fim de cada missão (depois da tela de estatísticas) com tiros bloqueados, tiros reduzidos, golpes reduzidos e dano total evitado.
- Os efeitos valem **só para o seu personagem**. Os efeitos visuais de impacto continuam originais.

### Escolhendo padrão ou reforçado

Na lista de armaduras do Arsenal, clique no pequeno indicador de proteção abaixo da armadura para alternar entre **padrão** e **reforçado**. Passe o mouse para ver os valores: uma silhueta do corpo mostra a blindagem de cada região. A escolha fica salva por modelo.

### Instalação

1. Requer o **Bingus Shared Loader**, por último na lista de mods.
2. Importe o ZIP no Arsenal, substituindo a versão anterior. Deixe só uma habilitada.
3. Faça Deploy e **reinicie o jogo**.
4. O menu MODS tem quatro opções: **idioma** (English, Português do Brasil, Español), **aviso de proteção na tela** (o aviso BLOQUEADO / ARMADURA -X e o relatório do fim da missão, ligado por padrão) **frestas nos braços e pernas** (ligado por padrão) e **placas inclinadas** (experimental, desligado por padrão).

### Atualizações do jogo e segurança

O mod confere a versão exata do jogo ao iniciar. Depois de um patch ele **se desliga sozinho** e mostra um aviso na tela até ser atualizado, para nunca rodar com endereços desatualizados. Se algo não bater, o mod mantém o comportamento original do jogo.

**Compatibilidade:** outros mods que alteram os mesmos valores (status de armadura, velocidade do personagem ou ergonomia) podem conflitar. Nesse caso o mod se recusa a escrever, em vez de somar alterações.

**Problema conhecido - fogo amigo:** tiros de outros jogadores ainda não são bloqueados nem reduzidos, porque no multiplayer quem decide esse dano é o jogo de quem atirou. Ataques de inimigos são reduzidos normalmente. A correção está planejada para uma próxima atualização.

**Diagnóstico (opcional):** crie um arquivo vazio `%LOCALAPPDATA%\CowboyBingus\Helldivers2\RegionalArmorDiagnostics.txt` para registrar detalhes de cada golpe. Apague para desligar. Log: `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\HelldiversArmorBridge.log`.

### Créditos

- **CowboyBingus - Bingus Shared Loader.** Sem ele, este mod com certeza não seria possível: é a base que carrega, isola e mantém funcionando cada parte do Armor Reimagined.
- **ChaosOfficerOnyx**, autor do [Helldivers' Ammunition](https://github.com/ChaosOfficerOnyx/Helldivers-Ammunition): o estilo da interface de descrição no Arsenal foi inspirado no mod dele.
- **ice36656**, autor do **HD2 Entity Summoner**: invocar inimigos sob demanda tornou possível testar cada golpe corpo a corpo.
- **SkyeShade / HD2Runtime**: pesquisa pública sobre as estruturas de entidades e vida do jogo, usada como referência.
- **Imagem conceito da comunidade** mostrando um Helldiver sem armadura, com armadura leve e com armadura média ("os devs vendo isso: eu sabia que seria um pesadelo adicionar"). Autor desconhecido - foi essa imagem que inspirou a criação deste mod. Se você é o autor, entre em contato para ser creditado pelo nome.
